gdjs.Start_32MenuCode = {};
gdjs.Start_32MenuCode.GDTitlesObjects1= [];
gdjs.Start_32MenuCode.GDTitlesObjects2= [];
gdjs.Start_32MenuCode.GDTitlesObjects3= [];
gdjs.Start_32MenuCode.GDTitlesObjects4= [];
gdjs.Start_32MenuCode.GDTitlesObjects5= [];
gdjs.Start_32MenuCode.GDTitlesObjects6= [];
gdjs.Start_32MenuCode.GDTitlesObjects7= [];
gdjs.Start_32MenuCode.GDTitlesObjects8= [];
gdjs.Start_32MenuCode.GDTitlesObjects9= [];
gdjs.Start_32MenuCode.GDTitlesObjects10= [];
gdjs.Start_32MenuCode.GDTitlesObjects11= [];
gdjs.Start_32MenuCode.GDTitlesObjects12= [];
gdjs.Start_32MenuCode.GDTitlesObjects13= [];
gdjs.Start_32MenuCode.GDTitlesObjects14= [];
gdjs.Start_32MenuCode.GDTitlesObjects15= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects1= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects2= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects3= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects4= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects5= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects6= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects7= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects8= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects9= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects10= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects11= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects12= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects13= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects14= [];
gdjs.Start_32MenuCode.GDNew_9595gameObjects15= [];
gdjs.Start_32MenuCode.GDContinueObjects1= [];
gdjs.Start_32MenuCode.GDContinueObjects2= [];
gdjs.Start_32MenuCode.GDContinueObjects3= [];
gdjs.Start_32MenuCode.GDContinueObjects4= [];
gdjs.Start_32MenuCode.GDContinueObjects5= [];
gdjs.Start_32MenuCode.GDContinueObjects6= [];
gdjs.Start_32MenuCode.GDContinueObjects7= [];
gdjs.Start_32MenuCode.GDContinueObjects8= [];
gdjs.Start_32MenuCode.GDContinueObjects9= [];
gdjs.Start_32MenuCode.GDContinueObjects10= [];
gdjs.Start_32MenuCode.GDContinueObjects11= [];
gdjs.Start_32MenuCode.GDContinueObjects12= [];
gdjs.Start_32MenuCode.GDContinueObjects13= [];
gdjs.Start_32MenuCode.GDContinueObjects14= [];
gdjs.Start_32MenuCode.GDContinueObjects15= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects1= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects2= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects3= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects4= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects5= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects6= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects7= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects8= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects9= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects10= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects11= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects12= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects13= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects14= [];
gdjs.Start_32MenuCode.GDExit_9595gameObjects15= [];
gdjs.Start_32MenuCode.GDCreditsObjects1= [];
gdjs.Start_32MenuCode.GDCreditsObjects2= [];
gdjs.Start_32MenuCode.GDCreditsObjects3= [];
gdjs.Start_32MenuCode.GDCreditsObjects4= [];
gdjs.Start_32MenuCode.GDCreditsObjects5= [];
gdjs.Start_32MenuCode.GDCreditsObjects6= [];
gdjs.Start_32MenuCode.GDCreditsObjects7= [];
gdjs.Start_32MenuCode.GDCreditsObjects8= [];
gdjs.Start_32MenuCode.GDCreditsObjects9= [];
gdjs.Start_32MenuCode.GDCreditsObjects10= [];
gdjs.Start_32MenuCode.GDCreditsObjects11= [];
gdjs.Start_32MenuCode.GDCreditsObjects12= [];
gdjs.Start_32MenuCode.GDCreditsObjects13= [];
gdjs.Start_32MenuCode.GDCreditsObjects14= [];
gdjs.Start_32MenuCode.GDCreditsObjects15= [];
gdjs.Start_32MenuCode.GDPanelObjects1= [];
gdjs.Start_32MenuCode.GDPanelObjects2= [];
gdjs.Start_32MenuCode.GDPanelObjects3= [];
gdjs.Start_32MenuCode.GDPanelObjects4= [];
gdjs.Start_32MenuCode.GDPanelObjects5= [];
gdjs.Start_32MenuCode.GDPanelObjects6= [];
gdjs.Start_32MenuCode.GDPanelObjects7= [];
gdjs.Start_32MenuCode.GDPanelObjects8= [];
gdjs.Start_32MenuCode.GDPanelObjects9= [];
gdjs.Start_32MenuCode.GDPanelObjects10= [];
gdjs.Start_32MenuCode.GDPanelObjects11= [];
gdjs.Start_32MenuCode.GDPanelObjects12= [];
gdjs.Start_32MenuCode.GDPanelObjects13= [];
gdjs.Start_32MenuCode.GDPanelObjects14= [];
gdjs.Start_32MenuCode.GDPanelObjects15= [];
gdjs.Start_32MenuCode.GDQuestionObjects1= [];
gdjs.Start_32MenuCode.GDQuestionObjects2= [];
gdjs.Start_32MenuCode.GDQuestionObjects3= [];
gdjs.Start_32MenuCode.GDQuestionObjects4= [];
gdjs.Start_32MenuCode.GDQuestionObjects5= [];
gdjs.Start_32MenuCode.GDQuestionObjects6= [];
gdjs.Start_32MenuCode.GDQuestionObjects7= [];
gdjs.Start_32MenuCode.GDQuestionObjects8= [];
gdjs.Start_32MenuCode.GDQuestionObjects9= [];
gdjs.Start_32MenuCode.GDQuestionObjects10= [];
gdjs.Start_32MenuCode.GDQuestionObjects11= [];
gdjs.Start_32MenuCode.GDQuestionObjects12= [];
gdjs.Start_32MenuCode.GDQuestionObjects13= [];
gdjs.Start_32MenuCode.GDQuestionObjects14= [];
gdjs.Start_32MenuCode.GDQuestionObjects15= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects1= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects2= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects3= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects4= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects5= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects6= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects7= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects8= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects9= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects10= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects11= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects12= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects13= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects14= [];
gdjs.Start_32MenuCode.GDName_9595inputObjects15= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects2= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects3= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects4= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects5= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects6= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects7= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects8= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects9= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects10= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects11= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects12= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects13= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects14= [];
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects15= [];
gdjs.Start_32MenuCode.GDTestObjects1= [];
gdjs.Start_32MenuCode.GDTestObjects2= [];
gdjs.Start_32MenuCode.GDTestObjects3= [];
gdjs.Start_32MenuCode.GDTestObjects4= [];
gdjs.Start_32MenuCode.GDTestObjects5= [];
gdjs.Start_32MenuCode.GDTestObjects6= [];
gdjs.Start_32MenuCode.GDTestObjects7= [];
gdjs.Start_32MenuCode.GDTestObjects8= [];
gdjs.Start_32MenuCode.GDTestObjects9= [];
gdjs.Start_32MenuCode.GDTestObjects10= [];
gdjs.Start_32MenuCode.GDTestObjects11= [];
gdjs.Start_32MenuCode.GDTestObjects12= [];
gdjs.Start_32MenuCode.GDTestObjects13= [];
gdjs.Start_32MenuCode.GDTestObjects14= [];
gdjs.Start_32MenuCode.GDTestObjects15= [];
gdjs.Start_32MenuCode.GDBackObjects1= [];
gdjs.Start_32MenuCode.GDBackObjects2= [];
gdjs.Start_32MenuCode.GDBackObjects3= [];
gdjs.Start_32MenuCode.GDBackObjects4= [];
gdjs.Start_32MenuCode.GDBackObjects5= [];
gdjs.Start_32MenuCode.GDBackObjects6= [];
gdjs.Start_32MenuCode.GDBackObjects7= [];
gdjs.Start_32MenuCode.GDBackObjects8= [];
gdjs.Start_32MenuCode.GDBackObjects9= [];
gdjs.Start_32MenuCode.GDBackObjects10= [];
gdjs.Start_32MenuCode.GDBackObjects11= [];
gdjs.Start_32MenuCode.GDBackObjects12= [];
gdjs.Start_32MenuCode.GDBackObjects13= [];
gdjs.Start_32MenuCode.GDBackObjects14= [];
gdjs.Start_32MenuCode.GDBackObjects15= [];
gdjs.Start_32MenuCode.GDLogoObjects1= [];
gdjs.Start_32MenuCode.GDLogoObjects2= [];
gdjs.Start_32MenuCode.GDLogoObjects3= [];
gdjs.Start_32MenuCode.GDLogoObjects4= [];
gdjs.Start_32MenuCode.GDLogoObjects5= [];
gdjs.Start_32MenuCode.GDLogoObjects6= [];
gdjs.Start_32MenuCode.GDLogoObjects7= [];
gdjs.Start_32MenuCode.GDLogoObjects8= [];
gdjs.Start_32MenuCode.GDLogoObjects9= [];
gdjs.Start_32MenuCode.GDLogoObjects10= [];
gdjs.Start_32MenuCode.GDLogoObjects11= [];
gdjs.Start_32MenuCode.GDLogoObjects12= [];
gdjs.Start_32MenuCode.GDLogoObjects13= [];
gdjs.Start_32MenuCode.GDLogoObjects14= [];
gdjs.Start_32MenuCode.GDLogoObjects15= [];
gdjs.Start_32MenuCode.GDPlayerObjects1= [];
gdjs.Start_32MenuCode.GDPlayerObjects2= [];
gdjs.Start_32MenuCode.GDPlayerObjects3= [];
gdjs.Start_32MenuCode.GDPlayerObjects4= [];
gdjs.Start_32MenuCode.GDPlayerObjects5= [];
gdjs.Start_32MenuCode.GDPlayerObjects6= [];
gdjs.Start_32MenuCode.GDPlayerObjects7= [];
gdjs.Start_32MenuCode.GDPlayerObjects8= [];
gdjs.Start_32MenuCode.GDPlayerObjects9= [];
gdjs.Start_32MenuCode.GDPlayerObjects10= [];
gdjs.Start_32MenuCode.GDPlayerObjects11= [];
gdjs.Start_32MenuCode.GDPlayerObjects12= [];
gdjs.Start_32MenuCode.GDPlayerObjects13= [];
gdjs.Start_32MenuCode.GDPlayerObjects14= [];
gdjs.Start_32MenuCode.GDPlayerObjects15= [];
gdjs.Start_32MenuCode.GDSlashObjects1= [];
gdjs.Start_32MenuCode.GDSlashObjects2= [];
gdjs.Start_32MenuCode.GDSlashObjects3= [];
gdjs.Start_32MenuCode.GDSlashObjects4= [];
gdjs.Start_32MenuCode.GDSlashObjects5= [];
gdjs.Start_32MenuCode.GDSlashObjects6= [];
gdjs.Start_32MenuCode.GDSlashObjects7= [];
gdjs.Start_32MenuCode.GDSlashObjects8= [];
gdjs.Start_32MenuCode.GDSlashObjects9= [];
gdjs.Start_32MenuCode.GDSlashObjects10= [];
gdjs.Start_32MenuCode.GDSlashObjects11= [];
gdjs.Start_32MenuCode.GDSlashObjects12= [];
gdjs.Start_32MenuCode.GDSlashObjects13= [];
gdjs.Start_32MenuCode.GDSlashObjects14= [];
gdjs.Start_32MenuCode.GDSlashObjects15= [];
gdjs.Start_32MenuCode.GDShadowObjects1= [];
gdjs.Start_32MenuCode.GDShadowObjects2= [];
gdjs.Start_32MenuCode.GDShadowObjects3= [];
gdjs.Start_32MenuCode.GDShadowObjects4= [];
gdjs.Start_32MenuCode.GDShadowObjects5= [];
gdjs.Start_32MenuCode.GDShadowObjects6= [];
gdjs.Start_32MenuCode.GDShadowObjects7= [];
gdjs.Start_32MenuCode.GDShadowObjects8= [];
gdjs.Start_32MenuCode.GDShadowObjects9= [];
gdjs.Start_32MenuCode.GDShadowObjects10= [];
gdjs.Start_32MenuCode.GDShadowObjects11= [];
gdjs.Start_32MenuCode.GDShadowObjects12= [];
gdjs.Start_32MenuCode.GDShadowObjects13= [];
gdjs.Start_32MenuCode.GDShadowObjects14= [];
gdjs.Start_32MenuCode.GDShadowObjects15= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects1= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects2= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects3= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects4= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects5= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects6= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects7= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects8= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects9= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects10= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects11= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects12= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects13= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects14= [];
gdjs.Start_32MenuCode.GDStatus_9595boxObjects15= [];
gdjs.Start_32MenuCode.GDHealthBarObjects1= [];
gdjs.Start_32MenuCode.GDHealthBarObjects2= [];
gdjs.Start_32MenuCode.GDHealthBarObjects3= [];
gdjs.Start_32MenuCode.GDHealthBarObjects4= [];
gdjs.Start_32MenuCode.GDHealthBarObjects5= [];
gdjs.Start_32MenuCode.GDHealthBarObjects6= [];
gdjs.Start_32MenuCode.GDHealthBarObjects7= [];
gdjs.Start_32MenuCode.GDHealthBarObjects8= [];
gdjs.Start_32MenuCode.GDHealthBarObjects9= [];
gdjs.Start_32MenuCode.GDHealthBarObjects10= [];
gdjs.Start_32MenuCode.GDHealthBarObjects11= [];
gdjs.Start_32MenuCode.GDHealthBarObjects12= [];
gdjs.Start_32MenuCode.GDHealthBarObjects13= [];
gdjs.Start_32MenuCode.GDHealthBarObjects14= [];
gdjs.Start_32MenuCode.GDHealthBarObjects15= [];
gdjs.Start_32MenuCode.GDTargetObjects1= [];
gdjs.Start_32MenuCode.GDTargetObjects2= [];
gdjs.Start_32MenuCode.GDTargetObjects3= [];
gdjs.Start_32MenuCode.GDTargetObjects4= [];
gdjs.Start_32MenuCode.GDTargetObjects5= [];
gdjs.Start_32MenuCode.GDTargetObjects6= [];
gdjs.Start_32MenuCode.GDTargetObjects7= [];
gdjs.Start_32MenuCode.GDTargetObjects8= [];
gdjs.Start_32MenuCode.GDTargetObjects9= [];
gdjs.Start_32MenuCode.GDTargetObjects10= [];
gdjs.Start_32MenuCode.GDTargetObjects11= [];
gdjs.Start_32MenuCode.GDTargetObjects12= [];
gdjs.Start_32MenuCode.GDTargetObjects13= [];
gdjs.Start_32MenuCode.GDTargetObjects14= [];
gdjs.Start_32MenuCode.GDTargetObjects15= [];
gdjs.Start_32MenuCode.GDHPObjects1= [];
gdjs.Start_32MenuCode.GDHPObjects2= [];
gdjs.Start_32MenuCode.GDHPObjects3= [];
gdjs.Start_32MenuCode.GDHPObjects4= [];
gdjs.Start_32MenuCode.GDHPObjects5= [];
gdjs.Start_32MenuCode.GDHPObjects6= [];
gdjs.Start_32MenuCode.GDHPObjects7= [];
gdjs.Start_32MenuCode.GDHPObjects8= [];
gdjs.Start_32MenuCode.GDHPObjects9= [];
gdjs.Start_32MenuCode.GDHPObjects10= [];
gdjs.Start_32MenuCode.GDHPObjects11= [];
gdjs.Start_32MenuCode.GDHPObjects12= [];
gdjs.Start_32MenuCode.GDHPObjects13= [];
gdjs.Start_32MenuCode.GDHPObjects14= [];
gdjs.Start_32MenuCode.GDHPObjects15= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects1= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects2= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects3= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects4= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects5= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects6= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects7= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects8= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects9= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects10= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects11= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects12= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects13= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects14= [];
gdjs.Start_32MenuCode.GDLevel_9595numberObjects15= [];
gdjs.Start_32MenuCode.GDplayernameObjects1= [];
gdjs.Start_32MenuCode.GDplayernameObjects2= [];
gdjs.Start_32MenuCode.GDplayernameObjects3= [];
gdjs.Start_32MenuCode.GDplayernameObjects4= [];
gdjs.Start_32MenuCode.GDplayernameObjects5= [];
gdjs.Start_32MenuCode.GDplayernameObjects6= [];
gdjs.Start_32MenuCode.GDplayernameObjects7= [];
gdjs.Start_32MenuCode.GDplayernameObjects8= [];
gdjs.Start_32MenuCode.GDplayernameObjects9= [];
gdjs.Start_32MenuCode.GDplayernameObjects10= [];
gdjs.Start_32MenuCode.GDplayernameObjects11= [];
gdjs.Start_32MenuCode.GDplayernameObjects12= [];
gdjs.Start_32MenuCode.GDplayernameObjects13= [];
gdjs.Start_32MenuCode.GDplayernameObjects14= [];
gdjs.Start_32MenuCode.GDplayernameObjects15= [];
gdjs.Start_32MenuCode.GDScreenObjects1= [];
gdjs.Start_32MenuCode.GDScreenObjects2= [];
gdjs.Start_32MenuCode.GDScreenObjects3= [];
gdjs.Start_32MenuCode.GDScreenObjects4= [];
gdjs.Start_32MenuCode.GDScreenObjects5= [];
gdjs.Start_32MenuCode.GDScreenObjects6= [];
gdjs.Start_32MenuCode.GDScreenObjects7= [];
gdjs.Start_32MenuCode.GDScreenObjects8= [];
gdjs.Start_32MenuCode.GDScreenObjects9= [];
gdjs.Start_32MenuCode.GDScreenObjects10= [];
gdjs.Start_32MenuCode.GDScreenObjects11= [];
gdjs.Start_32MenuCode.GDScreenObjects12= [];
gdjs.Start_32MenuCode.GDScreenObjects13= [];
gdjs.Start_32MenuCode.GDScreenObjects14= [];
gdjs.Start_32MenuCode.GDScreenObjects15= [];
gdjs.Start_32MenuCode.GDMenuObjects1= [];
gdjs.Start_32MenuCode.GDMenuObjects2= [];
gdjs.Start_32MenuCode.GDMenuObjects3= [];
gdjs.Start_32MenuCode.GDMenuObjects4= [];
gdjs.Start_32MenuCode.GDMenuObjects5= [];
gdjs.Start_32MenuCode.GDMenuObjects6= [];
gdjs.Start_32MenuCode.GDMenuObjects7= [];
gdjs.Start_32MenuCode.GDMenuObjects8= [];
gdjs.Start_32MenuCode.GDMenuObjects9= [];
gdjs.Start_32MenuCode.GDMenuObjects10= [];
gdjs.Start_32MenuCode.GDMenuObjects11= [];
gdjs.Start_32MenuCode.GDMenuObjects12= [];
gdjs.Start_32MenuCode.GDMenuObjects13= [];
gdjs.Start_32MenuCode.GDMenuObjects14= [];
gdjs.Start_32MenuCode.GDMenuObjects15= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects1= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects2= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects3= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects4= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects5= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects6= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects7= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects8= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects9= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects10= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects11= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects12= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects13= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects14= [];
gdjs.Start_32MenuCode.GDHealthemptyObjects15= [];
gdjs.Start_32MenuCode.GDPotionObjects1= [];
gdjs.Start_32MenuCode.GDPotionObjects2= [];
gdjs.Start_32MenuCode.GDPotionObjects3= [];
gdjs.Start_32MenuCode.GDPotionObjects4= [];
gdjs.Start_32MenuCode.GDPotionObjects5= [];
gdjs.Start_32MenuCode.GDPotionObjects6= [];
gdjs.Start_32MenuCode.GDPotionObjects7= [];
gdjs.Start_32MenuCode.GDPotionObjects8= [];
gdjs.Start_32MenuCode.GDPotionObjects9= [];
gdjs.Start_32MenuCode.GDPotionObjects10= [];
gdjs.Start_32MenuCode.GDPotionObjects11= [];
gdjs.Start_32MenuCode.GDPotionObjects12= [];
gdjs.Start_32MenuCode.GDPotionObjects13= [];
gdjs.Start_32MenuCode.GDPotionObjects14= [];
gdjs.Start_32MenuCode.GDPotionObjects15= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects1= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects2= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects3= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects4= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects5= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects6= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects7= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects8= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects9= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects10= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects11= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects12= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects13= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects14= [];
gdjs.Start_32MenuCode.GDPotion_9595boxObjects15= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects1= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects2= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects3= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects4= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects5= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects6= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects7= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects8= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects9= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects10= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects11= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects12= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects13= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects14= [];
gdjs.Start_32MenuCode.GDPotion_9595numberObjects15= [];
gdjs.Start_32MenuCode.GDTImerObjects1= [];
gdjs.Start_32MenuCode.GDTImerObjects2= [];
gdjs.Start_32MenuCode.GDTImerObjects3= [];
gdjs.Start_32MenuCode.GDTImerObjects4= [];
gdjs.Start_32MenuCode.GDTImerObjects5= [];
gdjs.Start_32MenuCode.GDTImerObjects6= [];
gdjs.Start_32MenuCode.GDTImerObjects7= [];
gdjs.Start_32MenuCode.GDTImerObjects8= [];
gdjs.Start_32MenuCode.GDTImerObjects9= [];
gdjs.Start_32MenuCode.GDTImerObjects10= [];
gdjs.Start_32MenuCode.GDTImerObjects11= [];
gdjs.Start_32MenuCode.GDTImerObjects12= [];
gdjs.Start_32MenuCode.GDTImerObjects13= [];
gdjs.Start_32MenuCode.GDTImerObjects14= [];
gdjs.Start_32MenuCode.GDTImerObjects15= [];
gdjs.Start_32MenuCode.GDKillcountObjects1= [];
gdjs.Start_32MenuCode.GDKillcountObjects2= [];
gdjs.Start_32MenuCode.GDKillcountObjects3= [];
gdjs.Start_32MenuCode.GDKillcountObjects4= [];
gdjs.Start_32MenuCode.GDKillcountObjects5= [];
gdjs.Start_32MenuCode.GDKillcountObjects6= [];
gdjs.Start_32MenuCode.GDKillcountObjects7= [];
gdjs.Start_32MenuCode.GDKillcountObjects8= [];
gdjs.Start_32MenuCode.GDKillcountObjects9= [];
gdjs.Start_32MenuCode.GDKillcountObjects10= [];
gdjs.Start_32MenuCode.GDKillcountObjects11= [];
gdjs.Start_32MenuCode.GDKillcountObjects12= [];
gdjs.Start_32MenuCode.GDKillcountObjects13= [];
gdjs.Start_32MenuCode.GDKillcountObjects14= [];
gdjs.Start_32MenuCode.GDKillcountObjects15= [];


gdjs.Start_32MenuCode.asyncCallback17907268 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}}
gdjs.Start_32MenuCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/saveindex", "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17907268(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17925844 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(0);
}}
gdjs.Start_32MenuCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/delete", "/", "DELETE", "name", gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17925844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17927188 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Start_32MenuCode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/leaderboard/logsave", "/", "PATCH", "name", gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17927188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17931748 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Area1.1", false);
}{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(1);
}}
gdjs.Start_32MenuCode.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17931748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Start_32MenuCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Start_32MenuCode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(2));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(8));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(3));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(14));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(5).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(15));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(6).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(16));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(11).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(23));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(8).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(19));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(18));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(17));
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Start_32MenuCode.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Start_32MenuCode.asyncCallback17925188 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList5 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/second/0", "/", "PATCH", "name", runtimeScene.getScene().getVariables().getFromIndex(9), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17925188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17924540 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList5(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/minute/0", "/", "PATCH", "name", runtimeScene.getScene().getVariables().getFromIndex(10), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17924540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17923444 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/hour/0", "/", "PATCH", "name", runtimeScene.getScene().getVariables().getFromIndex(8), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17923444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17923108 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/kcount/0", "/", "PATCH", "name", runtimeScene.getScene().getVariables().getFromIndex(11), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17923108(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17922500 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/potion/0", "/", "PATCH", "name", runtimeScene.getScene().getVariables().getFromIndex(6), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17922500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17920964 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/mkey/0", "/", "PATCH", "name", runtimeScene.getScene().getVariables().getFromIndex(5), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17920964(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17920180 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList11 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/key/0", "/", "PATCH", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17920180(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17919804 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList11(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/player_exp/0", "/", "PATCH", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17919804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17919116 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/player_level/1", "/", "PATCH", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17919116(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17918132 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Name_input"), gdjs.Start_32MenuCode.GDName_9595inputObjects1);

{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/newgame/player_name/" + (( gdjs.Start_32MenuCode.GDName_9595inputObjects1.length === 0 ) ? "" :gdjs.Start_32MenuCode.GDName_9595inputObjects1[0].getBehavior("Text").getText()), "/", "PATCH", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17918132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17870684 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Area1.1", false);
}}
gdjs.Start_32MenuCode.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17870684(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17922956 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Area1.2", false);
}}
gdjs.Start_32MenuCode.eventsList16 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17922956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17925100 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Area1.3", false);
}}
gdjs.Start_32MenuCode.eventsList17 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17925100(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.eventsList18 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) == 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) == 2;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList16(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) == 3;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList17(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Start_32MenuCode.asyncCallback17772396 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(2));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(3));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(8));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(7).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(11));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(14));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(5).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(15));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(6).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(16));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(11).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(23));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(17));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(18));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(8).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(19));
}
{ //Subevents
gdjs.Start_32MenuCode.eventsList18(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList19 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/continue/second/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(9), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17772396(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17770236 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList19(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList20 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/continue/minute/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(10), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17770236(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17771876 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList20(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList21 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/continue/hour/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(8), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17771876(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17770972 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList21(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList22 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/continue/kcount/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(11), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17770972(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17893572 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList22(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList23 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/continue/potion/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(6), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17893572(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback11946188 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList23(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList24 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/continue/mkey/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(5), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback11946188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17926628 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList24(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/continue/key/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17926628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17929980 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/continue/player_exp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17929980(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17936492 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/continue/area_level/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(7), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17936492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17935084 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList28 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/continue/player_level/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17935084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17933668 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList28(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList29 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/savedata/continue/player_name/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17933668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.asyncCallback17932884 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList29(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Start_32MenuCode.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/leaderboard/logsave", "/", "PATCH", "name", gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32MenuCode.asyncCallback17932884(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32MenuCode.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseInsideCanvas(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Start_32MenuCode.GDTargetObjects1);
{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDTargetObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDTargetObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Continue"), gdjs.Start_32MenuCode.GDContinueObjects1);
{for(var i = 0, len = gdjs.Start_32MenuCode.GDContinueObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDContinueObjects1[i].activateBehavior("ButtonFSM", false);
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDContinueObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDContinueObjects1[i].activateBehavior("ButtonObjectEffects", false);
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDContinueObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDContinueObjects1[i].setColor("153;153;153");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10)) >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Continue"), gdjs.Start_32MenuCode.GDContinueObjects1);
{for(var i = 0, len = gdjs.Start_32MenuCode.GDContinueObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDContinueObjects1[i].activateBehavior("ButtonFSM", true);
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDContinueObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDContinueObjects1[i].activateBehavior("ButtonObjectEffects", true);
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDContinueObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDContinueObjects1[i].setColor("0;0;0");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("New_game"), gdjs.Start_32MenuCode.GDNew_9595gameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Start_32MenuCode.GDNew_9595gameObjects1.length;i<l;++i) {
    if ( gdjs.Start_32MenuCode.GDNew_9595gameObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Start_32MenuCode.GDNew_9595gameObjects1[k] = gdjs.Start_32MenuCode.GDNew_9595gameObjects1[i];
        ++k;
    }
}
gdjs.Start_32MenuCode.GDNew_9595gameObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Start_32MenuCode.GDBackObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enter_button"), gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Name_input"), gdjs.Start_32MenuCode.GDName_9595inputObjects1);
gdjs.copyArray(runtimeScene.getObjects("Panel"), gdjs.Start_32MenuCode.GDPanelObjects1);
gdjs.copyArray(runtimeScene.getObjects("Question"), gdjs.Start_32MenuCode.GDQuestionObjects1);
{for(var i = 0, len = gdjs.Start_32MenuCode.GDPanelObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDPanelObjects1[i].setPosition(0,0);
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDQuestionObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDQuestionObjects1[i].setPosition((( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointX("question")),(( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointY("question")));
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDName_9595inputObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDName_9595inputObjects1[i].setPosition((( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointX("input")),(( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointY("input")));
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1[i].setPosition((( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointX("enter")),(( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointY("enter")));
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDBackObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDBackObjects1[i].setPosition((( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointX("back")),(( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointY("back")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Start_32MenuCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Start_32MenuCode.GDBackObjects1.length;i<l;++i) {
    if ( gdjs.Start_32MenuCode.GDBackObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Start_32MenuCode.GDBackObjects1[k] = gdjs.Start_32MenuCode.GDBackObjects1[i];
        ++k;
    }
}
gdjs.Start_32MenuCode.GDBackObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Start_32MenuCode.GDBackObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Enter_button"), gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Name_input"), gdjs.Start_32MenuCode.GDName_9595inputObjects1);
gdjs.copyArray(runtimeScene.getObjects("Panel"), gdjs.Start_32MenuCode.GDPanelObjects1);
gdjs.copyArray(runtimeScene.getObjects("Question"), gdjs.Start_32MenuCode.GDQuestionObjects1);
{for(var i = 0, len = gdjs.Start_32MenuCode.GDPanelObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDPanelObjects1[i].setPosition(0,1280);
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDBackObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDBackObjects1[i].setPosition((( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointX("back")),(( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointY("back")));
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1[i].setPosition((( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointX("enter")),(( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointY("enter")));
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDName_9595inputObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDName_9595inputObjects1[i].setPosition((( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointX("input")),(( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointY("input")));
}
}{for(var i = 0, len = gdjs.Start_32MenuCode.GDQuestionObjects1.length ;i < len;++i) {
    gdjs.Start_32MenuCode.GDQuestionObjects1[i].setPosition((( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointX("question")),(( gdjs.Start_32MenuCode.GDPanelObjects1.length === 0 ) ? 0 :gdjs.Start_32MenuCode.GDPanelObjects1[0].getPointY("question")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enter_button"), gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1.length;i<l;++i) {
    if ( gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1[k] = gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1[i];
        ++k;
    }
}
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Continue"), gdjs.Start_32MenuCode.GDContinueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Start_32MenuCode.GDContinueObjects1.length;i<l;++i) {
    if ( gdjs.Start_32MenuCode.GDContinueObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Start_32MenuCode.GDContinueObjects1[k] = gdjs.Start_32MenuCode.GDContinueObjects1[i];
        ++k;
    }
}
gdjs.Start_32MenuCode.GDContinueObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Start_32MenuCode.eventsList30(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Credits"), gdjs.Start_32MenuCode.GDCreditsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Start_32MenuCode.GDCreditsObjects1.length;i<l;++i) {
    if ( gdjs.Start_32MenuCode.GDCreditsObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Start_32MenuCode.GDCreditsObjects1[k] = gdjs.Start_32MenuCode.GDCreditsObjects1[i];
        ++k;
    }
}
gdjs.Start_32MenuCode.GDCreditsObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Credits");
}}

}


};

gdjs.Start_32MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Start_32MenuCode.GDTitlesObjects1.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects2.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects3.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects4.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects5.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects6.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects7.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects8.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects9.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects10.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects11.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects12.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects13.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects14.length = 0;
gdjs.Start_32MenuCode.GDTitlesObjects15.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects1.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects2.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects3.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects4.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects5.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects6.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects7.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects8.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects9.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects10.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects11.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects12.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects13.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects14.length = 0;
gdjs.Start_32MenuCode.GDNew_9595gameObjects15.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects1.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects2.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects3.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects4.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects5.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects6.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects7.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects8.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects9.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects10.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects11.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects12.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects13.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects14.length = 0;
gdjs.Start_32MenuCode.GDContinueObjects15.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects1.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects2.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects3.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects4.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects5.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects6.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects7.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects8.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects9.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects10.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects11.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects12.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects13.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects14.length = 0;
gdjs.Start_32MenuCode.GDExit_9595gameObjects15.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects1.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects2.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects3.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects4.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects5.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects6.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects7.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects8.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects9.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects10.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects11.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects12.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects13.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects14.length = 0;
gdjs.Start_32MenuCode.GDCreditsObjects15.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects1.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects2.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects3.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects4.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects5.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects6.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects7.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects8.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects9.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects10.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects11.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects12.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects13.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects14.length = 0;
gdjs.Start_32MenuCode.GDPanelObjects15.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects1.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects2.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects3.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects4.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects5.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects6.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects7.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects8.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects9.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects10.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects11.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects12.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects13.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects14.length = 0;
gdjs.Start_32MenuCode.GDQuestionObjects15.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects1.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects2.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects3.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects4.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects5.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects6.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects7.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects8.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects9.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects10.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects11.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects12.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects13.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects14.length = 0;
gdjs.Start_32MenuCode.GDName_9595inputObjects15.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects1.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects2.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects3.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects4.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects5.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects6.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects7.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects8.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects9.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects10.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects11.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects12.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects13.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects14.length = 0;
gdjs.Start_32MenuCode.GDEnter_9595buttonObjects15.length = 0;
gdjs.Start_32MenuCode.GDTestObjects1.length = 0;
gdjs.Start_32MenuCode.GDTestObjects2.length = 0;
gdjs.Start_32MenuCode.GDTestObjects3.length = 0;
gdjs.Start_32MenuCode.GDTestObjects4.length = 0;
gdjs.Start_32MenuCode.GDTestObjects5.length = 0;
gdjs.Start_32MenuCode.GDTestObjects6.length = 0;
gdjs.Start_32MenuCode.GDTestObjects7.length = 0;
gdjs.Start_32MenuCode.GDTestObjects8.length = 0;
gdjs.Start_32MenuCode.GDTestObjects9.length = 0;
gdjs.Start_32MenuCode.GDTestObjects10.length = 0;
gdjs.Start_32MenuCode.GDTestObjects11.length = 0;
gdjs.Start_32MenuCode.GDTestObjects12.length = 0;
gdjs.Start_32MenuCode.GDTestObjects13.length = 0;
gdjs.Start_32MenuCode.GDTestObjects14.length = 0;
gdjs.Start_32MenuCode.GDTestObjects15.length = 0;
gdjs.Start_32MenuCode.GDBackObjects1.length = 0;
gdjs.Start_32MenuCode.GDBackObjects2.length = 0;
gdjs.Start_32MenuCode.GDBackObjects3.length = 0;
gdjs.Start_32MenuCode.GDBackObjects4.length = 0;
gdjs.Start_32MenuCode.GDBackObjects5.length = 0;
gdjs.Start_32MenuCode.GDBackObjects6.length = 0;
gdjs.Start_32MenuCode.GDBackObjects7.length = 0;
gdjs.Start_32MenuCode.GDBackObjects8.length = 0;
gdjs.Start_32MenuCode.GDBackObjects9.length = 0;
gdjs.Start_32MenuCode.GDBackObjects10.length = 0;
gdjs.Start_32MenuCode.GDBackObjects11.length = 0;
gdjs.Start_32MenuCode.GDBackObjects12.length = 0;
gdjs.Start_32MenuCode.GDBackObjects13.length = 0;
gdjs.Start_32MenuCode.GDBackObjects14.length = 0;
gdjs.Start_32MenuCode.GDBackObjects15.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects1.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects2.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects3.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects4.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects5.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects6.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects7.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects8.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects9.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects10.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects11.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects12.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects13.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects14.length = 0;
gdjs.Start_32MenuCode.GDLogoObjects15.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects1.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects2.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects3.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects4.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects5.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects6.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects7.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects8.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects9.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects10.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects11.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects12.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects13.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects14.length = 0;
gdjs.Start_32MenuCode.GDPlayerObjects15.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects1.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects2.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects3.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects4.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects5.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects6.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects7.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects8.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects9.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects10.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects11.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects12.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects13.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects14.length = 0;
gdjs.Start_32MenuCode.GDSlashObjects15.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects1.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects2.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects3.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects4.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects5.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects6.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects7.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects8.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects9.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects10.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects11.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects12.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects13.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects14.length = 0;
gdjs.Start_32MenuCode.GDShadowObjects15.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects1.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects2.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects3.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects4.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects5.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects6.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects7.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects8.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects9.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects10.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects11.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects12.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects13.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects14.length = 0;
gdjs.Start_32MenuCode.GDStatus_9595boxObjects15.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects1.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects2.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects3.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects4.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects5.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects6.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects7.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects8.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects9.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects10.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects11.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects12.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects13.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects14.length = 0;
gdjs.Start_32MenuCode.GDHealthBarObjects15.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects1.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects2.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects3.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects4.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects5.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects6.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects7.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects8.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects9.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects10.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects11.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects12.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects13.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects14.length = 0;
gdjs.Start_32MenuCode.GDTargetObjects15.length = 0;
gdjs.Start_32MenuCode.GDHPObjects1.length = 0;
gdjs.Start_32MenuCode.GDHPObjects2.length = 0;
gdjs.Start_32MenuCode.GDHPObjects3.length = 0;
gdjs.Start_32MenuCode.GDHPObjects4.length = 0;
gdjs.Start_32MenuCode.GDHPObjects5.length = 0;
gdjs.Start_32MenuCode.GDHPObjects6.length = 0;
gdjs.Start_32MenuCode.GDHPObjects7.length = 0;
gdjs.Start_32MenuCode.GDHPObjects8.length = 0;
gdjs.Start_32MenuCode.GDHPObjects9.length = 0;
gdjs.Start_32MenuCode.GDHPObjects10.length = 0;
gdjs.Start_32MenuCode.GDHPObjects11.length = 0;
gdjs.Start_32MenuCode.GDHPObjects12.length = 0;
gdjs.Start_32MenuCode.GDHPObjects13.length = 0;
gdjs.Start_32MenuCode.GDHPObjects14.length = 0;
gdjs.Start_32MenuCode.GDHPObjects15.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects1.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects2.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects3.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects4.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects5.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects6.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects7.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects8.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects9.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects10.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects11.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects12.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects13.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects14.length = 0;
gdjs.Start_32MenuCode.GDLevel_9595numberObjects15.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects1.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects2.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects3.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects4.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects5.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects6.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects7.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects8.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects9.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects10.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects11.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects12.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects13.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects14.length = 0;
gdjs.Start_32MenuCode.GDplayernameObjects15.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects1.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects2.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects3.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects4.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects5.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects6.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects7.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects8.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects9.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects10.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects11.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects12.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects13.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects14.length = 0;
gdjs.Start_32MenuCode.GDScreenObjects15.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects1.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects2.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects3.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects4.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects5.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects6.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects7.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects8.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects9.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects10.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects11.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects12.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects13.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects14.length = 0;
gdjs.Start_32MenuCode.GDMenuObjects15.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects1.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects2.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects3.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects4.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects5.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects6.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects7.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects8.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects9.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects10.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects11.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects12.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects13.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects14.length = 0;
gdjs.Start_32MenuCode.GDHealthemptyObjects15.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects1.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects2.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects3.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects4.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects5.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects6.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects7.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects8.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects9.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects10.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects11.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects12.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects13.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects14.length = 0;
gdjs.Start_32MenuCode.GDPotionObjects15.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects1.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects2.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects3.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects4.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects5.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects6.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects7.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects8.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects9.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects10.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects11.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects12.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects13.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects14.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595boxObjects15.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects1.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects2.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects3.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects4.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects5.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects6.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects7.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects8.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects9.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects10.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects11.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects12.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects13.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects14.length = 0;
gdjs.Start_32MenuCode.GDPotion_9595numberObjects15.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects1.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects2.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects3.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects4.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects5.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects6.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects7.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects8.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects9.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects10.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects11.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects12.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects13.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects14.length = 0;
gdjs.Start_32MenuCode.GDTImerObjects15.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects1.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects2.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects3.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects4.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects5.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects6.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects7.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects8.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects9.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects10.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects11.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects12.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects13.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects14.length = 0;
gdjs.Start_32MenuCode.GDKillcountObjects15.length = 0;

gdjs.Start_32MenuCode.eventsList31(runtimeScene);

return;

}

gdjs['Start_32MenuCode'] = gdjs.Start_32MenuCode;
