gdjs.Area1_462Code = {};
gdjs.Area1_462Code.GDKing_9595Slime2Objects2_1final = [];

gdjs.Area1_462Code.GDKing_9595Slime2Objects3_1final = [];

gdjs.Area1_462Code.GDKing_9595SlimeObjects2_1final = [];

gdjs.Area1_462Code.GDKing_9595SlimeObjects3_1final = [];

gdjs.Area1_462Code.GDMenuObjects2_1final = [];

gdjs.Area1_462Code.GDPlayerObjects2_1final = [];

gdjs.Area1_462Code.GDPlayerObjects3_1final = [];

gdjs.Area1_462Code.GDPotion_9595boxObjects2_1final = [];

gdjs.Area1_462Code.forEachIndex3 = 0;

gdjs.Area1_462Code.forEachIndex4 = 0;

gdjs.Area1_462Code.forEachObjects3 = [];

gdjs.Area1_462Code.forEachObjects4 = [];

gdjs.Area1_462Code.forEachTemporary3 = null;

gdjs.Area1_462Code.forEachTemporary4 = null;

gdjs.Area1_462Code.forEachTotalCount3 = 0;

gdjs.Area1_462Code.forEachTotalCount4 = 0;

gdjs.Area1_462Code.GDFloorObjects1= [];
gdjs.Area1_462Code.GDFloorObjects2= [];
gdjs.Area1_462Code.GDFloorObjects3= [];
gdjs.Area1_462Code.GDFloorObjects4= [];
gdjs.Area1_462Code.GDFloorObjects5= [];
gdjs.Area1_462Code.GDFloorObjects6= [];
gdjs.Area1_462Code.GDFloorObjects7= [];
gdjs.Area1_462Code.GDFloorObjects8= [];
gdjs.Area1_462Code.GDFloorObjects9= [];
gdjs.Area1_462Code.GDWall_9595HorizontalObjects1= [];
gdjs.Area1_462Code.GDWall_9595HorizontalObjects2= [];
gdjs.Area1_462Code.GDWall_9595HorizontalObjects3= [];
gdjs.Area1_462Code.GDWall_9595HorizontalObjects4= [];
gdjs.Area1_462Code.GDWall_9595HorizontalObjects5= [];
gdjs.Area1_462Code.GDWall_9595HorizontalObjects6= [];
gdjs.Area1_462Code.GDWall_9595HorizontalObjects7= [];
gdjs.Area1_462Code.GDWall_9595HorizontalObjects8= [];
gdjs.Area1_462Code.GDWall_9595HorizontalObjects9= [];
gdjs.Area1_462Code.GDWall_9595verticalObjects1= [];
gdjs.Area1_462Code.GDWall_9595verticalObjects2= [];
gdjs.Area1_462Code.GDWall_9595verticalObjects3= [];
gdjs.Area1_462Code.GDWall_9595verticalObjects4= [];
gdjs.Area1_462Code.GDWall_9595verticalObjects5= [];
gdjs.Area1_462Code.GDWall_9595verticalObjects6= [];
gdjs.Area1_462Code.GDWall_9595verticalObjects7= [];
gdjs.Area1_462Code.GDWall_9595verticalObjects8= [];
gdjs.Area1_462Code.GDWall_9595verticalObjects9= [];
gdjs.Area1_462Code.GDBarrierObjects1= [];
gdjs.Area1_462Code.GDBarrierObjects2= [];
gdjs.Area1_462Code.GDBarrierObjects3= [];
gdjs.Area1_462Code.GDBarrierObjects4= [];
gdjs.Area1_462Code.GDBarrierObjects5= [];
gdjs.Area1_462Code.GDBarrierObjects6= [];
gdjs.Area1_462Code.GDBarrierObjects7= [];
gdjs.Area1_462Code.GDBarrierObjects8= [];
gdjs.Area1_462Code.GDBarrierObjects9= [];
gdjs.Area1_462Code.GDCollision_9595MaskObjects1= [];
gdjs.Area1_462Code.GDCollision_9595MaskObjects2= [];
gdjs.Area1_462Code.GDCollision_9595MaskObjects3= [];
gdjs.Area1_462Code.GDCollision_9595MaskObjects4= [];
gdjs.Area1_462Code.GDCollision_9595MaskObjects5= [];
gdjs.Area1_462Code.GDCollision_9595MaskObjects6= [];
gdjs.Area1_462Code.GDCollision_9595MaskObjects7= [];
gdjs.Area1_462Code.GDCollision_9595MaskObjects8= [];
gdjs.Area1_462Code.GDCollision_9595MaskObjects9= [];
gdjs.Area1_462Code.GDKing_9595SlimeObjects1= [];
gdjs.Area1_462Code.GDKing_9595SlimeObjects2= [];
gdjs.Area1_462Code.GDKing_9595SlimeObjects3= [];
gdjs.Area1_462Code.GDKing_9595SlimeObjects4= [];
gdjs.Area1_462Code.GDKing_9595SlimeObjects5= [];
gdjs.Area1_462Code.GDKing_9595SlimeObjects6= [];
gdjs.Area1_462Code.GDKing_9595SlimeObjects7= [];
gdjs.Area1_462Code.GDKing_9595SlimeObjects8= [];
gdjs.Area1_462Code.GDKing_9595SlimeObjects9= [];
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects1= [];
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects2= [];
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects3= [];
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4= [];
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5= [];
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects6= [];
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects7= [];
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects8= [];
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects9= [];
gdjs.Area1_462Code.GDKing_9595Slime2Objects1= [];
gdjs.Area1_462Code.GDKing_9595Slime2Objects2= [];
gdjs.Area1_462Code.GDKing_9595Slime2Objects3= [];
gdjs.Area1_462Code.GDKing_9595Slime2Objects4= [];
gdjs.Area1_462Code.GDKing_9595Slime2Objects5= [];
gdjs.Area1_462Code.GDKing_9595Slime2Objects6= [];
gdjs.Area1_462Code.GDKing_9595Slime2Objects7= [];
gdjs.Area1_462Code.GDKing_9595Slime2Objects8= [];
gdjs.Area1_462Code.GDKing_9595Slime2Objects9= [];
gdjs.Area1_462Code.GDBarrier2Objects1= [];
gdjs.Area1_462Code.GDBarrier2Objects2= [];
gdjs.Area1_462Code.GDBarrier2Objects3= [];
gdjs.Area1_462Code.GDBarrier2Objects4= [];
gdjs.Area1_462Code.GDBarrier2Objects5= [];
gdjs.Area1_462Code.GDBarrier2Objects6= [];
gdjs.Area1_462Code.GDBarrier2Objects7= [];
gdjs.Area1_462Code.GDBarrier2Objects8= [];
gdjs.Area1_462Code.GDBarrier2Objects9= [];
gdjs.Area1_462Code.GDCollision_9595Mask2Objects1= [];
gdjs.Area1_462Code.GDCollision_9595Mask2Objects2= [];
gdjs.Area1_462Code.GDCollision_9595Mask2Objects3= [];
gdjs.Area1_462Code.GDCollision_9595Mask2Objects4= [];
gdjs.Area1_462Code.GDCollision_9595Mask2Objects5= [];
gdjs.Area1_462Code.GDCollision_9595Mask2Objects6= [];
gdjs.Area1_462Code.GDCollision_9595Mask2Objects7= [];
gdjs.Area1_462Code.GDCollision_9595Mask2Objects8= [];
gdjs.Area1_462Code.GDCollision_9595Mask2Objects9= [];
gdjs.Area1_462Code.GDStaircaseObjects1= [];
gdjs.Area1_462Code.GDStaircaseObjects2= [];
gdjs.Area1_462Code.GDStaircaseObjects3= [];
gdjs.Area1_462Code.GDStaircaseObjects4= [];
gdjs.Area1_462Code.GDStaircaseObjects5= [];
gdjs.Area1_462Code.GDStaircaseObjects6= [];
gdjs.Area1_462Code.GDStaircaseObjects7= [];
gdjs.Area1_462Code.GDStaircaseObjects8= [];
gdjs.Area1_462Code.GDStaircaseObjects9= [];
gdjs.Area1_462Code.GDTESTObjects1= [];
gdjs.Area1_462Code.GDTESTObjects2= [];
gdjs.Area1_462Code.GDTESTObjects3= [];
gdjs.Area1_462Code.GDTESTObjects4= [];
gdjs.Area1_462Code.GDTESTObjects5= [];
gdjs.Area1_462Code.GDTESTObjects6= [];
gdjs.Area1_462Code.GDTESTObjects7= [];
gdjs.Area1_462Code.GDTESTObjects8= [];
gdjs.Area1_462Code.GDTESTObjects9= [];
gdjs.Area1_462Code.GDPlayerObjects1= [];
gdjs.Area1_462Code.GDPlayerObjects2= [];
gdjs.Area1_462Code.GDPlayerObjects3= [];
gdjs.Area1_462Code.GDPlayerObjects4= [];
gdjs.Area1_462Code.GDPlayerObjects5= [];
gdjs.Area1_462Code.GDPlayerObjects6= [];
gdjs.Area1_462Code.GDPlayerObjects7= [];
gdjs.Area1_462Code.GDPlayerObjects8= [];
gdjs.Area1_462Code.GDPlayerObjects9= [];
gdjs.Area1_462Code.GDSlashObjects1= [];
gdjs.Area1_462Code.GDSlashObjects2= [];
gdjs.Area1_462Code.GDSlashObjects3= [];
gdjs.Area1_462Code.GDSlashObjects4= [];
gdjs.Area1_462Code.GDSlashObjects5= [];
gdjs.Area1_462Code.GDSlashObjects6= [];
gdjs.Area1_462Code.GDSlashObjects7= [];
gdjs.Area1_462Code.GDSlashObjects8= [];
gdjs.Area1_462Code.GDSlashObjects9= [];
gdjs.Area1_462Code.GDShadowObjects1= [];
gdjs.Area1_462Code.GDShadowObjects2= [];
gdjs.Area1_462Code.GDShadowObjects3= [];
gdjs.Area1_462Code.GDShadowObjects4= [];
gdjs.Area1_462Code.GDShadowObjects5= [];
gdjs.Area1_462Code.GDShadowObjects6= [];
gdjs.Area1_462Code.GDShadowObjects7= [];
gdjs.Area1_462Code.GDShadowObjects8= [];
gdjs.Area1_462Code.GDShadowObjects9= [];
gdjs.Area1_462Code.GDStatus_9595boxObjects1= [];
gdjs.Area1_462Code.GDStatus_9595boxObjects2= [];
gdjs.Area1_462Code.GDStatus_9595boxObjects3= [];
gdjs.Area1_462Code.GDStatus_9595boxObjects4= [];
gdjs.Area1_462Code.GDStatus_9595boxObjects5= [];
gdjs.Area1_462Code.GDStatus_9595boxObjects6= [];
gdjs.Area1_462Code.GDStatus_9595boxObjects7= [];
gdjs.Area1_462Code.GDStatus_9595boxObjects8= [];
gdjs.Area1_462Code.GDStatus_9595boxObjects9= [];
gdjs.Area1_462Code.GDHealthBarObjects1= [];
gdjs.Area1_462Code.GDHealthBarObjects2= [];
gdjs.Area1_462Code.GDHealthBarObjects3= [];
gdjs.Area1_462Code.GDHealthBarObjects4= [];
gdjs.Area1_462Code.GDHealthBarObjects5= [];
gdjs.Area1_462Code.GDHealthBarObjects6= [];
gdjs.Area1_462Code.GDHealthBarObjects7= [];
gdjs.Area1_462Code.GDHealthBarObjects8= [];
gdjs.Area1_462Code.GDHealthBarObjects9= [];
gdjs.Area1_462Code.GDTargetObjects1= [];
gdjs.Area1_462Code.GDTargetObjects2= [];
gdjs.Area1_462Code.GDTargetObjects3= [];
gdjs.Area1_462Code.GDTargetObjects4= [];
gdjs.Area1_462Code.GDTargetObjects5= [];
gdjs.Area1_462Code.GDTargetObjects6= [];
gdjs.Area1_462Code.GDTargetObjects7= [];
gdjs.Area1_462Code.GDTargetObjects8= [];
gdjs.Area1_462Code.GDTargetObjects9= [];
gdjs.Area1_462Code.GDHPObjects1= [];
gdjs.Area1_462Code.GDHPObjects2= [];
gdjs.Area1_462Code.GDHPObjects3= [];
gdjs.Area1_462Code.GDHPObjects4= [];
gdjs.Area1_462Code.GDHPObjects5= [];
gdjs.Area1_462Code.GDHPObjects6= [];
gdjs.Area1_462Code.GDHPObjects7= [];
gdjs.Area1_462Code.GDHPObjects8= [];
gdjs.Area1_462Code.GDHPObjects9= [];
gdjs.Area1_462Code.GDLevel_9595numberObjects1= [];
gdjs.Area1_462Code.GDLevel_9595numberObjects2= [];
gdjs.Area1_462Code.GDLevel_9595numberObjects3= [];
gdjs.Area1_462Code.GDLevel_9595numberObjects4= [];
gdjs.Area1_462Code.GDLevel_9595numberObjects5= [];
gdjs.Area1_462Code.GDLevel_9595numberObjects6= [];
gdjs.Area1_462Code.GDLevel_9595numberObjects7= [];
gdjs.Area1_462Code.GDLevel_9595numberObjects8= [];
gdjs.Area1_462Code.GDLevel_9595numberObjects9= [];
gdjs.Area1_462Code.GDplayernameObjects1= [];
gdjs.Area1_462Code.GDplayernameObjects2= [];
gdjs.Area1_462Code.GDplayernameObjects3= [];
gdjs.Area1_462Code.GDplayernameObjects4= [];
gdjs.Area1_462Code.GDplayernameObjects5= [];
gdjs.Area1_462Code.GDplayernameObjects6= [];
gdjs.Area1_462Code.GDplayernameObjects7= [];
gdjs.Area1_462Code.GDplayernameObjects8= [];
gdjs.Area1_462Code.GDplayernameObjects9= [];
gdjs.Area1_462Code.GDScreenObjects1= [];
gdjs.Area1_462Code.GDScreenObjects2= [];
gdjs.Area1_462Code.GDScreenObjects3= [];
gdjs.Area1_462Code.GDScreenObjects4= [];
gdjs.Area1_462Code.GDScreenObjects5= [];
gdjs.Area1_462Code.GDScreenObjects6= [];
gdjs.Area1_462Code.GDScreenObjects7= [];
gdjs.Area1_462Code.GDScreenObjects8= [];
gdjs.Area1_462Code.GDScreenObjects9= [];
gdjs.Area1_462Code.GDMenuObjects1= [];
gdjs.Area1_462Code.GDMenuObjects2= [];
gdjs.Area1_462Code.GDMenuObjects3= [];
gdjs.Area1_462Code.GDMenuObjects4= [];
gdjs.Area1_462Code.GDMenuObjects5= [];
gdjs.Area1_462Code.GDMenuObjects6= [];
gdjs.Area1_462Code.GDMenuObjects7= [];
gdjs.Area1_462Code.GDMenuObjects8= [];
gdjs.Area1_462Code.GDMenuObjects9= [];
gdjs.Area1_462Code.GDHealthemptyObjects1= [];
gdjs.Area1_462Code.GDHealthemptyObjects2= [];
gdjs.Area1_462Code.GDHealthemptyObjects3= [];
gdjs.Area1_462Code.GDHealthemptyObjects4= [];
gdjs.Area1_462Code.GDHealthemptyObjects5= [];
gdjs.Area1_462Code.GDHealthemptyObjects6= [];
gdjs.Area1_462Code.GDHealthemptyObjects7= [];
gdjs.Area1_462Code.GDHealthemptyObjects8= [];
gdjs.Area1_462Code.GDHealthemptyObjects9= [];
gdjs.Area1_462Code.GDPotionObjects1= [];
gdjs.Area1_462Code.GDPotionObjects2= [];
gdjs.Area1_462Code.GDPotionObjects3= [];
gdjs.Area1_462Code.GDPotionObjects4= [];
gdjs.Area1_462Code.GDPotionObjects5= [];
gdjs.Area1_462Code.GDPotionObjects6= [];
gdjs.Area1_462Code.GDPotionObjects7= [];
gdjs.Area1_462Code.GDPotionObjects8= [];
gdjs.Area1_462Code.GDPotionObjects9= [];
gdjs.Area1_462Code.GDPotion_9595boxObjects1= [];
gdjs.Area1_462Code.GDPotion_9595boxObjects2= [];
gdjs.Area1_462Code.GDPotion_9595boxObjects3= [];
gdjs.Area1_462Code.GDPotion_9595boxObjects4= [];
gdjs.Area1_462Code.GDPotion_9595boxObjects5= [];
gdjs.Area1_462Code.GDPotion_9595boxObjects6= [];
gdjs.Area1_462Code.GDPotion_9595boxObjects7= [];
gdjs.Area1_462Code.GDPotion_9595boxObjects8= [];
gdjs.Area1_462Code.GDPotion_9595boxObjects9= [];
gdjs.Area1_462Code.GDPotion_9595numberObjects1= [];
gdjs.Area1_462Code.GDPotion_9595numberObjects2= [];
gdjs.Area1_462Code.GDPotion_9595numberObjects3= [];
gdjs.Area1_462Code.GDPotion_9595numberObjects4= [];
gdjs.Area1_462Code.GDPotion_9595numberObjects5= [];
gdjs.Area1_462Code.GDPotion_9595numberObjects6= [];
gdjs.Area1_462Code.GDPotion_9595numberObjects7= [];
gdjs.Area1_462Code.GDPotion_9595numberObjects8= [];
gdjs.Area1_462Code.GDPotion_9595numberObjects9= [];
gdjs.Area1_462Code.GDTImerObjects1= [];
gdjs.Area1_462Code.GDTImerObjects2= [];
gdjs.Area1_462Code.GDTImerObjects3= [];
gdjs.Area1_462Code.GDTImerObjects4= [];
gdjs.Area1_462Code.GDTImerObjects5= [];
gdjs.Area1_462Code.GDTImerObjects6= [];
gdjs.Area1_462Code.GDTImerObjects7= [];
gdjs.Area1_462Code.GDTImerObjects8= [];
gdjs.Area1_462Code.GDTImerObjects9= [];
gdjs.Area1_462Code.GDKillcountObjects1= [];
gdjs.Area1_462Code.GDKillcountObjects2= [];
gdjs.Area1_462Code.GDKillcountObjects3= [];
gdjs.Area1_462Code.GDKillcountObjects4= [];
gdjs.Area1_462Code.GDKillcountObjects5= [];
gdjs.Area1_462Code.GDKillcountObjects6= [];
gdjs.Area1_462Code.GDKillcountObjects7= [];
gdjs.Area1_462Code.GDKillcountObjects8= [];
gdjs.Area1_462Code.GDKillcountObjects9= [];


gdjs.Area1_462Code.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_462Code.GDKing_9595SlimeObjects7);
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects7.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects7[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects7.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects7[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_462Code.asyncCallback8740572 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(8), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8740572(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8739684 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(6), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8739684(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8738708 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(9), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8738708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8737748 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(7), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8737748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8736812 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(5), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8736812(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects6[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects6[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_462Code.asyncCallback8746940 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)));
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)));
}
{ //Subevents
gdjs.Area1_462Code.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/maxexp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8746940(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8746004 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/hp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8746004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8744876 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/spd/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8744876(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8743812 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/atk/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8743812(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8742748 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_462Code.GDPlayerObjects1) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/def/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8742748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.eventsList12 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_462Code.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_462Code.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDScreenObjects1Objects = Hashtable.newFrom({"Screen": gdjs.Area1_462Code.GDScreenObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDMenuObjects1Objects = Hashtable.newFrom({"Menu": gdjs.Area1_462Code.GDMenuObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDStatus_95959595boxObjects1Objects = Hashtable.newFrom({"Status_box": gdjs.Area1_462Code.GDStatus_9595boxObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDHPObjects1Objects = Hashtable.newFrom({"HP": gdjs.Area1_462Code.GDHPObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDHealthBarObjects1Objects = Hashtable.newFrom({"HealthBar": gdjs.Area1_462Code.GDHealthBarObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDTargetObjects1Objects = Hashtable.newFrom({"Target": gdjs.Area1_462Code.GDTargetObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDLevel_95959595numberObjects1Objects = Hashtable.newFrom({"Level_number": gdjs.Area1_462Code.GDLevel_9595numberObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDplayernameObjects1Objects = Hashtable.newFrom({"playername": gdjs.Area1_462Code.GDplayernameObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPotion_95959595boxObjects1Objects = Hashtable.newFrom({"Potion_box": gdjs.Area1_462Code.GDPotion_9595boxObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPotion_95959595numberObjects1Objects = Hashtable.newFrom({"Potion_number": gdjs.Area1_462Code.GDPotion_9595numberObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDTImerObjects1Objects = Hashtable.newFrom({"TImer": gdjs.Area1_462Code.GDTImerObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKillcountObjects1Objects = Hashtable.newFrom({"Killcount": gdjs.Area1_462Code.GDKillcountObjects1});
gdjs.Area1_462Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Collision_Mask"), gdjs.Area1_462Code.GDCollision_9595MaskObjects2);
gdjs.copyArray(runtimeScene.getObjects("Collision_Mask2"), gdjs.Area1_462Code.GDCollision_9595Mask2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects2);
gdjs.copyArray(gdjs.Area1_462Code.GDScreenObjects1, gdjs.Area1_462Code.GDScreenObjects2);

gdjs.copyArray(gdjs.Area1_462Code.GDStatus_9595boxObjects1, gdjs.Area1_462Code.GDStatus_9595boxObjects2);

{for(var i = 0, len = gdjs.Area1_462Code.GDScreenObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDScreenObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDStatus_9595boxObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDStatus_9595boxObjects2[i].getBehavior("Opacity").setOpacity(200);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDStatus_9595boxObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDStatus_9595boxObjects2[i].getBehavior("Resizable").setSize(300, 150);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects2[i].getBehavior("Resizable").setSize(77, 96);
}
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.Area1_462Code.GDCollision_9595MaskObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDCollision_9595MaskObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDCollision_9595Mask2Objects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDCollision_9595Mask2Objects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Area1_462Code.GDLevel_9595numberObjects1 */
/* Reuse gdjs.Area1_462Code.GDPotion_9595numberObjects1 */
/* Reuse gdjs.Area1_462Code.GDplayernameObjects1 */
{for(var i = 0, len = gdjs.Area1_462Code.GDplayernameObjects1.length ;i < len;++i) {
    gdjs.Area1_462Code.GDplayernameObjects1[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(2).getAsString());
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDLevel_9595numberObjects1.length ;i < len;++i) {
    gdjs.Area1_462Code.GDLevel_9595numberObjects1[i].setBBText("LV. " + runtimeScene.getGame().getVariables().getFromIndex(3).getAsString());
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDPotion_9595numberObjects1.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotion_9595numberObjects1[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16))) + "x");
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDPotion_9595numberObjects1.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotion_9595numberObjects1[i].setBBText("Kill : " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(23))));
}
}}

}


};gdjs.Area1_462Code.eventsList14 = function(runtimeScene) {

{

gdjs.Area1_462Code.GDPotion_9595boxObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Area1_462Code.GDPotion_9595boxObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_462Code.GDPotion_9595boxObjects3);
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPotion_9595boxObjects3.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDPotion_9595boxObjects3[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.Area1_462Code.GDPotion_9595boxObjects3[k] = gdjs.Area1_462Code.GDPotion_9595boxObjects3[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPotion_9595boxObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Area1_462Code.GDPotion_9595boxObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Area1_462Code.GDPotion_9595boxObjects2_1final.indexOf(gdjs.Area1_462Code.GDPotion_9595boxObjects3[j]) === -1 )
            gdjs.Area1_462Code.GDPotion_9595boxObjects2_1final.push(gdjs.Area1_462Code.GDPotion_9595boxObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "f");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.Area1_462Code.GDPotion_9595boxObjects2_1final, gdjs.Area1_462Code.GDPotion_9595boxObjects2);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_462Code.GDHealthBarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_462Code.GDPotion_9595numberObjects2);
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects2[i].getBehavior("Health").Heal((gdjs.Area1_462Code.GDPlayerObjects2[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDHealthBarObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDHealthBarObjects2[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_462Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_462Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}{runtimeScene.getGame().getVariables().getFromIndex(16).sub(1);
}{for(var i = 0, len = gdjs.Area1_462Code.GDPotion_9595numberObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotion_9595numberObjects2[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16))) + "x");
}
}}

}


{

gdjs.Area1_462Code.GDMenuObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Area1_462Code.GDMenuObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Area1_462Code.GDMenuObjects3);
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDMenuObjects3.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDMenuObjects3[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.Area1_462Code.GDMenuObjects3[k] = gdjs.Area1_462Code.GDMenuObjects3[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDMenuObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Area1_462Code.GDMenuObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Area1_462Code.GDMenuObjects2_1final.indexOf(gdjs.Area1_462Code.GDMenuObjects3[j]) === -1 )
            gdjs.Area1_462Code.GDMenuObjects2_1final.push(gdjs.Area1_462Code.GDMenuObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.Area1_462Code.GDMenuObjects2_1final, gdjs.Area1_462Code.GDMenuObjects2);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Menu");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyReleased(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_462Code.GDHealthBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Area1_462Code.GDHealthBarObjects1.length ;i < len;++i) {
    gdjs.Area1_462Code.GDHealthBarObjects1[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_462Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_462Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}}

}


};gdjs.Area1_462Code.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HP"), gdjs.Area1_462Code.GDHPObjects3);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_462Code.GDKillcountObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_462Code.GDPotion_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_462Code.GDPotion_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Screen"), gdjs.Area1_462Code.GDScreenObjects3);
gdjs.copyArray(runtimeScene.getObjects("Status_box"), gdjs.Area1_462Code.GDStatus_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Area1_462Code.GDTargetObjects3);
{for(var i = 0, len = gdjs.Area1_462Code.GDStatus_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDStatus_9595boxObjects3[i].setZOrder((( gdjs.Area1_462Code.GDHPObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDHPObjects3[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDPotion_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotion_9595boxObjects3[i].setZOrder((( gdjs.Area1_462Code.GDTargetObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDTargetObjects3[0].getZOrder()) - 2);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDKillcountObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKillcountObjects3[i].setZOrder((( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDPotion_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotion_9595numberObjects3[i].setZOrder((( gdjs.Area1_462Code.GDTargetObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDTargetObjects3[0].getZOrder()) - 1);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.Area1_462Code.GDFloorObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_462Code.GDWall_9595HorizontalObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall_vertical"), gdjs.Area1_462Code.GDWall_9595verticalObjects3);
{for(var i = 0, len = gdjs.Area1_462Code.GDFloorObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDFloorObjects3[i].setZOrder(0);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDWall_9595verticalObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDWall_9595verticalObjects3[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDWall_9595HorizontalObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDWall_9595HorizontalObjects3[i].setZOrder(2);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Area1_462Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Staircase"), gdjs.Area1_462Code.GDStaircaseObjects2);
{for(var i = 0, len = gdjs.Area1_462Code.GDStaircaseObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDStaircaseObjects2[i].setZOrder((( gdjs.Area1_462Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects2[0].getZOrder()) - 1);
}
}}

}


};gdjs.Area1_462Code.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shadow"), gdjs.Area1_462Code.GDShadowObjects2);
{for(var i = 0, len = gdjs.Area1_462Code.GDShadowObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDShadowObjects2[i].setZOrder((( gdjs.Area1_462Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects2[0].getZOrder()) - 3);
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList15(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_462Code.GDKing_9595SlimeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDPlayerObjects2[i].getY() > (( gdjs.Area1_462Code.GDKing_9595SlimeObjects2.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects2[0].getPointY("center")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPlayerObjects2[k] = gdjs.Area1_462Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_462Code.GDSlashObjects2);
{for(var i = 0, len = gdjs.Area1_462Code.GDSlashObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDSlashObjects2[i].setZOrder((( gdjs.Area1_462Code.GDKing_9595SlimeObjects2.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects2[0].getZOrder()) + 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_462Code.GDKing_9595SlimeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDPlayerObjects1[i].getY() < (( gdjs.Area1_462Code.GDKing_9595SlimeObjects1.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects1[0].getPointY("center")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPlayerObjects1[k] = gdjs.Area1_462Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_462Code.GDSlashObjects1);
{for(var i = 0, len = gdjs.Area1_462Code.GDSlashObjects1.length ;i < len;++i) {
    gdjs.Area1_462Code.GDSlashObjects1[i].setZOrder((( gdjs.Area1_462Code.GDKing_9595SlimeObjects1.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects1[0].getZOrder()) - 1);
}
}}

}


};gdjs.Area1_462Code.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Area1_462Code.GDMenuObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDMenuObjects2.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDMenuObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDMenuObjects2[k] = gdjs.Area1_462Code.GDMenuObjects2[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDMenuObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Menu");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyReleased(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_462Code.GDHealthBarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Area1_462Code.GDHealthBarObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDHealthBarObjects2[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_462Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_462Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_462Code.GDPotion_9595boxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPotion_9595boxObjects1.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDPotion_9595boxObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPotion_9595boxObjects1[k] = gdjs.Area1_462Code.GDPotion_9595boxObjects1[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPotion_9595boxObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) > 0;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_462Code.GDHealthBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_462Code.GDPotion_9595numberObjects1);
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects1[i].getBehavior("Health").Heal((gdjs.Area1_462Code.GDPlayerObjects1[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDHealthBarObjects1.length ;i < len;++i) {
    gdjs.Area1_462Code.GDHealthBarObjects1[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_462Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_462Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}{runtimeScene.getGame().getVariables().getFromIndex(16).sub(1);
}{for(var i = 0, len = gdjs.Area1_462Code.GDPotion_9595numberObjects1.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotion_9595numberObjects1[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16))) + "x");
}
}}

}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_462Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_462Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDCollision_95959595MaskObjects3Objects = Hashtable.newFrom({"Collision_Mask": gdjs.Area1_462Code.GDCollision_9595MaskObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDCollision_95959595Mask2Objects3Objects = Hashtable.newFrom({"Collision_Mask2": gdjs.Area1_462Code.GDCollision_9595Mask2Objects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBarrierObjects4Objects = Hashtable.newFrom({"Barrier": gdjs.Area1_462Code.GDBarrierObjects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBarrierObjects4Objects = Hashtable.newFrom({"Barrier": gdjs.Area1_462Code.GDBarrierObjects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBarrier2Objects3Objects = Hashtable.newFrom({"Barrier2": gdjs.Area1_462Code.GDBarrier2Objects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBarrier2Objects3Objects = Hashtable.newFrom({"Barrier2": gdjs.Area1_462Code.GDBarrier2Objects3});
gdjs.Area1_462Code.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Area1_462Code.GDBarrierObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBarrierObjects4Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDBarrierObjects4 */
/* Reuse gdjs.Area1_462Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects4[i].separateFromObjectsList(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBarrierObjects4Objects, false);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBarrierObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBarrierObjects4[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barrier2"), gdjs.Area1_462Code.GDBarrier2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBarrier2Objects3Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDBarrier2Objects3 */
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].separateFromObjectsList(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBarrier2Objects3Objects, false);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBarrier2Objects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBarrier2Objects3[i].hide(false);
}
}}

}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPotionObjects3Objects = Hashtable.newFrom({"Potion": gdjs.Area1_462Code.GDPotionObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects3Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_462Code.GDKing_9595SlimeObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects3Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_462Code.GDKing_9595SlimeObjects3});
gdjs.Area1_462Code.asyncCallback11220028 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects4[i].getBehavior("ShakeObject_PositionAngleScale").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Area1_462Code.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_462Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback11220028(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects3, gdjs.Area1_462Code.GDKing_9595SlimeObjects4);

gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects3, gdjs.Area1_462Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_462Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects4[0].getPointY("Center")) - (( gdjs.Area1_462Code.GDKing_9595SlimeObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects4[0].getPointY("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_462Code.GDPlayerObjects4[i].getPointX("Center")), (gdjs.Area1_462Code.GDPlayerObjects4[i].getPointY("Center")) - 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects3, gdjs.Area1_462Code.GDKing_9595SlimeObjects4);

gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects3, gdjs.Area1_462Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_462Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects4[0].getPointY("Center")) - (( gdjs.Area1_462Code.GDKing_9595SlimeObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects4[0].getPointY("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_462Code.GDPlayerObjects4[i].getPointX("Center")), (gdjs.Area1_462Code.GDPlayerObjects4[i].getPointY("Center")) + 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects3, gdjs.Area1_462Code.GDKing_9595SlimeObjects4);

gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects3, gdjs.Area1_462Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_462Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects4[0].getPointX("Center")) - (( gdjs.Area1_462Code.GDKing_9595SlimeObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects4[0].getPointX("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_462Code.GDPlayerObjects4[i].getPointX("Center")) + 2000, (gdjs.Area1_462Code.GDPlayerObjects4[i].getPointY("Center")), 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects3, gdjs.Area1_462Code.GDKing_9595SlimeObjects4);

gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects3, gdjs.Area1_462Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_462Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects4[0].getPointX("Center")) - (( gdjs.Area1_462Code.GDKing_9595SlimeObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects4[0].getPointX("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_462Code.GDPlayerObjects4[i].getPointX("Center")) - 2000, (gdjs.Area1_462Code.GDPlayerObjects4[i].getPointY("Center")), 1000, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(1, 5, 5, 0, 5, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects3Objects = Hashtable.newFrom({"King_Slime2": gdjs.Area1_462Code.GDKing_9595Slime2Objects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects3Objects = Hashtable.newFrom({"King_Slime2": gdjs.Area1_462Code.GDKing_9595Slime2Objects3});
gdjs.Area1_462Code.asyncCallback11232812 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects4[i].getBehavior("ShakeObject_PositionAngleScale").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Area1_462Code.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_462Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback11232812(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects3, gdjs.Area1_462Code.GDKing_9595Slime2Objects4);

gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects3, gdjs.Area1_462Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_462Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects4[0].getPointY("Center")) - (( gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects4[0].getPointY("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_462Code.GDPlayerObjects4[i].getPointX("Center")), (gdjs.Area1_462Code.GDPlayerObjects4[i].getPointY("Center")) - 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects3, gdjs.Area1_462Code.GDKing_9595Slime2Objects4);

gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects3, gdjs.Area1_462Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_462Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects4[0].getPointY("Center")) - (( gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects4[0].getPointY("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_462Code.GDPlayerObjects4[i].getPointX("Center")), (gdjs.Area1_462Code.GDPlayerObjects4[i].getPointY("Center")) + 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects3, gdjs.Area1_462Code.GDKing_9595Slime2Objects4);

gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects3, gdjs.Area1_462Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_462Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects4[0].getPointX("Center")) - (( gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects4[0].getPointX("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_462Code.GDPlayerObjects4[i].getPointX("Center")) + 2000, (gdjs.Area1_462Code.GDPlayerObjects4[i].getPointY("Center")), 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects3, gdjs.Area1_462Code.GDKing_9595Slime2Objects4);

gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects3, gdjs.Area1_462Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_462Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects4[0].getPointX("Center")) - (( gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects4[0].getPointX("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_462Code.GDPlayerObjects4[i].getPointX("Center")) - 2000, (gdjs.Area1_462Code.GDPlayerObjects4[i].getPointY("Center")), 1000, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(1, 5, 5, 0, 5, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects4Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_462Code.GDKing_9595SlimeObjects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects4Objects = Hashtable.newFrom({"King_Slime2": gdjs.Area1_462Code.GDKing_9595Slime2Objects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects3Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_462Code.GDKing_9595SlimeObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects3Objects = Hashtable.newFrom({"King_Slime2": gdjs.Area1_462Code.GDKing_9595Slime2Objects3});
gdjs.Area1_462Code.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_462Code.GDKing_9595SlimeObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects3 */
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].separateFromObjectsList(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects3Objects, false);
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime2"), gdjs.Area1_462Code.GDKing_9595Slime2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595Slime2Objects3 */
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].separateFromObjectsList(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects3Objects, false);
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList22(runtimeScene);} //End of subevents
}

}


{

gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length = 0;

gdjs.Area1_462Code.GDKing_9595Slime2Objects3.length = 0;

gdjs.Area1_462Code.GDPlayerObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Area1_462Code.GDKing_9595SlimeObjects3_1final.length = 0;
gdjs.Area1_462Code.GDKing_9595Slime2Objects3_1final.length = 0;
gdjs.Area1_462Code.GDPlayerObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_462Code.GDKing_9595SlimeObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects4);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects4Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Area1_462Code.GDKing_9595SlimeObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Area1_462Code.GDKing_9595SlimeObjects3_1final.indexOf(gdjs.Area1_462Code.GDKing_9595SlimeObjects4[j]) === -1 )
            gdjs.Area1_462Code.GDKing_9595SlimeObjects3_1final.push(gdjs.Area1_462Code.GDKing_9595SlimeObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Area1_462Code.GDPlayerObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Area1_462Code.GDPlayerObjects3_1final.indexOf(gdjs.Area1_462Code.GDPlayerObjects4[j]) === -1 )
            gdjs.Area1_462Code.GDPlayerObjects3_1final.push(gdjs.Area1_462Code.GDPlayerObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("King_Slime2"), gdjs.Area1_462Code.GDKing_9595Slime2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects4);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects4Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Area1_462Code.GDKing_9595Slime2Objects3_1final.indexOf(gdjs.Area1_462Code.GDKing_9595Slime2Objects4[j]) === -1 )
            gdjs.Area1_462Code.GDKing_9595Slime2Objects3_1final.push(gdjs.Area1_462Code.GDKing_9595Slime2Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Area1_462Code.GDPlayerObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Area1_462Code.GDPlayerObjects3_1final.indexOf(gdjs.Area1_462Code.GDPlayerObjects4[j]) === -1 )
            gdjs.Area1_462Code.GDPlayerObjects3_1final.push(gdjs.Area1_462Code.GDPlayerObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects3_1final, gdjs.Area1_462Code.GDKing_9595SlimeObjects3);
gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects3_1final, gdjs.Area1_462Code.GDKing_9595Slime2Objects3);
gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects3_1final, gdjs.Area1_462Code.GDPlayerObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPlayerObjects3[k] = gdjs.Area1_462Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPlayerObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_462Code.GDHealthBarObjects3);
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("Health").Hit(runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() - runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber(), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDHealthBarObjects3[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}}

}


{

gdjs.Area1_462Code.GDKing_9595SlimeObjects2.length = 0;

gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length = 0;

gdjs.Area1_462Code.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Area1_462Code.GDKing_9595SlimeObjects2_1final.length = 0;
gdjs.Area1_462Code.GDKing_9595Slime2Objects2_1final.length = 0;
gdjs.Area1_462Code.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_462Code.GDKing_9595SlimeObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Area1_462Code.GDKing_9595SlimeObjects2_1final.indexOf(gdjs.Area1_462Code.GDKing_9595SlimeObjects3[j]) === -1 )
            gdjs.Area1_462Code.GDKing_9595SlimeObjects2_1final.push(gdjs.Area1_462Code.GDKing_9595SlimeObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Area1_462Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Area1_462Code.GDPlayerObjects2_1final.indexOf(gdjs.Area1_462Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Area1_462Code.GDPlayerObjects2_1final.push(gdjs.Area1_462Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("King_Slime2"), gdjs.Area1_462Code.GDKing_9595Slime2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Area1_462Code.GDKing_9595Slime2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Area1_462Code.GDKing_9595Slime2Objects2_1final.indexOf(gdjs.Area1_462Code.GDKing_9595Slime2Objects3[j]) === -1 )
            gdjs.Area1_462Code.GDKing_9595Slime2Objects2_1final.push(gdjs.Area1_462Code.GDKing_9595Slime2Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Area1_462Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Area1_462Code.GDPlayerObjects2_1final.indexOf(gdjs.Area1_462Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Area1_462Code.GDPlayerObjects2_1final.push(gdjs.Area1_462Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects2_1final, gdjs.Area1_462Code.GDKing_9595SlimeObjects2);
gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects2_1final, gdjs.Area1_462Code.GDKing_9595Slime2Objects2);
gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects2_1final, gdjs.Area1_462Code.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDPlayerObjects2[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPlayerObjects2[k] = gdjs.Area1_462Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects2[i].getBehavior("Health").Hit(0, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_462Code.eventsList24 = function(runtimeScene) {

{


gdjs.Area1_462Code.eventsList23(runtimeScene);
}


};gdjs.Area1_462Code.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Area1_462Code.GDBarrierObjects3);
gdjs.copyArray(runtimeScene.getObjects("Barrier2"), gdjs.Area1_462Code.GDBarrier2Objects3);
{for(var i = 0, len = gdjs.Area1_462Code.GDBarrierObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBarrierObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBarrier2Objects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBarrier2Objects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_462Code.GDWall_9595HorizontalObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
/* Reuse gdjs.Area1_462Code.GDWall_9595HorizontalObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].separateFromObjectsList(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects3Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Collision_Mask"), gdjs.Area1_462Code.GDCollision_9595MaskObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDCollision_95959595MaskObjects3Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Area1_462Code.GDBarrierObjects3);
/* Reuse gdjs.Area1_462Code.GDCollision_9595MaskObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDCollision_9595MaskObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDCollision_9595MaskObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBarrierObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBarrierObjects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Collision_Mask2"), gdjs.Area1_462Code.GDCollision_9595Mask2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDCollision_95959595Mask2Objects3Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Barrier2"), gdjs.Area1_462Code.GDBarrier2Objects3);
/* Reuse gdjs.Area1_462Code.GDCollision_9595Mask2Objects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDCollision_9595Mask2Objects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDCollision_9595Mask2Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBarrier2Objects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBarrier2Objects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(10)) == 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Area1_462Code.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion"), gdjs.Area1_462Code.GDPotionObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects3Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPotionObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPotionObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_462Code.GDPotion_9595numberObjects3);
{for(var i = 0, len = gdjs.Area1_462Code.GDPotionObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotionObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(16).add(1);
}{for(var i = 0, len = gdjs.Area1_462Code.GDPotion_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotion_9595numberObjects3[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16))) + "x");
}
}}

}


{


gdjs.Area1_462Code.eventsList24(runtimeScene);
}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDSlashObjects3Objects = Hashtable.newFrom({"Slash": gdjs.Area1_462Code.GDSlashObjects3});
gdjs.Area1_462Code.asyncCallback11241900 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Slash"), gdjs.Area1_462Code.GDSlashObjects4);

{for(var i = 0, len = gdjs.Area1_462Code.GDSlashObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDSlashObjects4[i].deleteFromScene(runtimeScene);
}
}}
gdjs.Area1_462Code.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_462Code.GDSlashObjects3) asyncObjectsList.addObject("Slash", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback11241900(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);
gdjs.Area1_462Code.GDSlashObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDSlashObjects3Objects, (( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointX("slash")), (( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointY("slash")), "");
}{for(var i = 0, len = gdjs.Area1_462Code.GDSlashObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDSlashObjects3[i].getBehavior("Animation").setAnimationName("Slash");
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList26(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseInsideCanvas(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_462Code.GDSlashObjects2);
{for(var i = 0, len = gdjs.Area1_462Code.GDSlashObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDSlashObjects2[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


};gdjs.Area1_462Code.eventsList28 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HP"), gdjs.Area1_462Code.GDHPObjects3);
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_462Code.GDHealthBarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Healthempty"), gdjs.Area1_462Code.GDHealthemptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_462Code.GDKillcountObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_number"), gdjs.Area1_462Code.GDLevel_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Area1_462Code.GDMenuObjects3);
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_462Code.GDPotion_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_462Code.GDPotion_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Screen"), gdjs.Area1_462Code.GDScreenObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_462Code.GDSlashObjects3);
gdjs.copyArray(runtimeScene.getObjects("Status_box"), gdjs.Area1_462Code.GDStatus_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_462Code.GDTImerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Area1_462Code.GDTargetObjects3);
gdjs.copyArray(runtimeScene.getObjects("playername"), gdjs.Area1_462Code.GDplayernameObjects3);
{for(var i = 0, len = gdjs.Area1_462Code.GDScreenObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDScreenObjects3[i].setPosition((( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointX("screen")),(( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointY("screen")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDMenuObjects3[i].setPosition((( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointX("Menu")),(( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointY("Menu")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDStatus_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDStatus_9595boxObjects3[i].setPosition((( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointX("box_status")),(( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointY("box_status")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDHPObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDHPObjects3[i].setPosition((( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointX("HP_name")),(( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointY("HP_name")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDHealthBarObjects3[i].setPosition((( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDHealthemptyObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDHealthemptyObjects3[i].setPosition((( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDLevel_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDLevel_9595numberObjects3[i].setPosition((( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointX("LVL_name")),(( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointY("LVL_name")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDplayernameObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDplayernameObjects3[i].setPosition((( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointX("player_name")),(( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointY("player_name")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDPotion_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotion_9595boxObjects3[i].setPosition((( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointX("potion")),(( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointY("potion")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDPotion_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotion_9595numberObjects3[i].setPosition((( gdjs.Area1_462Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPotion_9595boxObjects3[0].getPointX("number")),(( gdjs.Area1_462Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPotion_9595boxObjects3[0].getPointY("number")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDSlashObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDSlashObjects3[i].setPosition((( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointX("slash")),(( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointY("slash")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDTargetObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDTargetObjects3[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDKillcountObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKillcountObjects3[i].setPosition((( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointX("kcount")),(( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointY("kcount")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDTImerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDTImerObjects3[i].setPosition((( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointX("time")),(( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointY("time")));
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointX("screen")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointY("screen")), "", 0);
}}

}


};gdjs.Area1_462Code.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HP"), gdjs.Area1_462Code.GDHPObjects3);
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_462Code.GDHealthBarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Healthempty"), gdjs.Area1_462Code.GDHealthemptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_462Code.GDKillcountObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_number"), gdjs.Area1_462Code.GDLevel_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Area1_462Code.GDMenuObjects3);
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_462Code.GDPotion_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_462Code.GDPotion_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Screen"), gdjs.Area1_462Code.GDScreenObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_462Code.GDSlashObjects3);
gdjs.copyArray(runtimeScene.getObjects("Status_box"), gdjs.Area1_462Code.GDStatus_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_462Code.GDTImerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Area1_462Code.GDTargetObjects3);
gdjs.copyArray(runtimeScene.getObjects("playername"), gdjs.Area1_462Code.GDplayernameObjects3);
{for(var i = 0, len = gdjs.Area1_462Code.GDScreenObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDScreenObjects3[i].setPosition((( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointX("screen")),(( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointY("screen")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDMenuObjects3[i].setPosition((( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointX("Menu")),(( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointY("Menu")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDStatus_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDStatus_9595boxObjects3[i].setPosition((( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointX("box_status")),(( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointY("box_status")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDHPObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDHPObjects3[i].setPosition((( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointX("HP_name")),(( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointY("HP_name")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDHealthBarObjects3[i].setPosition((( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDHealthemptyObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDHealthemptyObjects3[i].setPosition((( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDLevel_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDLevel_9595numberObjects3[i].setPosition((( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointX("LVL_name")),(( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointY("LVL_name")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDplayernameObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDplayernameObjects3[i].setPosition((( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointX("player_name")),(( gdjs.Area1_462Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDStatus_9595boxObjects3[0].getPointY("player_name")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDPotion_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotion_9595boxObjects3[i].setPosition((( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointX("potion")),(( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointY("potion")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDPotion_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPotion_9595numberObjects3[i].setPosition((( gdjs.Area1_462Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPotion_9595boxObjects3[0].getPointX("number")),(( gdjs.Area1_462Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPotion_9595boxObjects3[0].getPointY("number")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDSlashObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDSlashObjects3[i].setPosition((( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointX("slash")),(( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointY("slash")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDTargetObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDTargetObjects3[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDKillcountObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKillcountObjects3[i].setPosition((( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointX("kcount")),(( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointY("kcount")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDTImerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDTImerObjects3[i].setPosition((( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointX("time")),(( gdjs.Area1_462Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDScreenObjects3[0].getPointY("time")));
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointX("screen")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointY("screen")), "", 0);
}}

}


};gdjs.Area1_462Code.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPlayerObjects3[k] = gdjs.Area1_462Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Shadow"), gdjs.Area1_462Code.GDShadowObjects3);
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("Animation").setAnimationName("walk");
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDShadowObjects3[i].getBehavior("Animation").setAnimationName("walk");
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDShadowObjects3[i].setPosition((( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointX("shadow")),(( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointY("shadow")));
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPlayerObjects3[k] = gdjs.Area1_462Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Shadow"), gdjs.Area1_462Code.GDShadowObjects3);
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("Animation").setAnimationName("idle");
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDShadowObjects3[i].getBehavior("Animation").setAnimationName("idle");
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDShadowObjects3[i].setPosition((( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointX("shadow")),(( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointY("shadow")));
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPlayerObjects3[k] = gdjs.Area1_462Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].addForce(100, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPlayerObjects3[k] = gdjs.Area1_462Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].addForce(-(100), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Up") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPlayerObjects3[k] = gdjs.Area1_462Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].addForce(0, -(100), 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Down") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPlayerObjects3[k] = gdjs.Area1_462Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].addForce(0, 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) < (( gdjs.Area1_462Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects3[0].getPointX("center"));
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects3[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) > (( gdjs.Area1_462Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects2[0].getPointX("center"));
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.Area1_462Code.eventsList31 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_462Code.GDKing_9595SlimeObjects8);
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects8.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects8[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects8.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects8[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_462Code.asyncCallback8740573 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList31(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList32 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(8), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8740573(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8739685 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList32(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList33 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(6), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8739685(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8738709 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList33(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList34 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(9), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8738709(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8737749 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList35 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(7), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8737749(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8736813 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList35(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList36 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(5), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8736813(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.eventsList37 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects7);
{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects7.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects7[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDPlayerObjects7.length ;i < len;++i) {
    gdjs.Area1_462Code.GDPlayerObjects7[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_462Code.asyncCallback8746941 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)));
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)));
}
{ //Subevents
gdjs.Area1_462Code.eventsList37(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList38 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/maxexp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8746941(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8746005 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList38(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList39 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/hp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8746005(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8744877 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList39(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList40 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/spd/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8744877(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8743813 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList40(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList41 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/atk/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8743813(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.asyncCallback8742749 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_462Code.eventsList41(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_462Code.eventsList42 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/def/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_462Code.asyncCallback8742749(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_462Code.eventsList43 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_462Code.eventsList36(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_462Code.eventsList42(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_462Code.eventsList44 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber() > 0);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Level_number"), gdjs.Area1_462Code.GDLevel_9595numberObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Area1_462Code.GDLevel_9595numberObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDLevel_9595numberObjects2[i].setBBText("LV. " + runtimeScene.getGame().getVariables().getFromIndex(3).getAsString());
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(0);
}
{ //Subevents
gdjs.Area1_462Code.eventsList43(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_462Code.eventsList45 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Area1.2", false);
}}

}


};gdjs.Area1_462Code.eventsList46 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDPlayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDPlayerObjects1[k] = gdjs.Area1_462Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(16).setNumber(runtimeScene.getGame().getVariables().getFromIndex(22).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(runtimeScene.getGame().getVariables().getFromIndex(20).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(runtimeScene.getGame().getVariables().getFromIndex(21).getAsNumber());
}
{ //Subevents
gdjs.Area1_462Code.eventsList45(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_462Code.eventsList47 = function(runtimeScene) {

{


gdjs.Area1_462Code.eventsList25(runtimeScene);
}


{


gdjs.Area1_462Code.eventsList27(runtimeScene);
}


{


gdjs.Area1_462Code.eventsList30(runtimeScene);
}


{


gdjs.Area1_462Code.eventsList44(runtimeScene);
}


{


gdjs.Area1_462Code.eventsList46(runtimeScene);
}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBoss_95959595HealthbarObjects5Objects = Hashtable.newFrom({"Boss_Healthbar": gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects5Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_462Code.GDKing_9595SlimeObjects5});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects5Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_462Code.GDWall_9595HorizontalObjects5});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects5Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_462Code.GDWall_9595HorizontalObjects5});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects5Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_462Code.GDKing_9595SlimeObjects5});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects5Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects5});
gdjs.Area1_462Code.eventsList48 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects5, gdjs.Area1_462Code.GDKing_9595SlimeObjects6);

gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects5, gdjs.Area1_462Code.GDPlayerObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595SlimeObjects6.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595SlimeObjects6[i].getX() < (( gdjs.Area1_462Code.GDPlayerObjects6.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects6[0].getPointX("Center")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595SlimeObjects6[k] = gdjs.Area1_462Code.GDKing_9595SlimeObjects6[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595SlimeObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects6 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects6.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects6[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects5 */
/* Reuse gdjs.Area1_462Code.GDPlayerObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595SlimeObjects5[i].getX() > (( gdjs.Area1_462Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects5[0].getPointX("Center")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595SlimeObjects5[k] = gdjs.Area1_462Code.GDKing_9595SlimeObjects5[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects5 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects5[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects5Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_462Code.GDKing_9595SlimeObjects5});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects5Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects5});
gdjs.Area1_462Code.eventsList49 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects4, gdjs.Area1_462Code.GDKing_9595SlimeObjects5);

gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBoss_95959595HealthbarObjects5Objects, (( gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects5[0].getPointX("hp")), (( gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects5[0].getPointY("hp")), "");
}{for(var i = 0, len = gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5[i].getBehavior("Resizable").setSize(200, 25);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects4, gdjs.Area1_462Code.GDKing_9595SlimeObjects5);

gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_462Code.GDWall_9595HorizontalObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects5Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects5 */
/* Reuse gdjs.Area1_462Code.GDWall_9595HorizontalObjects5 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects5[i].separateFromObjectsList(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects5Objects, false);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects4, gdjs.Area1_462Code.GDKing_9595SlimeObjects5);

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects5Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects5Objects, 600, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Boss_Healthbar"), gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5);
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects5 */
/* Reuse gdjs.Area1_462Code.GDPlayerObjects5 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects5[i].getBehavior("Animation").setAnimationName("Walk");
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects5[i].addForceTowardObject((gdjs.Area1_462Code.GDPlayerObjects5.length !== 0 ? gdjs.Area1_462Code.GDPlayerObjects5[0] : null), runtimeScene.getScene().getVariables().getFromIndex(8).getAsNumber(), 0);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5[i].setPosition((( gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects5[0].getPointX("hp")),(( gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects5[0].getPointY("hp")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects5[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects5[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList48(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects4, gdjs.Area1_462Code.GDKing_9595SlimeObjects5);

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects5Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects5Objects, 600, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects5 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects5[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595SlimeObjects4, gdjs.Area1_462Code.GDKing_9595SlimeObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595SlimeObjects5[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595SlimeObjects5[k] = gdjs.Area1_462Code.GDKing_9595SlimeObjects5[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Area1_462Code.GDBarrierObjects5);
gdjs.copyArray(runtimeScene.getObjects("Boss_Healthbar"), gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_462Code.GDKillcountObjects5);
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects5 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects5[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBarrierObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBarrierObjects5[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).add(runtimeScene.getScene().getVariables().getFromIndex(8).getAsNumber());
}{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(0);
}{for(var i = 0, len = gdjs.Area1_462Code.GDKillcountObjects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKillcountObjects5[i].setBBText("Kill : " + runtimeScene.getGame().getVariables().getFromIndex(23).getAsString());
}
}{runtimeScene.getGame().getVariables().getFromIndex(23).add(1);
}}

}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDSlashObjects3Objects = Hashtable.newFrom({"Slash": gdjs.Area1_462Code.GDSlashObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects3Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_462Code.GDKing_9595SlimeObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDSlashObjects3Objects = Hashtable.newFrom({"Slash": gdjs.Area1_462Code.GDSlashObjects3});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects3Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_462Code.GDKing_9595SlimeObjects3});
gdjs.Area1_462Code.eventsList50 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_462Code.GDKing_9595SlimeObjects3);

for (gdjs.Area1_462Code.forEachIndex4 = 0;gdjs.Area1_462Code.forEachIndex4 < gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length;++gdjs.Area1_462Code.forEachIndex4) {
gdjs.Area1_462Code.GDKing_9595SlimeObjects4.length = 0;


gdjs.Area1_462Code.forEachTemporary4 = gdjs.Area1_462Code.GDKing_9595SlimeObjects3[gdjs.Area1_462Code.forEachIndex4];
gdjs.Area1_462Code.GDKing_9595SlimeObjects4.push(gdjs.Area1_462Code.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Area1_462Code.eventsList49(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_462Code.GDKing_9595SlimeObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_462Code.GDSlashObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDSlashObjects3Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595SlimeObjects3[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595SlimeObjects3[k] = gdjs.Area1_462Code.GDKing_9595SlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects3[i].getBehavior("Health").Hit(0, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_462Code.GDKing_9595SlimeObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_462Code.GDSlashObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDSlashObjects3Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595SlimeObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length;i<l;++i) {
    if ( !(gdjs.Area1_462Code.GDKing_9595SlimeObjects3[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595SlimeObjects3[k] = gdjs.Area1_462Code.GDKing_9595SlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Boss_Healthbar"), gdjs.Area1_462Code.GDBoss_9595HealthbarObjects3);
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects3[i].getBehavior("Animation").setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects3[i].getBehavior("Health").Hit(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() - runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber(), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBoss_9595HealthbarObjects3.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBoss_9595HealthbarObjects3[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects3[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595SlimeObjects3[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_462Code.GDKing_9595SlimeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595SlimeObjects2.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595SlimeObjects2[i].getBehavior("Animation").getAnimationName() == "Hurt" ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595SlimeObjects2[k] = gdjs.Area1_462Code.GDKing_9595SlimeObjects2[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595SlimeObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595SlimeObjects2.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595SlimeObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595SlimeObjects2[k] = gdjs.Area1_462Code.GDKing_9595SlimeObjects2[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595SlimeObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595SlimeObjects2 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595SlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595SlimeObjects2[i].getBehavior("Animation").setAnimationName("Walk");
}
}}

}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBoss_95959595HealthbarObjects4Objects = Hashtable.newFrom({"Boss_Healthbar": gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects4Objects = Hashtable.newFrom({"King_Slime2": gdjs.Area1_462Code.GDKing_9595Slime2Objects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects4Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_462Code.GDWall_9595HorizontalObjects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects4Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_462Code.GDWall_9595HorizontalObjects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects4Objects = Hashtable.newFrom({"King_Slime2": gdjs.Area1_462Code.GDKing_9595Slime2Objects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects4});
gdjs.Area1_462Code.eventsList51 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects4, gdjs.Area1_462Code.GDKing_9595Slime2Objects5);

gdjs.copyArray(gdjs.Area1_462Code.GDPlayerObjects4, gdjs.Area1_462Code.GDPlayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595Slime2Objects5.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595Slime2Objects5[i].getX() < (( gdjs.Area1_462Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects5[0].getPointX("Center")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595Slime2Objects5[k] = gdjs.Area1_462Code.GDKing_9595Slime2Objects5[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595Slime2Objects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595Slime2Objects5 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595Slime2Objects5.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595Slime2Objects5[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

/* Reuse gdjs.Area1_462Code.GDKing_9595Slime2Objects4 */
/* Reuse gdjs.Area1_462Code.GDPlayerObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595Slime2Objects4[i].getX() > (( gdjs.Area1_462Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDPlayerObjects4[0].getPointX("Center")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595Slime2Objects4[k] = gdjs.Area1_462Code.GDKing_9595Slime2Objects4[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595Slime2Objects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595Slime2Objects4[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects4Objects = Hashtable.newFrom({"King_Slime2": gdjs.Area1_462Code.GDKing_9595Slime2Objects4});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects4});
gdjs.Area1_462Code.eventsList52 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects3, gdjs.Area1_462Code.GDKing_9595Slime2Objects4);

gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDBoss_95959595HealthbarObjects4Objects, (( gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects4[0].getPointX("hp")), (( gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects4[0].getPointY("hp")), "");
}{for(var i = 0, len = gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4[i].getBehavior("Resizable").setSize(200, 25);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects3, gdjs.Area1_462Code.GDKing_9595Slime2Objects4);

gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_462Code.GDWall_9595HorizontalObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects4Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595Slime2Objects4 */
/* Reuse gdjs.Area1_462Code.GDWall_9595HorizontalObjects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595Slime2Objects4[i].separateFromObjectsList(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDWall_95959595HorizontalObjects4Objects, false);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects3, gdjs.Area1_462Code.GDKing_9595Slime2Objects4);

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects4Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects4Objects, 600, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Boss_Healthbar"), gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4);
/* Reuse gdjs.Area1_462Code.GDKing_9595Slime2Objects4 */
/* Reuse gdjs.Area1_462Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595Slime2Objects4[i].getBehavior("Animation").setAnimationName("Walk");
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595Slime2Objects4[i].addForceTowardObject((gdjs.Area1_462Code.GDPlayerObjects4.length !== 0 ? gdjs.Area1_462Code.GDPlayerObjects4[0] : null), runtimeScene.getScene().getVariables().getFromIndex(8).getAsNumber(), 0);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4[i].setPosition((( gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects4[0].getPointX("hp")),(( gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects4[0].getPointY("hp")));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects4[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects4[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList51(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects3, gdjs.Area1_462Code.GDKing_9595Slime2Objects4);

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects4Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects4Objects, 600, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595Slime2Objects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595Slime2Objects4[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(gdjs.Area1_462Code.GDKing_9595Slime2Objects3, gdjs.Area1_462Code.GDKing_9595Slime2Objects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595Slime2Objects4[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595Slime2Objects4[k] = gdjs.Area1_462Code.GDKing_9595Slime2Objects4[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Barrier2"), gdjs.Area1_462Code.GDBarrier2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Boss_Healthbar"), gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_462Code.GDKillcountObjects4);
/* Reuse gdjs.Area1_462Code.GDKing_9595Slime2Objects4 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595Slime2Objects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBarrier2Objects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBarrier2Objects4[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).add(runtimeScene.getScene().getVariables().getFromIndex(8).getAsNumber());
}{for(var i = 0, len = gdjs.Area1_462Code.GDKillcountObjects4.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKillcountObjects4[i].setBBText("Kill : " + runtimeScene.getGame().getVariables().getFromIndex(23).getAsString());
}
}{runtimeScene.getGame().getVariables().getFromIndex(23).add(1);
}}

}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDSlashObjects2Objects = Hashtable.newFrom({"Slash": gdjs.Area1_462Code.GDSlashObjects2});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects2Objects = Hashtable.newFrom({"King_Slime2": gdjs.Area1_462Code.GDKing_9595Slime2Objects2});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDSlashObjects2Objects = Hashtable.newFrom({"Slash": gdjs.Area1_462Code.GDSlashObjects2});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects2Objects = Hashtable.newFrom({"King_Slime2": gdjs.Area1_462Code.GDKing_9595Slime2Objects2});
gdjs.Area1_462Code.eventsList53 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("King_Slime2"), gdjs.Area1_462Code.GDKing_9595Slime2Objects2);

for (gdjs.Area1_462Code.forEachIndex3 = 0;gdjs.Area1_462Code.forEachIndex3 < gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length;++gdjs.Area1_462Code.forEachIndex3) {
gdjs.Area1_462Code.GDKing_9595Slime2Objects3.length = 0;


gdjs.Area1_462Code.forEachTemporary3 = gdjs.Area1_462Code.GDKing_9595Slime2Objects2[gdjs.Area1_462Code.forEachIndex3];
gdjs.Area1_462Code.GDKing_9595Slime2Objects3.push(gdjs.Area1_462Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Area1_462Code.eventsList52(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime2"), gdjs.Area1_462Code.GDKing_9595Slime2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_462Code.GDSlashObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDSlashObjects2Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595Slime2Objects2[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595Slime2Objects2[k] = gdjs.Area1_462Code.GDKing_9595Slime2Objects2[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595Slime2Objects2 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595Slime2Objects2[i].getBehavior("Health").Hit(0, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime2"), gdjs.Area1_462Code.GDKing_9595Slime2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_462Code.GDSlashObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDSlashObjects2Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKing_95959595Slime2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length;i<l;++i) {
    if ( !(gdjs.Area1_462Code.GDKing_9595Slime2Objects2[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595Slime2Objects2[k] = gdjs.Area1_462Code.GDKing_9595Slime2Objects2[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Boss_Healthbar"), gdjs.Area1_462Code.GDBoss_9595HealthbarObjects2);
/* Reuse gdjs.Area1_462Code.GDKing_9595Slime2Objects2 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595Slime2Objects2[i].getBehavior("Animation").setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595Slime2Objects2[i].getBehavior("Health").Hit(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() - runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber(), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_462Code.GDBoss_9595HealthbarObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDBoss_9595HealthbarObjects2[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length === 0 ) ? 0 :gdjs.Area1_462Code.GDKing_9595Slime2Objects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime2"), gdjs.Area1_462Code.GDKing_9595Slime2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595Slime2Objects1.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595Slime2Objects1[i].getBehavior("Animation").getAnimationName() == "Hurt" ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595Slime2Objects1[k] = gdjs.Area1_462Code.GDKing_9595Slime2Objects1[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595Slime2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_462Code.GDKing_9595Slime2Objects1.length;i<l;++i) {
    if ( gdjs.Area1_462Code.GDKing_9595Slime2Objects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.Area1_462Code.GDKing_9595Slime2Objects1[k] = gdjs.Area1_462Code.GDKing_9595Slime2Objects1[i];
        ++k;
    }
}
gdjs.Area1_462Code.GDKing_9595Slime2Objects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDKing_9595Slime2Objects1 */
{for(var i = 0, len = gdjs.Area1_462Code.GDKing_9595Slime2Objects1.length ;i < len;++i) {
    gdjs.Area1_462Code.GDKing_9595Slime2Objects1[i].getBehavior("Animation").setAnimationName("Walk");
}
}}

}


};gdjs.Area1_462Code.eventsList54 = function(runtimeScene) {

{


gdjs.Area1_462Code.eventsList50(runtimeScene);
}


{


gdjs.Area1_462Code.eventsList53(runtimeScene);
}


};gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Area1_462Code.GDPlayerObjects1});
gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDStaircaseObjects1Objects = Hashtable.newFrom({"Staircase": gdjs.Area1_462Code.GDStaircaseObjects1});
gdjs.Area1_462Code.eventsList55 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Staircase"), gdjs.Area1_462Code.GDStaircaseObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPlayerObjects1Objects, gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDStaircaseObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(2);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Area1.3", false);
}}

}


};gdjs.Area1_462Code.eventsList56 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) >= 10;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDTImerObjects2 */
{for(var i = 0, len = gdjs.Area1_462Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDTImerObjects2[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}}

}


};gdjs.Area1_462Code.eventsList57 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) >= 10;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDTImerObjects2 */
{for(var i = 0, len = gdjs.Area1_462Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList56(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_462Code.eventsList58 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) >= 10;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_462Code.GDTImerObjects2 */
{for(var i = 0, len = gdjs.Area1_462Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList57(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_462Code.eventsList59 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_462Code.GDTImerObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timer");
}{for(var i = 0, len = gdjs.Area1_462Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "timer") >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_462Code.GDTImerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(17).add(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timer");
}{for(var i = 0, len = gdjs.Area1_462Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_462Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}
{ //Subevents
gdjs.Area1_462Code.eventsList58(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) == 60;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(17).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(18).add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 60;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(19).add(1);
}}

}


};gdjs.Area1_462Code.eventsList60 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_462Code.GDPlayerObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(1).setString("boss_slime");
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Area1_462Code.GDPlayerObjects1.length !== 0 ? gdjs.Area1_462Code.GDPlayerObjects1[0] : null), true, "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.2, "", 0);
}
{ //Subevents
gdjs.Area1_462Code.eventsList12(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(21).setNumber(runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(22).setNumber(runtimeScene.getGame().getVariables().getFromIndex(16).getAsNumber());
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.Area1_462Code.GDHPObjects1.length = 0;

gdjs.Area1_462Code.GDHealthBarObjects1.length = 0;

gdjs.Area1_462Code.GDKillcountObjects1.length = 0;

gdjs.Area1_462Code.GDLevel_9595numberObjects1.length = 0;

gdjs.Area1_462Code.GDMenuObjects1.length = 0;

gdjs.Area1_462Code.GDPotion_9595boxObjects1.length = 0;

gdjs.Area1_462Code.GDPotion_9595numberObjects1.length = 0;

gdjs.Area1_462Code.GDScreenObjects1.length = 0;

gdjs.Area1_462Code.GDStatus_9595boxObjects1.length = 0;

gdjs.Area1_462Code.GDTImerObjects1.length = 0;

gdjs.Area1_462Code.GDTargetObjects1.length = 0;

gdjs.Area1_462Code.GDplayernameObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDScreenObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDMenuObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDStatus_95959595boxObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDHPObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDHealthBarObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDTargetObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDLevel_95959595numberObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDplayernameObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPotion_95959595boxObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDPotion_95959595numberObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDTImerObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_462Code.mapOfGDgdjs_9546Area1_9595462Code_9546GDKillcountObjects1Objects, 0, 0, "");
}
{ //Subevents
gdjs.Area1_462Code.eventsList13(runtimeScene);} //End of subevents
}

}


{


gdjs.Area1_462Code.eventsList14(runtimeScene);
}


{


gdjs.Area1_462Code.eventsList16(runtimeScene);
}


{


gdjs.Area1_462Code.eventsList17(runtimeScene);
}


{


gdjs.Area1_462Code.eventsList47(runtimeScene);
}


{


gdjs.Area1_462Code.eventsList54(runtimeScene);
}


{


gdjs.Area1_462Code.eventsList55(runtimeScene);
}


{


gdjs.Area1_462Code.eventsList59(runtimeScene);
}


};

gdjs.Area1_462Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Area1_462Code.GDFloorObjects1.length = 0;
gdjs.Area1_462Code.GDFloorObjects2.length = 0;
gdjs.Area1_462Code.GDFloorObjects3.length = 0;
gdjs.Area1_462Code.GDFloorObjects4.length = 0;
gdjs.Area1_462Code.GDFloorObjects5.length = 0;
gdjs.Area1_462Code.GDFloorObjects6.length = 0;
gdjs.Area1_462Code.GDFloorObjects7.length = 0;
gdjs.Area1_462Code.GDFloorObjects8.length = 0;
gdjs.Area1_462Code.GDFloorObjects9.length = 0;
gdjs.Area1_462Code.GDWall_9595HorizontalObjects1.length = 0;
gdjs.Area1_462Code.GDWall_9595HorizontalObjects2.length = 0;
gdjs.Area1_462Code.GDWall_9595HorizontalObjects3.length = 0;
gdjs.Area1_462Code.GDWall_9595HorizontalObjects4.length = 0;
gdjs.Area1_462Code.GDWall_9595HorizontalObjects5.length = 0;
gdjs.Area1_462Code.GDWall_9595HorizontalObjects6.length = 0;
gdjs.Area1_462Code.GDWall_9595HorizontalObjects7.length = 0;
gdjs.Area1_462Code.GDWall_9595HorizontalObjects8.length = 0;
gdjs.Area1_462Code.GDWall_9595HorizontalObjects9.length = 0;
gdjs.Area1_462Code.GDWall_9595verticalObjects1.length = 0;
gdjs.Area1_462Code.GDWall_9595verticalObjects2.length = 0;
gdjs.Area1_462Code.GDWall_9595verticalObjects3.length = 0;
gdjs.Area1_462Code.GDWall_9595verticalObjects4.length = 0;
gdjs.Area1_462Code.GDWall_9595verticalObjects5.length = 0;
gdjs.Area1_462Code.GDWall_9595verticalObjects6.length = 0;
gdjs.Area1_462Code.GDWall_9595verticalObjects7.length = 0;
gdjs.Area1_462Code.GDWall_9595verticalObjects8.length = 0;
gdjs.Area1_462Code.GDWall_9595verticalObjects9.length = 0;
gdjs.Area1_462Code.GDBarrierObjects1.length = 0;
gdjs.Area1_462Code.GDBarrierObjects2.length = 0;
gdjs.Area1_462Code.GDBarrierObjects3.length = 0;
gdjs.Area1_462Code.GDBarrierObjects4.length = 0;
gdjs.Area1_462Code.GDBarrierObjects5.length = 0;
gdjs.Area1_462Code.GDBarrierObjects6.length = 0;
gdjs.Area1_462Code.GDBarrierObjects7.length = 0;
gdjs.Area1_462Code.GDBarrierObjects8.length = 0;
gdjs.Area1_462Code.GDBarrierObjects9.length = 0;
gdjs.Area1_462Code.GDCollision_9595MaskObjects1.length = 0;
gdjs.Area1_462Code.GDCollision_9595MaskObjects2.length = 0;
gdjs.Area1_462Code.GDCollision_9595MaskObjects3.length = 0;
gdjs.Area1_462Code.GDCollision_9595MaskObjects4.length = 0;
gdjs.Area1_462Code.GDCollision_9595MaskObjects5.length = 0;
gdjs.Area1_462Code.GDCollision_9595MaskObjects6.length = 0;
gdjs.Area1_462Code.GDCollision_9595MaskObjects7.length = 0;
gdjs.Area1_462Code.GDCollision_9595MaskObjects8.length = 0;
gdjs.Area1_462Code.GDCollision_9595MaskObjects9.length = 0;
gdjs.Area1_462Code.GDKing_9595SlimeObjects1.length = 0;
gdjs.Area1_462Code.GDKing_9595SlimeObjects2.length = 0;
gdjs.Area1_462Code.GDKing_9595SlimeObjects3.length = 0;
gdjs.Area1_462Code.GDKing_9595SlimeObjects4.length = 0;
gdjs.Area1_462Code.GDKing_9595SlimeObjects5.length = 0;
gdjs.Area1_462Code.GDKing_9595SlimeObjects6.length = 0;
gdjs.Area1_462Code.GDKing_9595SlimeObjects7.length = 0;
gdjs.Area1_462Code.GDKing_9595SlimeObjects8.length = 0;
gdjs.Area1_462Code.GDKing_9595SlimeObjects9.length = 0;
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects1.length = 0;
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects2.length = 0;
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects3.length = 0;
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects4.length = 0;
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects5.length = 0;
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects6.length = 0;
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects7.length = 0;
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects8.length = 0;
gdjs.Area1_462Code.GDBoss_9595HealthbarObjects9.length = 0;
gdjs.Area1_462Code.GDKing_9595Slime2Objects1.length = 0;
gdjs.Area1_462Code.GDKing_9595Slime2Objects2.length = 0;
gdjs.Area1_462Code.GDKing_9595Slime2Objects3.length = 0;
gdjs.Area1_462Code.GDKing_9595Slime2Objects4.length = 0;
gdjs.Area1_462Code.GDKing_9595Slime2Objects5.length = 0;
gdjs.Area1_462Code.GDKing_9595Slime2Objects6.length = 0;
gdjs.Area1_462Code.GDKing_9595Slime2Objects7.length = 0;
gdjs.Area1_462Code.GDKing_9595Slime2Objects8.length = 0;
gdjs.Area1_462Code.GDKing_9595Slime2Objects9.length = 0;
gdjs.Area1_462Code.GDBarrier2Objects1.length = 0;
gdjs.Area1_462Code.GDBarrier2Objects2.length = 0;
gdjs.Area1_462Code.GDBarrier2Objects3.length = 0;
gdjs.Area1_462Code.GDBarrier2Objects4.length = 0;
gdjs.Area1_462Code.GDBarrier2Objects5.length = 0;
gdjs.Area1_462Code.GDBarrier2Objects6.length = 0;
gdjs.Area1_462Code.GDBarrier2Objects7.length = 0;
gdjs.Area1_462Code.GDBarrier2Objects8.length = 0;
gdjs.Area1_462Code.GDBarrier2Objects9.length = 0;
gdjs.Area1_462Code.GDCollision_9595Mask2Objects1.length = 0;
gdjs.Area1_462Code.GDCollision_9595Mask2Objects2.length = 0;
gdjs.Area1_462Code.GDCollision_9595Mask2Objects3.length = 0;
gdjs.Area1_462Code.GDCollision_9595Mask2Objects4.length = 0;
gdjs.Area1_462Code.GDCollision_9595Mask2Objects5.length = 0;
gdjs.Area1_462Code.GDCollision_9595Mask2Objects6.length = 0;
gdjs.Area1_462Code.GDCollision_9595Mask2Objects7.length = 0;
gdjs.Area1_462Code.GDCollision_9595Mask2Objects8.length = 0;
gdjs.Area1_462Code.GDCollision_9595Mask2Objects9.length = 0;
gdjs.Area1_462Code.GDStaircaseObjects1.length = 0;
gdjs.Area1_462Code.GDStaircaseObjects2.length = 0;
gdjs.Area1_462Code.GDStaircaseObjects3.length = 0;
gdjs.Area1_462Code.GDStaircaseObjects4.length = 0;
gdjs.Area1_462Code.GDStaircaseObjects5.length = 0;
gdjs.Area1_462Code.GDStaircaseObjects6.length = 0;
gdjs.Area1_462Code.GDStaircaseObjects7.length = 0;
gdjs.Area1_462Code.GDStaircaseObjects8.length = 0;
gdjs.Area1_462Code.GDStaircaseObjects9.length = 0;
gdjs.Area1_462Code.GDTESTObjects1.length = 0;
gdjs.Area1_462Code.GDTESTObjects2.length = 0;
gdjs.Area1_462Code.GDTESTObjects3.length = 0;
gdjs.Area1_462Code.GDTESTObjects4.length = 0;
gdjs.Area1_462Code.GDTESTObjects5.length = 0;
gdjs.Area1_462Code.GDTESTObjects6.length = 0;
gdjs.Area1_462Code.GDTESTObjects7.length = 0;
gdjs.Area1_462Code.GDTESTObjects8.length = 0;
gdjs.Area1_462Code.GDTESTObjects9.length = 0;
gdjs.Area1_462Code.GDPlayerObjects1.length = 0;
gdjs.Area1_462Code.GDPlayerObjects2.length = 0;
gdjs.Area1_462Code.GDPlayerObjects3.length = 0;
gdjs.Area1_462Code.GDPlayerObjects4.length = 0;
gdjs.Area1_462Code.GDPlayerObjects5.length = 0;
gdjs.Area1_462Code.GDPlayerObjects6.length = 0;
gdjs.Area1_462Code.GDPlayerObjects7.length = 0;
gdjs.Area1_462Code.GDPlayerObjects8.length = 0;
gdjs.Area1_462Code.GDPlayerObjects9.length = 0;
gdjs.Area1_462Code.GDSlashObjects1.length = 0;
gdjs.Area1_462Code.GDSlashObjects2.length = 0;
gdjs.Area1_462Code.GDSlashObjects3.length = 0;
gdjs.Area1_462Code.GDSlashObjects4.length = 0;
gdjs.Area1_462Code.GDSlashObjects5.length = 0;
gdjs.Area1_462Code.GDSlashObjects6.length = 0;
gdjs.Area1_462Code.GDSlashObjects7.length = 0;
gdjs.Area1_462Code.GDSlashObjects8.length = 0;
gdjs.Area1_462Code.GDSlashObjects9.length = 0;
gdjs.Area1_462Code.GDShadowObjects1.length = 0;
gdjs.Area1_462Code.GDShadowObjects2.length = 0;
gdjs.Area1_462Code.GDShadowObjects3.length = 0;
gdjs.Area1_462Code.GDShadowObjects4.length = 0;
gdjs.Area1_462Code.GDShadowObjects5.length = 0;
gdjs.Area1_462Code.GDShadowObjects6.length = 0;
gdjs.Area1_462Code.GDShadowObjects7.length = 0;
gdjs.Area1_462Code.GDShadowObjects8.length = 0;
gdjs.Area1_462Code.GDShadowObjects9.length = 0;
gdjs.Area1_462Code.GDStatus_9595boxObjects1.length = 0;
gdjs.Area1_462Code.GDStatus_9595boxObjects2.length = 0;
gdjs.Area1_462Code.GDStatus_9595boxObjects3.length = 0;
gdjs.Area1_462Code.GDStatus_9595boxObjects4.length = 0;
gdjs.Area1_462Code.GDStatus_9595boxObjects5.length = 0;
gdjs.Area1_462Code.GDStatus_9595boxObjects6.length = 0;
gdjs.Area1_462Code.GDStatus_9595boxObjects7.length = 0;
gdjs.Area1_462Code.GDStatus_9595boxObjects8.length = 0;
gdjs.Area1_462Code.GDStatus_9595boxObjects9.length = 0;
gdjs.Area1_462Code.GDHealthBarObjects1.length = 0;
gdjs.Area1_462Code.GDHealthBarObjects2.length = 0;
gdjs.Area1_462Code.GDHealthBarObjects3.length = 0;
gdjs.Area1_462Code.GDHealthBarObjects4.length = 0;
gdjs.Area1_462Code.GDHealthBarObjects5.length = 0;
gdjs.Area1_462Code.GDHealthBarObjects6.length = 0;
gdjs.Area1_462Code.GDHealthBarObjects7.length = 0;
gdjs.Area1_462Code.GDHealthBarObjects8.length = 0;
gdjs.Area1_462Code.GDHealthBarObjects9.length = 0;
gdjs.Area1_462Code.GDTargetObjects1.length = 0;
gdjs.Area1_462Code.GDTargetObjects2.length = 0;
gdjs.Area1_462Code.GDTargetObjects3.length = 0;
gdjs.Area1_462Code.GDTargetObjects4.length = 0;
gdjs.Area1_462Code.GDTargetObjects5.length = 0;
gdjs.Area1_462Code.GDTargetObjects6.length = 0;
gdjs.Area1_462Code.GDTargetObjects7.length = 0;
gdjs.Area1_462Code.GDTargetObjects8.length = 0;
gdjs.Area1_462Code.GDTargetObjects9.length = 0;
gdjs.Area1_462Code.GDHPObjects1.length = 0;
gdjs.Area1_462Code.GDHPObjects2.length = 0;
gdjs.Area1_462Code.GDHPObjects3.length = 0;
gdjs.Area1_462Code.GDHPObjects4.length = 0;
gdjs.Area1_462Code.GDHPObjects5.length = 0;
gdjs.Area1_462Code.GDHPObjects6.length = 0;
gdjs.Area1_462Code.GDHPObjects7.length = 0;
gdjs.Area1_462Code.GDHPObjects8.length = 0;
gdjs.Area1_462Code.GDHPObjects9.length = 0;
gdjs.Area1_462Code.GDLevel_9595numberObjects1.length = 0;
gdjs.Area1_462Code.GDLevel_9595numberObjects2.length = 0;
gdjs.Area1_462Code.GDLevel_9595numberObjects3.length = 0;
gdjs.Area1_462Code.GDLevel_9595numberObjects4.length = 0;
gdjs.Area1_462Code.GDLevel_9595numberObjects5.length = 0;
gdjs.Area1_462Code.GDLevel_9595numberObjects6.length = 0;
gdjs.Area1_462Code.GDLevel_9595numberObjects7.length = 0;
gdjs.Area1_462Code.GDLevel_9595numberObjects8.length = 0;
gdjs.Area1_462Code.GDLevel_9595numberObjects9.length = 0;
gdjs.Area1_462Code.GDplayernameObjects1.length = 0;
gdjs.Area1_462Code.GDplayernameObjects2.length = 0;
gdjs.Area1_462Code.GDplayernameObjects3.length = 0;
gdjs.Area1_462Code.GDplayernameObjects4.length = 0;
gdjs.Area1_462Code.GDplayernameObjects5.length = 0;
gdjs.Area1_462Code.GDplayernameObjects6.length = 0;
gdjs.Area1_462Code.GDplayernameObjects7.length = 0;
gdjs.Area1_462Code.GDplayernameObjects8.length = 0;
gdjs.Area1_462Code.GDplayernameObjects9.length = 0;
gdjs.Area1_462Code.GDScreenObjects1.length = 0;
gdjs.Area1_462Code.GDScreenObjects2.length = 0;
gdjs.Area1_462Code.GDScreenObjects3.length = 0;
gdjs.Area1_462Code.GDScreenObjects4.length = 0;
gdjs.Area1_462Code.GDScreenObjects5.length = 0;
gdjs.Area1_462Code.GDScreenObjects6.length = 0;
gdjs.Area1_462Code.GDScreenObjects7.length = 0;
gdjs.Area1_462Code.GDScreenObjects8.length = 0;
gdjs.Area1_462Code.GDScreenObjects9.length = 0;
gdjs.Area1_462Code.GDMenuObjects1.length = 0;
gdjs.Area1_462Code.GDMenuObjects2.length = 0;
gdjs.Area1_462Code.GDMenuObjects3.length = 0;
gdjs.Area1_462Code.GDMenuObjects4.length = 0;
gdjs.Area1_462Code.GDMenuObjects5.length = 0;
gdjs.Area1_462Code.GDMenuObjects6.length = 0;
gdjs.Area1_462Code.GDMenuObjects7.length = 0;
gdjs.Area1_462Code.GDMenuObjects8.length = 0;
gdjs.Area1_462Code.GDMenuObjects9.length = 0;
gdjs.Area1_462Code.GDHealthemptyObjects1.length = 0;
gdjs.Area1_462Code.GDHealthemptyObjects2.length = 0;
gdjs.Area1_462Code.GDHealthemptyObjects3.length = 0;
gdjs.Area1_462Code.GDHealthemptyObjects4.length = 0;
gdjs.Area1_462Code.GDHealthemptyObjects5.length = 0;
gdjs.Area1_462Code.GDHealthemptyObjects6.length = 0;
gdjs.Area1_462Code.GDHealthemptyObjects7.length = 0;
gdjs.Area1_462Code.GDHealthemptyObjects8.length = 0;
gdjs.Area1_462Code.GDHealthemptyObjects9.length = 0;
gdjs.Area1_462Code.GDPotionObjects1.length = 0;
gdjs.Area1_462Code.GDPotionObjects2.length = 0;
gdjs.Area1_462Code.GDPotionObjects3.length = 0;
gdjs.Area1_462Code.GDPotionObjects4.length = 0;
gdjs.Area1_462Code.GDPotionObjects5.length = 0;
gdjs.Area1_462Code.GDPotionObjects6.length = 0;
gdjs.Area1_462Code.GDPotionObjects7.length = 0;
gdjs.Area1_462Code.GDPotionObjects8.length = 0;
gdjs.Area1_462Code.GDPotionObjects9.length = 0;
gdjs.Area1_462Code.GDPotion_9595boxObjects1.length = 0;
gdjs.Area1_462Code.GDPotion_9595boxObjects2.length = 0;
gdjs.Area1_462Code.GDPotion_9595boxObjects3.length = 0;
gdjs.Area1_462Code.GDPotion_9595boxObjects4.length = 0;
gdjs.Area1_462Code.GDPotion_9595boxObjects5.length = 0;
gdjs.Area1_462Code.GDPotion_9595boxObjects6.length = 0;
gdjs.Area1_462Code.GDPotion_9595boxObjects7.length = 0;
gdjs.Area1_462Code.GDPotion_9595boxObjects8.length = 0;
gdjs.Area1_462Code.GDPotion_9595boxObjects9.length = 0;
gdjs.Area1_462Code.GDPotion_9595numberObjects1.length = 0;
gdjs.Area1_462Code.GDPotion_9595numberObjects2.length = 0;
gdjs.Area1_462Code.GDPotion_9595numberObjects3.length = 0;
gdjs.Area1_462Code.GDPotion_9595numberObjects4.length = 0;
gdjs.Area1_462Code.GDPotion_9595numberObjects5.length = 0;
gdjs.Area1_462Code.GDPotion_9595numberObjects6.length = 0;
gdjs.Area1_462Code.GDPotion_9595numberObjects7.length = 0;
gdjs.Area1_462Code.GDPotion_9595numberObjects8.length = 0;
gdjs.Area1_462Code.GDPotion_9595numberObjects9.length = 0;
gdjs.Area1_462Code.GDTImerObjects1.length = 0;
gdjs.Area1_462Code.GDTImerObjects2.length = 0;
gdjs.Area1_462Code.GDTImerObjects3.length = 0;
gdjs.Area1_462Code.GDTImerObjects4.length = 0;
gdjs.Area1_462Code.GDTImerObjects5.length = 0;
gdjs.Area1_462Code.GDTImerObjects6.length = 0;
gdjs.Area1_462Code.GDTImerObjects7.length = 0;
gdjs.Area1_462Code.GDTImerObjects8.length = 0;
gdjs.Area1_462Code.GDTImerObjects9.length = 0;
gdjs.Area1_462Code.GDKillcountObjects1.length = 0;
gdjs.Area1_462Code.GDKillcountObjects2.length = 0;
gdjs.Area1_462Code.GDKillcountObjects3.length = 0;
gdjs.Area1_462Code.GDKillcountObjects4.length = 0;
gdjs.Area1_462Code.GDKillcountObjects5.length = 0;
gdjs.Area1_462Code.GDKillcountObjects6.length = 0;
gdjs.Area1_462Code.GDKillcountObjects7.length = 0;
gdjs.Area1_462Code.GDKillcountObjects8.length = 0;
gdjs.Area1_462Code.GDKillcountObjects9.length = 0;

gdjs.Area1_462Code.eventsList60(runtimeScene);

return;

}

gdjs['Area1_462Code'] = gdjs.Area1_462Code;
