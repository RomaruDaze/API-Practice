gdjs.AlmanacCode = {};
gdjs.AlmanacCode.GDTest_9595TextObjects1= [];
gdjs.AlmanacCode.GDTest_9595TextObjects2= [];
gdjs.AlmanacCode.GDTest_9595TextObjects3= [];
gdjs.AlmanacCode.GDTest_9595TextObjects4= [];
gdjs.AlmanacCode.GDTest_9595TextObjects5= [];
gdjs.AlmanacCode.GDTest_9595TextObjects6= [];
gdjs.AlmanacCode.GDTest_9595TextObjects7= [];
gdjs.AlmanacCode.GDSlimeObjects1= [];
gdjs.AlmanacCode.GDSlimeObjects2= [];
gdjs.AlmanacCode.GDSlimeObjects3= [];
gdjs.AlmanacCode.GDSlimeObjects4= [];
gdjs.AlmanacCode.GDSlimeObjects5= [];
gdjs.AlmanacCode.GDSlimeObjects6= [];
gdjs.AlmanacCode.GDSlimeObjects7= [];
gdjs.AlmanacCode.GDBossslimeObjects1= [];
gdjs.AlmanacCode.GDBossslimeObjects2= [];
gdjs.AlmanacCode.GDBossslimeObjects3= [];
gdjs.AlmanacCode.GDBossslimeObjects4= [];
gdjs.AlmanacCode.GDBossslimeObjects5= [];
gdjs.AlmanacCode.GDBossslimeObjects6= [];
gdjs.AlmanacCode.GDBossslimeObjects7= [];
gdjs.AlmanacCode.GDPaimonObjects1= [];
gdjs.AlmanacCode.GDPaimonObjects2= [];
gdjs.AlmanacCode.GDPaimonObjects3= [];
gdjs.AlmanacCode.GDPaimonObjects4= [];
gdjs.AlmanacCode.GDPaimonObjects5= [];
gdjs.AlmanacCode.GDPaimonObjects6= [];
gdjs.AlmanacCode.GDPaimonObjects7= [];
gdjs.AlmanacCode.GDGoblinObjects1= [];
gdjs.AlmanacCode.GDGoblinObjects2= [];
gdjs.AlmanacCode.GDGoblinObjects3= [];
gdjs.AlmanacCode.GDGoblinObjects4= [];
gdjs.AlmanacCode.GDGoblinObjects5= [];
gdjs.AlmanacCode.GDGoblinObjects6= [];
gdjs.AlmanacCode.GDGoblinObjects7= [];
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects1= [];
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects2= [];
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects3= [];
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects4= [];
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects5= [];
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects6= [];
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects7= [];
gdjs.AlmanacCode.GDMammonObjects1= [];
gdjs.AlmanacCode.GDMammonObjects2= [];
gdjs.AlmanacCode.GDMammonObjects3= [];
gdjs.AlmanacCode.GDMammonObjects4= [];
gdjs.AlmanacCode.GDMammonObjects5= [];
gdjs.AlmanacCode.GDMammonObjects6= [];
gdjs.AlmanacCode.GDMammonObjects7= [];
gdjs.AlmanacCode.GDLizardObjects1= [];
gdjs.AlmanacCode.GDLizardObjects2= [];
gdjs.AlmanacCode.GDLizardObjects3= [];
gdjs.AlmanacCode.GDLizardObjects4= [];
gdjs.AlmanacCode.GDLizardObjects5= [];
gdjs.AlmanacCode.GDLizardObjects6= [];
gdjs.AlmanacCode.GDLizardObjects7= [];
gdjs.AlmanacCode.GDDragooneerObjects1= [];
gdjs.AlmanacCode.GDDragooneerObjects2= [];
gdjs.AlmanacCode.GDDragooneerObjects3= [];
gdjs.AlmanacCode.GDDragooneerObjects4= [];
gdjs.AlmanacCode.GDDragooneerObjects5= [];
gdjs.AlmanacCode.GDDragooneerObjects6= [];
gdjs.AlmanacCode.GDDragooneerObjects7= [];
gdjs.AlmanacCode.GDLeviathanObjects1= [];
gdjs.AlmanacCode.GDLeviathanObjects2= [];
gdjs.AlmanacCode.GDLeviathanObjects3= [];
gdjs.AlmanacCode.GDLeviathanObjects4= [];
gdjs.AlmanacCode.GDLeviathanObjects5= [];
gdjs.AlmanacCode.GDLeviathanObjects6= [];
gdjs.AlmanacCode.GDLeviathanObjects7= [];
gdjs.AlmanacCode.GDMageObjects1= [];
gdjs.AlmanacCode.GDMageObjects2= [];
gdjs.AlmanacCode.GDMageObjects3= [];
gdjs.AlmanacCode.GDMageObjects4= [];
gdjs.AlmanacCode.GDMageObjects5= [];
gdjs.AlmanacCode.GDMageObjects6= [];
gdjs.AlmanacCode.GDMageObjects7= [];
gdjs.AlmanacCode.GDNewTiledSpriteObjects1= [];
gdjs.AlmanacCode.GDNewTiledSpriteObjects2= [];
gdjs.AlmanacCode.GDNewTiledSpriteObjects3= [];
gdjs.AlmanacCode.GDNewTiledSpriteObjects4= [];
gdjs.AlmanacCode.GDNewTiledSpriteObjects5= [];
gdjs.AlmanacCode.GDNewTiledSpriteObjects6= [];
gdjs.AlmanacCode.GDNewTiledSpriteObjects7= [];
gdjs.AlmanacCode.GDEnemy_9595spriteObjects1= [];
gdjs.AlmanacCode.GDEnemy_9595spriteObjects2= [];
gdjs.AlmanacCode.GDEnemy_9595spriteObjects3= [];
gdjs.AlmanacCode.GDEnemy_9595spriteObjects4= [];
gdjs.AlmanacCode.GDEnemy_9595spriteObjects5= [];
gdjs.AlmanacCode.GDEnemy_9595spriteObjects6= [];
gdjs.AlmanacCode.GDEnemy_9595spriteObjects7= [];
gdjs.AlmanacCode.GDBackObjects1= [];
gdjs.AlmanacCode.GDBackObjects2= [];
gdjs.AlmanacCode.GDBackObjects3= [];
gdjs.AlmanacCode.GDBackObjects4= [];
gdjs.AlmanacCode.GDBackObjects5= [];
gdjs.AlmanacCode.GDBackObjects6= [];
gdjs.AlmanacCode.GDBackObjects7= [];
gdjs.AlmanacCode.GDPlayerObjects1= [];
gdjs.AlmanacCode.GDPlayerObjects2= [];
gdjs.AlmanacCode.GDPlayerObjects3= [];
gdjs.AlmanacCode.GDPlayerObjects4= [];
gdjs.AlmanacCode.GDPlayerObjects5= [];
gdjs.AlmanacCode.GDPlayerObjects6= [];
gdjs.AlmanacCode.GDPlayerObjects7= [];
gdjs.AlmanacCode.GDSlashObjects1= [];
gdjs.AlmanacCode.GDSlashObjects2= [];
gdjs.AlmanacCode.GDSlashObjects3= [];
gdjs.AlmanacCode.GDSlashObjects4= [];
gdjs.AlmanacCode.GDSlashObjects5= [];
gdjs.AlmanacCode.GDSlashObjects6= [];
gdjs.AlmanacCode.GDSlashObjects7= [];
gdjs.AlmanacCode.GDShadowObjects1= [];
gdjs.AlmanacCode.GDShadowObjects2= [];
gdjs.AlmanacCode.GDShadowObjects3= [];
gdjs.AlmanacCode.GDShadowObjects4= [];
gdjs.AlmanacCode.GDShadowObjects5= [];
gdjs.AlmanacCode.GDShadowObjects6= [];
gdjs.AlmanacCode.GDShadowObjects7= [];
gdjs.AlmanacCode.GDStatus_9595boxObjects1= [];
gdjs.AlmanacCode.GDStatus_9595boxObjects2= [];
gdjs.AlmanacCode.GDStatus_9595boxObjects3= [];
gdjs.AlmanacCode.GDStatus_9595boxObjects4= [];
gdjs.AlmanacCode.GDStatus_9595boxObjects5= [];
gdjs.AlmanacCode.GDStatus_9595boxObjects6= [];
gdjs.AlmanacCode.GDStatus_9595boxObjects7= [];
gdjs.AlmanacCode.GDHealthBarObjects1= [];
gdjs.AlmanacCode.GDHealthBarObjects2= [];
gdjs.AlmanacCode.GDHealthBarObjects3= [];
gdjs.AlmanacCode.GDHealthBarObjects4= [];
gdjs.AlmanacCode.GDHealthBarObjects5= [];
gdjs.AlmanacCode.GDHealthBarObjects6= [];
gdjs.AlmanacCode.GDHealthBarObjects7= [];
gdjs.AlmanacCode.GDTargetObjects1= [];
gdjs.AlmanacCode.GDTargetObjects2= [];
gdjs.AlmanacCode.GDTargetObjects3= [];
gdjs.AlmanacCode.GDTargetObjects4= [];
gdjs.AlmanacCode.GDTargetObjects5= [];
gdjs.AlmanacCode.GDTargetObjects6= [];
gdjs.AlmanacCode.GDTargetObjects7= [];
gdjs.AlmanacCode.GDHPObjects1= [];
gdjs.AlmanacCode.GDHPObjects2= [];
gdjs.AlmanacCode.GDHPObjects3= [];
gdjs.AlmanacCode.GDHPObjects4= [];
gdjs.AlmanacCode.GDHPObjects5= [];
gdjs.AlmanacCode.GDHPObjects6= [];
gdjs.AlmanacCode.GDHPObjects7= [];
gdjs.AlmanacCode.GDLevel_9595numberObjects1= [];
gdjs.AlmanacCode.GDLevel_9595numberObjects2= [];
gdjs.AlmanacCode.GDLevel_9595numberObjects3= [];
gdjs.AlmanacCode.GDLevel_9595numberObjects4= [];
gdjs.AlmanacCode.GDLevel_9595numberObjects5= [];
gdjs.AlmanacCode.GDLevel_9595numberObjects6= [];
gdjs.AlmanacCode.GDLevel_9595numberObjects7= [];
gdjs.AlmanacCode.GDplayernameObjects1= [];
gdjs.AlmanacCode.GDplayernameObjects2= [];
gdjs.AlmanacCode.GDplayernameObjects3= [];
gdjs.AlmanacCode.GDplayernameObjects4= [];
gdjs.AlmanacCode.GDplayernameObjects5= [];
gdjs.AlmanacCode.GDplayernameObjects6= [];
gdjs.AlmanacCode.GDplayernameObjects7= [];
gdjs.AlmanacCode.GDScreenObjects1= [];
gdjs.AlmanacCode.GDScreenObjects2= [];
gdjs.AlmanacCode.GDScreenObjects3= [];
gdjs.AlmanacCode.GDScreenObjects4= [];
gdjs.AlmanacCode.GDScreenObjects5= [];
gdjs.AlmanacCode.GDScreenObjects6= [];
gdjs.AlmanacCode.GDScreenObjects7= [];
gdjs.AlmanacCode.GDMenuObjects1= [];
gdjs.AlmanacCode.GDMenuObjects2= [];
gdjs.AlmanacCode.GDMenuObjects3= [];
gdjs.AlmanacCode.GDMenuObjects4= [];
gdjs.AlmanacCode.GDMenuObjects5= [];
gdjs.AlmanacCode.GDMenuObjects6= [];
gdjs.AlmanacCode.GDMenuObjects7= [];
gdjs.AlmanacCode.GDHealthemptyObjects1= [];
gdjs.AlmanacCode.GDHealthemptyObjects2= [];
gdjs.AlmanacCode.GDHealthemptyObjects3= [];
gdjs.AlmanacCode.GDHealthemptyObjects4= [];
gdjs.AlmanacCode.GDHealthemptyObjects5= [];
gdjs.AlmanacCode.GDHealthemptyObjects6= [];
gdjs.AlmanacCode.GDHealthemptyObjects7= [];
gdjs.AlmanacCode.GDPotionObjects1= [];
gdjs.AlmanacCode.GDPotionObjects2= [];
gdjs.AlmanacCode.GDPotionObjects3= [];
gdjs.AlmanacCode.GDPotionObjects4= [];
gdjs.AlmanacCode.GDPotionObjects5= [];
gdjs.AlmanacCode.GDPotionObjects6= [];
gdjs.AlmanacCode.GDPotionObjects7= [];
gdjs.AlmanacCode.GDPotion_9595boxObjects1= [];
gdjs.AlmanacCode.GDPotion_9595boxObjects2= [];
gdjs.AlmanacCode.GDPotion_9595boxObjects3= [];
gdjs.AlmanacCode.GDPotion_9595boxObjects4= [];
gdjs.AlmanacCode.GDPotion_9595boxObjects5= [];
gdjs.AlmanacCode.GDPotion_9595boxObjects6= [];
gdjs.AlmanacCode.GDPotion_9595boxObjects7= [];
gdjs.AlmanacCode.GDPotion_9595numberObjects1= [];
gdjs.AlmanacCode.GDPotion_9595numberObjects2= [];
gdjs.AlmanacCode.GDPotion_9595numberObjects3= [];
gdjs.AlmanacCode.GDPotion_9595numberObjects4= [];
gdjs.AlmanacCode.GDPotion_9595numberObjects5= [];
gdjs.AlmanacCode.GDPotion_9595numberObjects6= [];
gdjs.AlmanacCode.GDPotion_9595numberObjects7= [];
gdjs.AlmanacCode.GDTImerObjects1= [];
gdjs.AlmanacCode.GDTImerObjects2= [];
gdjs.AlmanacCode.GDTImerObjects3= [];
gdjs.AlmanacCode.GDTImerObjects4= [];
gdjs.AlmanacCode.GDTImerObjects5= [];
gdjs.AlmanacCode.GDTImerObjects6= [];
gdjs.AlmanacCode.GDTImerObjects7= [];
gdjs.AlmanacCode.GDKillcountObjects1= [];
gdjs.AlmanacCode.GDKillcountObjects2= [];
gdjs.AlmanacCode.GDKillcountObjects3= [];
gdjs.AlmanacCode.GDKillcountObjects4= [];
gdjs.AlmanacCode.GDKillcountObjects5= [];
gdjs.AlmanacCode.GDKillcountObjects6= [];
gdjs.AlmanacCode.GDKillcountObjects7= [];


gdjs.AlmanacCode.asyncCallback8711164 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Test_Text"), gdjs.AlmanacCode.GDTest_9595TextObjects7);
{for(var i = 0, len = gdjs.AlmanacCode.GDTest_9595TextObjects7.length ;i < len;++i) {
    gdjs.AlmanacCode.GDTest_9595TextObjects7[i].setBBText("INFO : " + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Attack     : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Defense    : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Speed      : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "HP         : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Experience : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
}}
gdjs.AlmanacCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8711164(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8710620 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8710620(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8709524 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8709524(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8708492 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8708492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8707460 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8707460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.eventsList5 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.AlmanacCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.AlmanacCode.asyncCallback8711165 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Test_Text"), gdjs.AlmanacCode.GDTest_9595TextObjects7);
{for(var i = 0, len = gdjs.AlmanacCode.GDTest_9595TextObjects7.length ;i < len;++i) {
    gdjs.AlmanacCode.GDTest_9595TextObjects7[i].setBBText("INFO : " + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Attack     : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Defense    : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Speed      : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "HP         : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Experience : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
}}
gdjs.AlmanacCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8711165(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8710621 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8710621(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8709525 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8709525(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8708493 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8708493(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8707461 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8707461(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.eventsList11 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.AlmanacCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.AlmanacCode.asyncCallback8711166 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Test_Text"), gdjs.AlmanacCode.GDTest_9595TextObjects7);
{for(var i = 0, len = gdjs.AlmanacCode.GDTest_9595TextObjects7.length ;i < len;++i) {
    gdjs.AlmanacCode.GDTest_9595TextObjects7[i].setBBText("INFO : " + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Attack     : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Defense    : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Speed      : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "HP         : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Experience : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
}}
gdjs.AlmanacCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8711166(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8710622 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8710622(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8709526 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList14 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8709526(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8708494 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8708494(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8707462 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8707462(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.eventsList17 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.AlmanacCode.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.AlmanacCode.asyncCallback8711167 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Test_Text"), gdjs.AlmanacCode.GDTest_9595TextObjects7);
{for(var i = 0, len = gdjs.AlmanacCode.GDTest_9595TextObjects7.length ;i < len;++i) {
    gdjs.AlmanacCode.GDTest_9595TextObjects7[i].setBBText("INFO : " + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Attack     : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Defense    : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Speed      : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "HP         : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Experience : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
}}
gdjs.AlmanacCode.eventsList18 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8711167(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8710623 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList18(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList19 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8710623(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8709527 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList19(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList20 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8709527(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8708495 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList20(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList21 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8708495(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8707463 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList21(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8707463(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.eventsList23 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.AlmanacCode.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.AlmanacCode.asyncCallback8711168 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Test_Text"), gdjs.AlmanacCode.GDTest_9595TextObjects7);
{for(var i = 0, len = gdjs.AlmanacCode.GDTest_9595TextObjects7.length ;i < len;++i) {
    gdjs.AlmanacCode.GDTest_9595TextObjects7[i].setBBText("INFO : " + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Attack     : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Defense    : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Speed      : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "HP         : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Experience : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
}}
gdjs.AlmanacCode.eventsList24 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8711168(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8710624 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList24(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8710624(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8709528 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8709528(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8708496 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8708496(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8707464 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8707464(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.eventsList29 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.AlmanacCode.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.AlmanacCode.asyncCallback8711169 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Test_Text"), gdjs.AlmanacCode.GDTest_9595TextObjects7);
{for(var i = 0, len = gdjs.AlmanacCode.GDTest_9595TextObjects7.length ;i < len;++i) {
    gdjs.AlmanacCode.GDTest_9595TextObjects7[i].setBBText("INFO : " + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Attack     : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Defense    : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Speed      : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "HP         : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Experience : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
}}
gdjs.AlmanacCode.eventsList30 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8711169(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8710625 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList30(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList31 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8710625(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8709529 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList31(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList32 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8709529(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8708497 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList32(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList33 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8708497(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8707465 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList33(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList34 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8707465(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.eventsList35 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.AlmanacCode.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.AlmanacCode.asyncCallback8711170 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Test_Text"), gdjs.AlmanacCode.GDTest_9595TextObjects7);
{for(var i = 0, len = gdjs.AlmanacCode.GDTest_9595TextObjects7.length ;i < len;++i) {
    gdjs.AlmanacCode.GDTest_9595TextObjects7[i].setBBText("INFO : " + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Attack     : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Defense    : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Speed      : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "HP         : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Experience : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
}}
gdjs.AlmanacCode.eventsList36 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8711170(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8710626 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList36(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList37 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8710626(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8709530 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList37(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList38 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8709530(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8708498 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList38(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList39 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8708498(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8707466 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList39(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList40 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8707466(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.eventsList41 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.AlmanacCode.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.AlmanacCode.asyncCallback8711171 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Test_Text"), gdjs.AlmanacCode.GDTest_9595TextObjects7);
{for(var i = 0, len = gdjs.AlmanacCode.GDTest_9595TextObjects7.length ;i < len;++i) {
    gdjs.AlmanacCode.GDTest_9595TextObjects7[i].setBBText("INFO : " + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Attack     : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Defense    : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Speed      : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "HP         : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Experience : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
}}
gdjs.AlmanacCode.eventsList42 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8711171(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8710627 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList42(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList43 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8710627(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8709531 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList43(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList44 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8709531(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8708499 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList44(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList45 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8708499(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8707467 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList45(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList46 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8707467(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.eventsList47 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.AlmanacCode.eventsList46(runtimeScene);} //End of subevents
}

}


};gdjs.AlmanacCode.asyncCallback8711172 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Test_Text"), gdjs.AlmanacCode.GDTest_9595TextObjects7);
{for(var i = 0, len = gdjs.AlmanacCode.GDTest_9595TextObjects7.length ;i < len;++i) {
    gdjs.AlmanacCode.GDTest_9595TextObjects7[i].setBBText("INFO : " + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Attack     : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Defense    : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Speed      : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "HP         : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Experience : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
}}
gdjs.AlmanacCode.eventsList48 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8711172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8710628 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList48(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList49 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8710628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8709532 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList49(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList50 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8709532(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8708500 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList50(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList51 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8708500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8707468 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList51(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList52 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8707468(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.eventsList53 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.AlmanacCode.eventsList52(runtimeScene);} //End of subevents
}

}


};gdjs.AlmanacCode.asyncCallback8711173 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Test_Text"), gdjs.AlmanacCode.GDTest_9595TextObjects6);
{for(var i = 0, len = gdjs.AlmanacCode.GDTest_9595TextObjects6.length ;i < len;++i) {
    gdjs.AlmanacCode.GDTest_9595TextObjects6[i].setBBText("INFO : " + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Attack     : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Defense    : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Speed      : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "HP         : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Experience : " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
}}
gdjs.AlmanacCode.eventsList54 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8711173(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8710629 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList54(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList55 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8710629(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8709533 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList55(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList56 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8709533(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8708501 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList56(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList57 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8708501(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.asyncCallback8707469 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AlmanacCode.eventsList57(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AlmanacCode.eventsList58 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk" + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.AlmanacCode.asyncCallback8707469(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AlmanacCode.eventsList59 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.AlmanacCode.eventsList58(runtimeScene);} //End of subevents
}

}


};gdjs.AlmanacCode.eventsList60 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.AlmanacCode.GDSlimeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AlmanacCode.GDSlimeObjects2.length;i<l;++i) {
    if ( gdjs.AlmanacCode.GDSlimeObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AlmanacCode.GDSlimeObjects2[k] = gdjs.AlmanacCode.GDSlimeObjects2[i];
        ++k;
    }
}
gdjs.AlmanacCode.GDSlimeObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Enemy_sprite"), gdjs.AlmanacCode.GDEnemy_9595spriteObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("slime");
}{for(var i = 0, len = gdjs.AlmanacCode.GDEnemy_9595spriteObjects2.length ;i < len;++i) {
    gdjs.AlmanacCode.GDEnemy_9595spriteObjects2[i].getBehavior("Animation").setAnimationName("SLIME");
}
}
{ //Subevents
gdjs.AlmanacCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bossslime"), gdjs.AlmanacCode.GDBossslimeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AlmanacCode.GDBossslimeObjects2.length;i<l;++i) {
    if ( gdjs.AlmanacCode.GDBossslimeObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AlmanacCode.GDBossslimeObjects2[k] = gdjs.AlmanacCode.GDBossslimeObjects2[i];
        ++k;
    }
}
gdjs.AlmanacCode.GDBossslimeObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Enemy_sprite"), gdjs.AlmanacCode.GDEnemy_9595spriteObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("boss_slime");
}{for(var i = 0, len = gdjs.AlmanacCode.GDEnemy_9595spriteObjects2.length ;i < len;++i) {
    gdjs.AlmanacCode.GDEnemy_9595spriteObjects2[i].getBehavior("Animation").setAnimationName("BOSSSLIME");
}
}
{ //Subevents
gdjs.AlmanacCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.AlmanacCode.GDPaimonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AlmanacCode.GDPaimonObjects2.length;i<l;++i) {
    if ( gdjs.AlmanacCode.GDPaimonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AlmanacCode.GDPaimonObjects2[k] = gdjs.AlmanacCode.GDPaimonObjects2[i];
        ++k;
    }
}
gdjs.AlmanacCode.GDPaimonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Enemy_sprite"), gdjs.AlmanacCode.GDEnemy_9595spriteObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("paimon");
}{for(var i = 0, len = gdjs.AlmanacCode.GDEnemy_9595spriteObjects2.length ;i < len;++i) {
    gdjs.AlmanacCode.GDEnemy_9595spriteObjects2[i].getBehavior("Animation").setAnimationName("PAIMON");
}
}
{ //Subevents
gdjs.AlmanacCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Goblin"), gdjs.AlmanacCode.GDGoblinObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AlmanacCode.GDGoblinObjects2.length;i<l;++i) {
    if ( gdjs.AlmanacCode.GDGoblinObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AlmanacCode.GDGoblinObjects2[k] = gdjs.AlmanacCode.GDGoblinObjects2[i];
        ++k;
    }
}
gdjs.AlmanacCode.GDGoblinObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("goblin");
}
{ //Subevents
gdjs.AlmanacCode.eventsList23(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Big_Gob_Lin"), gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects2.length;i<l;++i) {
    if ( gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects2[k] = gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects2[i];
        ++k;
    }
}
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("biggoblin");
}
{ //Subevents
gdjs.AlmanacCode.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mammon"), gdjs.AlmanacCode.GDMammonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AlmanacCode.GDMammonObjects2.length;i<l;++i) {
    if ( gdjs.AlmanacCode.GDMammonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AlmanacCode.GDMammonObjects2[k] = gdjs.AlmanacCode.GDMammonObjects2[i];
        ++k;
    }
}
gdjs.AlmanacCode.GDMammonObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("mammon");
}
{ //Subevents
gdjs.AlmanacCode.eventsList35(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lizard"), gdjs.AlmanacCode.GDLizardObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AlmanacCode.GDLizardObjects2.length;i<l;++i) {
    if ( gdjs.AlmanacCode.GDLizardObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AlmanacCode.GDLizardObjects2[k] = gdjs.AlmanacCode.GDLizardObjects2[i];
        ++k;
    }
}
gdjs.AlmanacCode.GDLizardObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("lizard");
}
{ //Subevents
gdjs.AlmanacCode.eventsList41(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dragooneer"), gdjs.AlmanacCode.GDDragooneerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AlmanacCode.GDDragooneerObjects2.length;i<l;++i) {
    if ( gdjs.AlmanacCode.GDDragooneerObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AlmanacCode.GDDragooneerObjects2[k] = gdjs.AlmanacCode.GDDragooneerObjects2[i];
        ++k;
    }
}
gdjs.AlmanacCode.GDDragooneerObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("dragooneer");
}
{ //Subevents
gdjs.AlmanacCode.eventsList47(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Leviathan"), gdjs.AlmanacCode.GDLeviathanObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AlmanacCode.GDLeviathanObjects2.length;i<l;++i) {
    if ( gdjs.AlmanacCode.GDLeviathanObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AlmanacCode.GDLeviathanObjects2[k] = gdjs.AlmanacCode.GDLeviathanObjects2[i];
        ++k;
    }
}
gdjs.AlmanacCode.GDLeviathanObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("leviathan");
}
{ //Subevents
gdjs.AlmanacCode.eventsList53(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mage"), gdjs.AlmanacCode.GDMageObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AlmanacCode.GDMageObjects1.length;i<l;++i) {
    if ( gdjs.AlmanacCode.GDMageObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AlmanacCode.GDMageObjects1[k] = gdjs.AlmanacCode.GDMageObjects1[i];
        ++k;
    }
}
gdjs.AlmanacCode.GDMageObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("mage");
}
{ //Subevents
gdjs.AlmanacCode.eventsList59(runtimeScene);} //End of subevents
}

}


};gdjs.AlmanacCode.eventsList61 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseInsideCanvas(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.AlmanacCode.GDTargetObjects1);
{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.AlmanacCode.GDTargetObjects1.length ;i < len;++i) {
    gdjs.AlmanacCode.GDTargetObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


{


gdjs.AlmanacCode.eventsList60(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.AlmanacCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AlmanacCode.GDBackObjects1.length;i<l;++i) {
    if ( gdjs.AlmanacCode.GDBackObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AlmanacCode.GDBackObjects1[k] = gdjs.AlmanacCode.GDBackObjects1[i];
        ++k;
    }
}
gdjs.AlmanacCode.GDBackObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};

gdjs.AlmanacCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.AlmanacCode.GDTest_9595TextObjects1.length = 0;
gdjs.AlmanacCode.GDTest_9595TextObjects2.length = 0;
gdjs.AlmanacCode.GDTest_9595TextObjects3.length = 0;
gdjs.AlmanacCode.GDTest_9595TextObjects4.length = 0;
gdjs.AlmanacCode.GDTest_9595TextObjects5.length = 0;
gdjs.AlmanacCode.GDTest_9595TextObjects6.length = 0;
gdjs.AlmanacCode.GDTest_9595TextObjects7.length = 0;
gdjs.AlmanacCode.GDSlimeObjects1.length = 0;
gdjs.AlmanacCode.GDSlimeObjects2.length = 0;
gdjs.AlmanacCode.GDSlimeObjects3.length = 0;
gdjs.AlmanacCode.GDSlimeObjects4.length = 0;
gdjs.AlmanacCode.GDSlimeObjects5.length = 0;
gdjs.AlmanacCode.GDSlimeObjects6.length = 0;
gdjs.AlmanacCode.GDSlimeObjects7.length = 0;
gdjs.AlmanacCode.GDBossslimeObjects1.length = 0;
gdjs.AlmanacCode.GDBossslimeObjects2.length = 0;
gdjs.AlmanacCode.GDBossslimeObjects3.length = 0;
gdjs.AlmanacCode.GDBossslimeObjects4.length = 0;
gdjs.AlmanacCode.GDBossslimeObjects5.length = 0;
gdjs.AlmanacCode.GDBossslimeObjects6.length = 0;
gdjs.AlmanacCode.GDBossslimeObjects7.length = 0;
gdjs.AlmanacCode.GDPaimonObjects1.length = 0;
gdjs.AlmanacCode.GDPaimonObjects2.length = 0;
gdjs.AlmanacCode.GDPaimonObjects3.length = 0;
gdjs.AlmanacCode.GDPaimonObjects4.length = 0;
gdjs.AlmanacCode.GDPaimonObjects5.length = 0;
gdjs.AlmanacCode.GDPaimonObjects6.length = 0;
gdjs.AlmanacCode.GDPaimonObjects7.length = 0;
gdjs.AlmanacCode.GDGoblinObjects1.length = 0;
gdjs.AlmanacCode.GDGoblinObjects2.length = 0;
gdjs.AlmanacCode.GDGoblinObjects3.length = 0;
gdjs.AlmanacCode.GDGoblinObjects4.length = 0;
gdjs.AlmanacCode.GDGoblinObjects5.length = 0;
gdjs.AlmanacCode.GDGoblinObjects6.length = 0;
gdjs.AlmanacCode.GDGoblinObjects7.length = 0;
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects1.length = 0;
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects2.length = 0;
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects3.length = 0;
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects4.length = 0;
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects5.length = 0;
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects6.length = 0;
gdjs.AlmanacCode.GDBig_9595Gob_9595LinObjects7.length = 0;
gdjs.AlmanacCode.GDMammonObjects1.length = 0;
gdjs.AlmanacCode.GDMammonObjects2.length = 0;
gdjs.AlmanacCode.GDMammonObjects3.length = 0;
gdjs.AlmanacCode.GDMammonObjects4.length = 0;
gdjs.AlmanacCode.GDMammonObjects5.length = 0;
gdjs.AlmanacCode.GDMammonObjects6.length = 0;
gdjs.AlmanacCode.GDMammonObjects7.length = 0;
gdjs.AlmanacCode.GDLizardObjects1.length = 0;
gdjs.AlmanacCode.GDLizardObjects2.length = 0;
gdjs.AlmanacCode.GDLizardObjects3.length = 0;
gdjs.AlmanacCode.GDLizardObjects4.length = 0;
gdjs.AlmanacCode.GDLizardObjects5.length = 0;
gdjs.AlmanacCode.GDLizardObjects6.length = 0;
gdjs.AlmanacCode.GDLizardObjects7.length = 0;
gdjs.AlmanacCode.GDDragooneerObjects1.length = 0;
gdjs.AlmanacCode.GDDragooneerObjects2.length = 0;
gdjs.AlmanacCode.GDDragooneerObjects3.length = 0;
gdjs.AlmanacCode.GDDragooneerObjects4.length = 0;
gdjs.AlmanacCode.GDDragooneerObjects5.length = 0;
gdjs.AlmanacCode.GDDragooneerObjects6.length = 0;
gdjs.AlmanacCode.GDDragooneerObjects7.length = 0;
gdjs.AlmanacCode.GDLeviathanObjects1.length = 0;
gdjs.AlmanacCode.GDLeviathanObjects2.length = 0;
gdjs.AlmanacCode.GDLeviathanObjects3.length = 0;
gdjs.AlmanacCode.GDLeviathanObjects4.length = 0;
gdjs.AlmanacCode.GDLeviathanObjects5.length = 0;
gdjs.AlmanacCode.GDLeviathanObjects6.length = 0;
gdjs.AlmanacCode.GDLeviathanObjects7.length = 0;
gdjs.AlmanacCode.GDMageObjects1.length = 0;
gdjs.AlmanacCode.GDMageObjects2.length = 0;
gdjs.AlmanacCode.GDMageObjects3.length = 0;
gdjs.AlmanacCode.GDMageObjects4.length = 0;
gdjs.AlmanacCode.GDMageObjects5.length = 0;
gdjs.AlmanacCode.GDMageObjects6.length = 0;
gdjs.AlmanacCode.GDMageObjects7.length = 0;
gdjs.AlmanacCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.AlmanacCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.AlmanacCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.AlmanacCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.AlmanacCode.GDNewTiledSpriteObjects5.length = 0;
gdjs.AlmanacCode.GDNewTiledSpriteObjects6.length = 0;
gdjs.AlmanacCode.GDNewTiledSpriteObjects7.length = 0;
gdjs.AlmanacCode.GDEnemy_9595spriteObjects1.length = 0;
gdjs.AlmanacCode.GDEnemy_9595spriteObjects2.length = 0;
gdjs.AlmanacCode.GDEnemy_9595spriteObjects3.length = 0;
gdjs.AlmanacCode.GDEnemy_9595spriteObjects4.length = 0;
gdjs.AlmanacCode.GDEnemy_9595spriteObjects5.length = 0;
gdjs.AlmanacCode.GDEnemy_9595spriteObjects6.length = 0;
gdjs.AlmanacCode.GDEnemy_9595spriteObjects7.length = 0;
gdjs.AlmanacCode.GDBackObjects1.length = 0;
gdjs.AlmanacCode.GDBackObjects2.length = 0;
gdjs.AlmanacCode.GDBackObjects3.length = 0;
gdjs.AlmanacCode.GDBackObjects4.length = 0;
gdjs.AlmanacCode.GDBackObjects5.length = 0;
gdjs.AlmanacCode.GDBackObjects6.length = 0;
gdjs.AlmanacCode.GDBackObjects7.length = 0;
gdjs.AlmanacCode.GDPlayerObjects1.length = 0;
gdjs.AlmanacCode.GDPlayerObjects2.length = 0;
gdjs.AlmanacCode.GDPlayerObjects3.length = 0;
gdjs.AlmanacCode.GDPlayerObjects4.length = 0;
gdjs.AlmanacCode.GDPlayerObjects5.length = 0;
gdjs.AlmanacCode.GDPlayerObjects6.length = 0;
gdjs.AlmanacCode.GDPlayerObjects7.length = 0;
gdjs.AlmanacCode.GDSlashObjects1.length = 0;
gdjs.AlmanacCode.GDSlashObjects2.length = 0;
gdjs.AlmanacCode.GDSlashObjects3.length = 0;
gdjs.AlmanacCode.GDSlashObjects4.length = 0;
gdjs.AlmanacCode.GDSlashObjects5.length = 0;
gdjs.AlmanacCode.GDSlashObjects6.length = 0;
gdjs.AlmanacCode.GDSlashObjects7.length = 0;
gdjs.AlmanacCode.GDShadowObjects1.length = 0;
gdjs.AlmanacCode.GDShadowObjects2.length = 0;
gdjs.AlmanacCode.GDShadowObjects3.length = 0;
gdjs.AlmanacCode.GDShadowObjects4.length = 0;
gdjs.AlmanacCode.GDShadowObjects5.length = 0;
gdjs.AlmanacCode.GDShadowObjects6.length = 0;
gdjs.AlmanacCode.GDShadowObjects7.length = 0;
gdjs.AlmanacCode.GDStatus_9595boxObjects1.length = 0;
gdjs.AlmanacCode.GDStatus_9595boxObjects2.length = 0;
gdjs.AlmanacCode.GDStatus_9595boxObjects3.length = 0;
gdjs.AlmanacCode.GDStatus_9595boxObjects4.length = 0;
gdjs.AlmanacCode.GDStatus_9595boxObjects5.length = 0;
gdjs.AlmanacCode.GDStatus_9595boxObjects6.length = 0;
gdjs.AlmanacCode.GDStatus_9595boxObjects7.length = 0;
gdjs.AlmanacCode.GDHealthBarObjects1.length = 0;
gdjs.AlmanacCode.GDHealthBarObjects2.length = 0;
gdjs.AlmanacCode.GDHealthBarObjects3.length = 0;
gdjs.AlmanacCode.GDHealthBarObjects4.length = 0;
gdjs.AlmanacCode.GDHealthBarObjects5.length = 0;
gdjs.AlmanacCode.GDHealthBarObjects6.length = 0;
gdjs.AlmanacCode.GDHealthBarObjects7.length = 0;
gdjs.AlmanacCode.GDTargetObjects1.length = 0;
gdjs.AlmanacCode.GDTargetObjects2.length = 0;
gdjs.AlmanacCode.GDTargetObjects3.length = 0;
gdjs.AlmanacCode.GDTargetObjects4.length = 0;
gdjs.AlmanacCode.GDTargetObjects5.length = 0;
gdjs.AlmanacCode.GDTargetObjects6.length = 0;
gdjs.AlmanacCode.GDTargetObjects7.length = 0;
gdjs.AlmanacCode.GDHPObjects1.length = 0;
gdjs.AlmanacCode.GDHPObjects2.length = 0;
gdjs.AlmanacCode.GDHPObjects3.length = 0;
gdjs.AlmanacCode.GDHPObjects4.length = 0;
gdjs.AlmanacCode.GDHPObjects5.length = 0;
gdjs.AlmanacCode.GDHPObjects6.length = 0;
gdjs.AlmanacCode.GDHPObjects7.length = 0;
gdjs.AlmanacCode.GDLevel_9595numberObjects1.length = 0;
gdjs.AlmanacCode.GDLevel_9595numberObjects2.length = 0;
gdjs.AlmanacCode.GDLevel_9595numberObjects3.length = 0;
gdjs.AlmanacCode.GDLevel_9595numberObjects4.length = 0;
gdjs.AlmanacCode.GDLevel_9595numberObjects5.length = 0;
gdjs.AlmanacCode.GDLevel_9595numberObjects6.length = 0;
gdjs.AlmanacCode.GDLevel_9595numberObjects7.length = 0;
gdjs.AlmanacCode.GDplayernameObjects1.length = 0;
gdjs.AlmanacCode.GDplayernameObjects2.length = 0;
gdjs.AlmanacCode.GDplayernameObjects3.length = 0;
gdjs.AlmanacCode.GDplayernameObjects4.length = 0;
gdjs.AlmanacCode.GDplayernameObjects5.length = 0;
gdjs.AlmanacCode.GDplayernameObjects6.length = 0;
gdjs.AlmanacCode.GDplayernameObjects7.length = 0;
gdjs.AlmanacCode.GDScreenObjects1.length = 0;
gdjs.AlmanacCode.GDScreenObjects2.length = 0;
gdjs.AlmanacCode.GDScreenObjects3.length = 0;
gdjs.AlmanacCode.GDScreenObjects4.length = 0;
gdjs.AlmanacCode.GDScreenObjects5.length = 0;
gdjs.AlmanacCode.GDScreenObjects6.length = 0;
gdjs.AlmanacCode.GDScreenObjects7.length = 0;
gdjs.AlmanacCode.GDMenuObjects1.length = 0;
gdjs.AlmanacCode.GDMenuObjects2.length = 0;
gdjs.AlmanacCode.GDMenuObjects3.length = 0;
gdjs.AlmanacCode.GDMenuObjects4.length = 0;
gdjs.AlmanacCode.GDMenuObjects5.length = 0;
gdjs.AlmanacCode.GDMenuObjects6.length = 0;
gdjs.AlmanacCode.GDMenuObjects7.length = 0;
gdjs.AlmanacCode.GDHealthemptyObjects1.length = 0;
gdjs.AlmanacCode.GDHealthemptyObjects2.length = 0;
gdjs.AlmanacCode.GDHealthemptyObjects3.length = 0;
gdjs.AlmanacCode.GDHealthemptyObjects4.length = 0;
gdjs.AlmanacCode.GDHealthemptyObjects5.length = 0;
gdjs.AlmanacCode.GDHealthemptyObjects6.length = 0;
gdjs.AlmanacCode.GDHealthemptyObjects7.length = 0;
gdjs.AlmanacCode.GDPotionObjects1.length = 0;
gdjs.AlmanacCode.GDPotionObjects2.length = 0;
gdjs.AlmanacCode.GDPotionObjects3.length = 0;
gdjs.AlmanacCode.GDPotionObjects4.length = 0;
gdjs.AlmanacCode.GDPotionObjects5.length = 0;
gdjs.AlmanacCode.GDPotionObjects6.length = 0;
gdjs.AlmanacCode.GDPotionObjects7.length = 0;
gdjs.AlmanacCode.GDPotion_9595boxObjects1.length = 0;
gdjs.AlmanacCode.GDPotion_9595boxObjects2.length = 0;
gdjs.AlmanacCode.GDPotion_9595boxObjects3.length = 0;
gdjs.AlmanacCode.GDPotion_9595boxObjects4.length = 0;
gdjs.AlmanacCode.GDPotion_9595boxObjects5.length = 0;
gdjs.AlmanacCode.GDPotion_9595boxObjects6.length = 0;
gdjs.AlmanacCode.GDPotion_9595boxObjects7.length = 0;
gdjs.AlmanacCode.GDPotion_9595numberObjects1.length = 0;
gdjs.AlmanacCode.GDPotion_9595numberObjects2.length = 0;
gdjs.AlmanacCode.GDPotion_9595numberObjects3.length = 0;
gdjs.AlmanacCode.GDPotion_9595numberObjects4.length = 0;
gdjs.AlmanacCode.GDPotion_9595numberObjects5.length = 0;
gdjs.AlmanacCode.GDPotion_9595numberObjects6.length = 0;
gdjs.AlmanacCode.GDPotion_9595numberObjects7.length = 0;
gdjs.AlmanacCode.GDTImerObjects1.length = 0;
gdjs.AlmanacCode.GDTImerObjects2.length = 0;
gdjs.AlmanacCode.GDTImerObjects3.length = 0;
gdjs.AlmanacCode.GDTImerObjects4.length = 0;
gdjs.AlmanacCode.GDTImerObjects5.length = 0;
gdjs.AlmanacCode.GDTImerObjects6.length = 0;
gdjs.AlmanacCode.GDTImerObjects7.length = 0;
gdjs.AlmanacCode.GDKillcountObjects1.length = 0;
gdjs.AlmanacCode.GDKillcountObjects2.length = 0;
gdjs.AlmanacCode.GDKillcountObjects3.length = 0;
gdjs.AlmanacCode.GDKillcountObjects4.length = 0;
gdjs.AlmanacCode.GDKillcountObjects5.length = 0;
gdjs.AlmanacCode.GDKillcountObjects6.length = 0;
gdjs.AlmanacCode.GDKillcountObjects7.length = 0;

gdjs.AlmanacCode.eventsList61(runtimeScene);

return;

}

gdjs['AlmanacCode'] = gdjs.AlmanacCode;
