gdjs.Area1_461Code = {};
gdjs.Area1_461Code.GDMenuObjects2_1final = [];

gdjs.Area1_461Code.GDPotion_9595boxObjects1_1final = [];

gdjs.Area1_461Code.GDGet_9595textObjects1= [];
gdjs.Area1_461Code.GDGet_9595textObjects2= [];
gdjs.Area1_461Code.GDGet_9595textObjects3= [];
gdjs.Area1_461Code.GDGet_9595textObjects4= [];
gdjs.Area1_461Code.GDGet_9595textObjects5= [];
gdjs.Area1_461Code.GDGet_9595textObjects6= [];
gdjs.Area1_461Code.GDGet_9595textObjects7= [];
gdjs.Area1_461Code.GDGet_9595textObjects8= [];
gdjs.Area1_461Code.GDGet_9595textObjects9= [];
gdjs.Area1_461Code.GDFloorObjects1= [];
gdjs.Area1_461Code.GDFloorObjects2= [];
gdjs.Area1_461Code.GDFloorObjects3= [];
gdjs.Area1_461Code.GDFloorObjects4= [];
gdjs.Area1_461Code.GDFloorObjects5= [];
gdjs.Area1_461Code.GDFloorObjects6= [];
gdjs.Area1_461Code.GDFloorObjects7= [];
gdjs.Area1_461Code.GDFloorObjects8= [];
gdjs.Area1_461Code.GDFloorObjects9= [];
gdjs.Area1_461Code.GDWall_9595HorizontalObjects1= [];
gdjs.Area1_461Code.GDWall_9595HorizontalObjects2= [];
gdjs.Area1_461Code.GDWall_9595HorizontalObjects3= [];
gdjs.Area1_461Code.GDWall_9595HorizontalObjects4= [];
gdjs.Area1_461Code.GDWall_9595HorizontalObjects5= [];
gdjs.Area1_461Code.GDWall_9595HorizontalObjects6= [];
gdjs.Area1_461Code.GDWall_9595HorizontalObjects7= [];
gdjs.Area1_461Code.GDWall_9595HorizontalObjects8= [];
gdjs.Area1_461Code.GDWall_9595HorizontalObjects9= [];
gdjs.Area1_461Code.GDSlimeObjects1= [];
gdjs.Area1_461Code.GDSlimeObjects2= [];
gdjs.Area1_461Code.GDSlimeObjects3= [];
gdjs.Area1_461Code.GDSlimeObjects4= [];
gdjs.Area1_461Code.GDSlimeObjects5= [];
gdjs.Area1_461Code.GDSlimeObjects6= [];
gdjs.Area1_461Code.GDSlimeObjects7= [];
gdjs.Area1_461Code.GDSlimeObjects8= [];
gdjs.Area1_461Code.GDSlimeObjects9= [];
gdjs.Area1_461Code.GDKing_9595SlimeObjects1= [];
gdjs.Area1_461Code.GDKing_9595SlimeObjects2= [];
gdjs.Area1_461Code.GDKing_9595SlimeObjects3= [];
gdjs.Area1_461Code.GDKing_9595SlimeObjects4= [];
gdjs.Area1_461Code.GDKing_9595SlimeObjects5= [];
gdjs.Area1_461Code.GDKing_9595SlimeObjects6= [];
gdjs.Area1_461Code.GDKing_9595SlimeObjects7= [];
gdjs.Area1_461Code.GDKing_9595SlimeObjects8= [];
gdjs.Area1_461Code.GDKing_9595SlimeObjects9= [];
gdjs.Area1_461Code.GDExp_9595pointObjects1= [];
gdjs.Area1_461Code.GDExp_9595pointObjects2= [];
gdjs.Area1_461Code.GDExp_9595pointObjects3= [];
gdjs.Area1_461Code.GDExp_9595pointObjects4= [];
gdjs.Area1_461Code.GDExp_9595pointObjects5= [];
gdjs.Area1_461Code.GDExp_9595pointObjects6= [];
gdjs.Area1_461Code.GDExp_9595pointObjects7= [];
gdjs.Area1_461Code.GDExp_9595pointObjects8= [];
gdjs.Area1_461Code.GDExp_9595pointObjects9= [];
gdjs.Area1_461Code.GDWall_9595verticalObjects1= [];
gdjs.Area1_461Code.GDWall_9595verticalObjects2= [];
gdjs.Area1_461Code.GDWall_9595verticalObjects3= [];
gdjs.Area1_461Code.GDWall_9595verticalObjects4= [];
gdjs.Area1_461Code.GDWall_9595verticalObjects5= [];
gdjs.Area1_461Code.GDWall_9595verticalObjects6= [];
gdjs.Area1_461Code.GDWall_9595verticalObjects7= [];
gdjs.Area1_461Code.GDWall_9595verticalObjects8= [];
gdjs.Area1_461Code.GDWall_9595verticalObjects9= [];
gdjs.Area1_461Code.GDCollisionMaskObjects1= [];
gdjs.Area1_461Code.GDCollisionMaskObjects2= [];
gdjs.Area1_461Code.GDCollisionMaskObjects3= [];
gdjs.Area1_461Code.GDCollisionMaskObjects4= [];
gdjs.Area1_461Code.GDCollisionMaskObjects5= [];
gdjs.Area1_461Code.GDCollisionMaskObjects6= [];
gdjs.Area1_461Code.GDCollisionMaskObjects7= [];
gdjs.Area1_461Code.GDCollisionMaskObjects8= [];
gdjs.Area1_461Code.GDCollisionMaskObjects9= [];
gdjs.Area1_461Code.GDChestsObjects1= [];
gdjs.Area1_461Code.GDChestsObjects2= [];
gdjs.Area1_461Code.GDChestsObjects3= [];
gdjs.Area1_461Code.GDChestsObjects4= [];
gdjs.Area1_461Code.GDChestsObjects5= [];
gdjs.Area1_461Code.GDChestsObjects6= [];
gdjs.Area1_461Code.GDChestsObjects7= [];
gdjs.Area1_461Code.GDChestsObjects8= [];
gdjs.Area1_461Code.GDChestsObjects9= [];
gdjs.Area1_461Code.GDDoorObjects1= [];
gdjs.Area1_461Code.GDDoorObjects2= [];
gdjs.Area1_461Code.GDDoorObjects3= [];
gdjs.Area1_461Code.GDDoorObjects4= [];
gdjs.Area1_461Code.GDDoorObjects5= [];
gdjs.Area1_461Code.GDDoorObjects6= [];
gdjs.Area1_461Code.GDDoorObjects7= [];
gdjs.Area1_461Code.GDDoorObjects8= [];
gdjs.Area1_461Code.GDDoorObjects9= [];
gdjs.Area1_461Code.GDDoorMaskObjects1= [];
gdjs.Area1_461Code.GDDoorMaskObjects2= [];
gdjs.Area1_461Code.GDDoorMaskObjects3= [];
gdjs.Area1_461Code.GDDoorMaskObjects4= [];
gdjs.Area1_461Code.GDDoorMaskObjects5= [];
gdjs.Area1_461Code.GDDoorMaskObjects6= [];
gdjs.Area1_461Code.GDDoorMaskObjects7= [];
gdjs.Area1_461Code.GDDoorMaskObjects8= [];
gdjs.Area1_461Code.GDDoorMaskObjects9= [];
gdjs.Area1_461Code.GDMasterChestObjects1= [];
gdjs.Area1_461Code.GDMasterChestObjects2= [];
gdjs.Area1_461Code.GDMasterChestObjects3= [];
gdjs.Area1_461Code.GDMasterChestObjects4= [];
gdjs.Area1_461Code.GDMasterChestObjects5= [];
gdjs.Area1_461Code.GDMasterChestObjects6= [];
gdjs.Area1_461Code.GDMasterChestObjects7= [];
gdjs.Area1_461Code.GDMasterChestObjects8= [];
gdjs.Area1_461Code.GDMasterChestObjects9= [];
gdjs.Area1_461Code.GDMasterDoorObjects1= [];
gdjs.Area1_461Code.GDMasterDoorObjects2= [];
gdjs.Area1_461Code.GDMasterDoorObjects3= [];
gdjs.Area1_461Code.GDMasterDoorObjects4= [];
gdjs.Area1_461Code.GDMasterDoorObjects5= [];
gdjs.Area1_461Code.GDMasterDoorObjects6= [];
gdjs.Area1_461Code.GDMasterDoorObjects7= [];
gdjs.Area1_461Code.GDMasterDoorObjects8= [];
gdjs.Area1_461Code.GDMasterDoorObjects9= [];
gdjs.Area1_461Code.GDBoss_9595HealthObjects1= [];
gdjs.Area1_461Code.GDBoss_9595HealthObjects2= [];
gdjs.Area1_461Code.GDBoss_9595HealthObjects3= [];
gdjs.Area1_461Code.GDBoss_9595HealthObjects4= [];
gdjs.Area1_461Code.GDBoss_9595HealthObjects5= [];
gdjs.Area1_461Code.GDBoss_9595HealthObjects6= [];
gdjs.Area1_461Code.GDBoss_9595HealthObjects7= [];
gdjs.Area1_461Code.GDBoss_9595HealthObjects8= [];
gdjs.Area1_461Code.GDBoss_9595HealthObjects9= [];
gdjs.Area1_461Code.GDbarrierverticalObjects1= [];
gdjs.Area1_461Code.GDbarrierverticalObjects2= [];
gdjs.Area1_461Code.GDbarrierverticalObjects3= [];
gdjs.Area1_461Code.GDbarrierverticalObjects4= [];
gdjs.Area1_461Code.GDbarrierverticalObjects5= [];
gdjs.Area1_461Code.GDbarrierverticalObjects6= [];
gdjs.Area1_461Code.GDbarrierverticalObjects7= [];
gdjs.Area1_461Code.GDbarrierverticalObjects8= [];
gdjs.Area1_461Code.GDbarrierverticalObjects9= [];
gdjs.Area1_461Code.GDBarrierObjects1= [];
gdjs.Area1_461Code.GDBarrierObjects2= [];
gdjs.Area1_461Code.GDBarrierObjects3= [];
gdjs.Area1_461Code.GDBarrierObjects4= [];
gdjs.Area1_461Code.GDBarrierObjects5= [];
gdjs.Area1_461Code.GDBarrierObjects6= [];
gdjs.Area1_461Code.GDBarrierObjects7= [];
gdjs.Area1_461Code.GDBarrierObjects8= [];
gdjs.Area1_461Code.GDBarrierObjects9= [];
gdjs.Area1_461Code.GDbarrierhorizontalObjects1= [];
gdjs.Area1_461Code.GDbarrierhorizontalObjects2= [];
gdjs.Area1_461Code.GDbarrierhorizontalObjects3= [];
gdjs.Area1_461Code.GDbarrierhorizontalObjects4= [];
gdjs.Area1_461Code.GDbarrierhorizontalObjects5= [];
gdjs.Area1_461Code.GDbarrierhorizontalObjects6= [];
gdjs.Area1_461Code.GDbarrierhorizontalObjects7= [];
gdjs.Area1_461Code.GDbarrierhorizontalObjects8= [];
gdjs.Area1_461Code.GDbarrierhorizontalObjects9= [];
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects1= [];
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects2= [];
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3= [];
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects4= [];
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects5= [];
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects6= [];
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects7= [];
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects8= [];
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects9= [];
gdjs.Area1_461Code.GDstaircaseObjects1= [];
gdjs.Area1_461Code.GDstaircaseObjects2= [];
gdjs.Area1_461Code.GDstaircaseObjects3= [];
gdjs.Area1_461Code.GDstaircaseObjects4= [];
gdjs.Area1_461Code.GDstaircaseObjects5= [];
gdjs.Area1_461Code.GDstaircaseObjects6= [];
gdjs.Area1_461Code.GDstaircaseObjects7= [];
gdjs.Area1_461Code.GDstaircaseObjects8= [];
gdjs.Area1_461Code.GDstaircaseObjects9= [];
gdjs.Area1_461Code.GDPlayerObjects1= [];
gdjs.Area1_461Code.GDPlayerObjects2= [];
gdjs.Area1_461Code.GDPlayerObjects3= [];
gdjs.Area1_461Code.GDPlayerObjects4= [];
gdjs.Area1_461Code.GDPlayerObjects5= [];
gdjs.Area1_461Code.GDPlayerObjects6= [];
gdjs.Area1_461Code.GDPlayerObjects7= [];
gdjs.Area1_461Code.GDPlayerObjects8= [];
gdjs.Area1_461Code.GDPlayerObjects9= [];
gdjs.Area1_461Code.GDSlashObjects1= [];
gdjs.Area1_461Code.GDSlashObjects2= [];
gdjs.Area1_461Code.GDSlashObjects3= [];
gdjs.Area1_461Code.GDSlashObjects4= [];
gdjs.Area1_461Code.GDSlashObjects5= [];
gdjs.Area1_461Code.GDSlashObjects6= [];
gdjs.Area1_461Code.GDSlashObjects7= [];
gdjs.Area1_461Code.GDSlashObjects8= [];
gdjs.Area1_461Code.GDSlashObjects9= [];
gdjs.Area1_461Code.GDShadowObjects1= [];
gdjs.Area1_461Code.GDShadowObjects2= [];
gdjs.Area1_461Code.GDShadowObjects3= [];
gdjs.Area1_461Code.GDShadowObjects4= [];
gdjs.Area1_461Code.GDShadowObjects5= [];
gdjs.Area1_461Code.GDShadowObjects6= [];
gdjs.Area1_461Code.GDShadowObjects7= [];
gdjs.Area1_461Code.GDShadowObjects8= [];
gdjs.Area1_461Code.GDShadowObjects9= [];
gdjs.Area1_461Code.GDStatus_9595boxObjects1= [];
gdjs.Area1_461Code.GDStatus_9595boxObjects2= [];
gdjs.Area1_461Code.GDStatus_9595boxObjects3= [];
gdjs.Area1_461Code.GDStatus_9595boxObjects4= [];
gdjs.Area1_461Code.GDStatus_9595boxObjects5= [];
gdjs.Area1_461Code.GDStatus_9595boxObjects6= [];
gdjs.Area1_461Code.GDStatus_9595boxObjects7= [];
gdjs.Area1_461Code.GDStatus_9595boxObjects8= [];
gdjs.Area1_461Code.GDStatus_9595boxObjects9= [];
gdjs.Area1_461Code.GDHealthBarObjects1= [];
gdjs.Area1_461Code.GDHealthBarObjects2= [];
gdjs.Area1_461Code.GDHealthBarObjects3= [];
gdjs.Area1_461Code.GDHealthBarObjects4= [];
gdjs.Area1_461Code.GDHealthBarObjects5= [];
gdjs.Area1_461Code.GDHealthBarObjects6= [];
gdjs.Area1_461Code.GDHealthBarObjects7= [];
gdjs.Area1_461Code.GDHealthBarObjects8= [];
gdjs.Area1_461Code.GDHealthBarObjects9= [];
gdjs.Area1_461Code.GDTargetObjects1= [];
gdjs.Area1_461Code.GDTargetObjects2= [];
gdjs.Area1_461Code.GDTargetObjects3= [];
gdjs.Area1_461Code.GDTargetObjects4= [];
gdjs.Area1_461Code.GDTargetObjects5= [];
gdjs.Area1_461Code.GDTargetObjects6= [];
gdjs.Area1_461Code.GDTargetObjects7= [];
gdjs.Area1_461Code.GDTargetObjects8= [];
gdjs.Area1_461Code.GDTargetObjects9= [];
gdjs.Area1_461Code.GDHPObjects1= [];
gdjs.Area1_461Code.GDHPObjects2= [];
gdjs.Area1_461Code.GDHPObjects3= [];
gdjs.Area1_461Code.GDHPObjects4= [];
gdjs.Area1_461Code.GDHPObjects5= [];
gdjs.Area1_461Code.GDHPObjects6= [];
gdjs.Area1_461Code.GDHPObjects7= [];
gdjs.Area1_461Code.GDHPObjects8= [];
gdjs.Area1_461Code.GDHPObjects9= [];
gdjs.Area1_461Code.GDLevel_9595numberObjects1= [];
gdjs.Area1_461Code.GDLevel_9595numberObjects2= [];
gdjs.Area1_461Code.GDLevel_9595numberObjects3= [];
gdjs.Area1_461Code.GDLevel_9595numberObjects4= [];
gdjs.Area1_461Code.GDLevel_9595numberObjects5= [];
gdjs.Area1_461Code.GDLevel_9595numberObjects6= [];
gdjs.Area1_461Code.GDLevel_9595numberObjects7= [];
gdjs.Area1_461Code.GDLevel_9595numberObjects8= [];
gdjs.Area1_461Code.GDLevel_9595numberObjects9= [];
gdjs.Area1_461Code.GDplayernameObjects1= [];
gdjs.Area1_461Code.GDplayernameObjects2= [];
gdjs.Area1_461Code.GDplayernameObjects3= [];
gdjs.Area1_461Code.GDplayernameObjects4= [];
gdjs.Area1_461Code.GDplayernameObjects5= [];
gdjs.Area1_461Code.GDplayernameObjects6= [];
gdjs.Area1_461Code.GDplayernameObjects7= [];
gdjs.Area1_461Code.GDplayernameObjects8= [];
gdjs.Area1_461Code.GDplayernameObjects9= [];
gdjs.Area1_461Code.GDScreenObjects1= [];
gdjs.Area1_461Code.GDScreenObjects2= [];
gdjs.Area1_461Code.GDScreenObjects3= [];
gdjs.Area1_461Code.GDScreenObjects4= [];
gdjs.Area1_461Code.GDScreenObjects5= [];
gdjs.Area1_461Code.GDScreenObjects6= [];
gdjs.Area1_461Code.GDScreenObjects7= [];
gdjs.Area1_461Code.GDScreenObjects8= [];
gdjs.Area1_461Code.GDScreenObjects9= [];
gdjs.Area1_461Code.GDMenuObjects1= [];
gdjs.Area1_461Code.GDMenuObjects2= [];
gdjs.Area1_461Code.GDMenuObjects3= [];
gdjs.Area1_461Code.GDMenuObjects4= [];
gdjs.Area1_461Code.GDMenuObjects5= [];
gdjs.Area1_461Code.GDMenuObjects6= [];
gdjs.Area1_461Code.GDMenuObjects7= [];
gdjs.Area1_461Code.GDMenuObjects8= [];
gdjs.Area1_461Code.GDMenuObjects9= [];
gdjs.Area1_461Code.GDHealthemptyObjects1= [];
gdjs.Area1_461Code.GDHealthemptyObjects2= [];
gdjs.Area1_461Code.GDHealthemptyObjects3= [];
gdjs.Area1_461Code.GDHealthemptyObjects4= [];
gdjs.Area1_461Code.GDHealthemptyObjects5= [];
gdjs.Area1_461Code.GDHealthemptyObjects6= [];
gdjs.Area1_461Code.GDHealthemptyObjects7= [];
gdjs.Area1_461Code.GDHealthemptyObjects8= [];
gdjs.Area1_461Code.GDHealthemptyObjects9= [];
gdjs.Area1_461Code.GDPotionObjects1= [];
gdjs.Area1_461Code.GDPotionObjects2= [];
gdjs.Area1_461Code.GDPotionObjects3= [];
gdjs.Area1_461Code.GDPotionObjects4= [];
gdjs.Area1_461Code.GDPotionObjects5= [];
gdjs.Area1_461Code.GDPotionObjects6= [];
gdjs.Area1_461Code.GDPotionObjects7= [];
gdjs.Area1_461Code.GDPotionObjects8= [];
gdjs.Area1_461Code.GDPotionObjects9= [];
gdjs.Area1_461Code.GDPotion_9595boxObjects1= [];
gdjs.Area1_461Code.GDPotion_9595boxObjects2= [];
gdjs.Area1_461Code.GDPotion_9595boxObjects3= [];
gdjs.Area1_461Code.GDPotion_9595boxObjects4= [];
gdjs.Area1_461Code.GDPotion_9595boxObjects5= [];
gdjs.Area1_461Code.GDPotion_9595boxObjects6= [];
gdjs.Area1_461Code.GDPotion_9595boxObjects7= [];
gdjs.Area1_461Code.GDPotion_9595boxObjects8= [];
gdjs.Area1_461Code.GDPotion_9595boxObjects9= [];
gdjs.Area1_461Code.GDPotion_9595numberObjects1= [];
gdjs.Area1_461Code.GDPotion_9595numberObjects2= [];
gdjs.Area1_461Code.GDPotion_9595numberObjects3= [];
gdjs.Area1_461Code.GDPotion_9595numberObjects4= [];
gdjs.Area1_461Code.GDPotion_9595numberObjects5= [];
gdjs.Area1_461Code.GDPotion_9595numberObjects6= [];
gdjs.Area1_461Code.GDPotion_9595numberObjects7= [];
gdjs.Area1_461Code.GDPotion_9595numberObjects8= [];
gdjs.Area1_461Code.GDPotion_9595numberObjects9= [];
gdjs.Area1_461Code.GDTImerObjects1= [];
gdjs.Area1_461Code.GDTImerObjects2= [];
gdjs.Area1_461Code.GDTImerObjects3= [];
gdjs.Area1_461Code.GDTImerObjects4= [];
gdjs.Area1_461Code.GDTImerObjects5= [];
gdjs.Area1_461Code.GDTImerObjects6= [];
gdjs.Area1_461Code.GDTImerObjects7= [];
gdjs.Area1_461Code.GDTImerObjects8= [];
gdjs.Area1_461Code.GDTImerObjects9= [];
gdjs.Area1_461Code.GDKillcountObjects1= [];
gdjs.Area1_461Code.GDKillcountObjects2= [];
gdjs.Area1_461Code.GDKillcountObjects3= [];
gdjs.Area1_461Code.GDKillcountObjects4= [];
gdjs.Area1_461Code.GDKillcountObjects5= [];
gdjs.Area1_461Code.GDKillcountObjects6= [];
gdjs.Area1_461Code.GDKillcountObjects7= [];
gdjs.Area1_461Code.GDKillcountObjects8= [];
gdjs.Area1_461Code.GDKillcountObjects9= [];


gdjs.Area1_461Code.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects8);
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects8.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects8[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_461Code.asyncCallback8718772 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)));
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)));
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
{ //Subevents
gdjs.Area1_461Code.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8718772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8718404 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8718404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8710228 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8710228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8709860 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8709860(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8709188 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8709188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects8);
{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects8.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects8[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects8.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects8[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_461Code.asyncCallback8725764 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(16), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8725764(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8724876 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(15), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8724876(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8723900 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(17), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8723900(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8722940 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(14), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8722940(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8722004 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(13), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8722004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects7);

{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects7.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects7[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects7.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects7[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_461Code.asyncCallback8732156 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)));
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9)));
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)));
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(8)));
}
{ //Subevents
gdjs.Area1_461Code.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/maxexp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(9), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8732156(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8731220 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList14 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/hp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(5), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8731220(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8730092 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/spd/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(8), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8730092(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8729028 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList16 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/def/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(7), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8729028(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8727964 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList16(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList17 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_461Code.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/atk/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(6), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8727964(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.eventsList18 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_461Code.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_461Code.eventsList11(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_461Code.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDScreenObjects1Objects = Hashtable.newFrom({"Screen": gdjs.Area1_461Code.GDScreenObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMenuObjects1Objects = Hashtable.newFrom({"Menu": gdjs.Area1_461Code.GDMenuObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDStatus_95959595boxObjects1Objects = Hashtable.newFrom({"Status_box": gdjs.Area1_461Code.GDStatus_9595boxObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDHPObjects1Objects = Hashtable.newFrom({"HP": gdjs.Area1_461Code.GDHPObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDHealthBarObjects1Objects = Hashtable.newFrom({"HealthBar": gdjs.Area1_461Code.GDHealthBarObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDHealthemptyObjects1Objects = Hashtable.newFrom({"Healthempty": gdjs.Area1_461Code.GDHealthemptyObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDTargetObjects1Objects = Hashtable.newFrom({"Target": gdjs.Area1_461Code.GDTargetObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDLevel_95959595numberObjects1Objects = Hashtable.newFrom({"Level_number": gdjs.Area1_461Code.GDLevel_9595numberObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDplayernameObjects1Objects = Hashtable.newFrom({"playername": gdjs.Area1_461Code.GDplayernameObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPotion_95959595boxObjects1Objects = Hashtable.newFrom({"Potion_box": gdjs.Area1_461Code.GDPotion_9595boxObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPotion_95959595numberObjects1Objects = Hashtable.newFrom({"Potion_number": gdjs.Area1_461Code.GDPotion_9595numberObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDTImerObjects1Objects = Hashtable.newFrom({"TImer": gdjs.Area1_461Code.GDTImerObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKillcountObjects1Objects = Hashtable.newFrom({"Killcount": gdjs.Area1_461Code.GDKillcountObjects1});
gdjs.Area1_461Code.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects2);
gdjs.copyArray(gdjs.Area1_461Code.GDScreenObjects1, gdjs.Area1_461Code.GDScreenObjects2);

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects2);
gdjs.copyArray(gdjs.Area1_461Code.GDStatus_9595boxObjects1, gdjs.Area1_461Code.GDStatus_9595boxObjects2);

{for(var i = 0, len = gdjs.Area1_461Code.GDScreenObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDScreenObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDStatus_9595boxObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDStatus_9595boxObjects2[i].getBehavior("Opacity").setOpacity(200);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDStatus_9595boxObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDStatus_9595boxObjects2[i].getBehavior("Resizable").setSize(300, 150);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects2[i].getBehavior("Resizable").setSize(77, 96);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects2[i].getBehavior("Resizable").setSize(97, 126);
}
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Area1_461Code.GDLevel_9595numberObjects1 */
/* Reuse gdjs.Area1_461Code.GDplayernameObjects1 */
{for(var i = 0, len = gdjs.Area1_461Code.GDplayernameObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDplayernameObjects1[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(2).getAsString());
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDLevel_9595numberObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDLevel_9595numberObjects1[i].setBBText("LV. " + runtimeScene.getGame().getVariables().getFromIndex(3).getAsString());
}
}}

}


};gdjs.Area1_461Code.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("slime");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("boss_slime");
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.2, "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Area1_461Code.GDPlayerObjects2.length !== 0 ? gdjs.Area1_461Code.GDPlayerObjects2[0] : null), true, "", 0);
}
{ //Subevents
gdjs.Area1_461Code.eventsList18(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_461Code.GDPotion_9595numberObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(21).setNumber(runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(22).setNumber(runtimeScene.getGame().getVariables().getFromIndex(16).getAsNumber());
}{for(var i = 0, len = gdjs.Area1_461Code.GDPotion_9595numberObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPotion_9595numberObjects2[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(16).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.Area1_461Code.GDHPObjects1.length = 0;

gdjs.Area1_461Code.GDHealthBarObjects1.length = 0;

gdjs.Area1_461Code.GDHealthemptyObjects1.length = 0;

gdjs.Area1_461Code.GDKillcountObjects1.length = 0;

gdjs.Area1_461Code.GDLevel_9595numberObjects1.length = 0;

gdjs.Area1_461Code.GDMenuObjects1.length = 0;

gdjs.Area1_461Code.GDPotion_9595boxObjects1.length = 0;

gdjs.Area1_461Code.GDPotion_9595numberObjects1.length = 0;

gdjs.Area1_461Code.GDScreenObjects1.length = 0;

gdjs.Area1_461Code.GDStatus_9595boxObjects1.length = 0;

gdjs.Area1_461Code.GDTImerObjects1.length = 0;

gdjs.Area1_461Code.GDTargetObjects1.length = 0;

gdjs.Area1_461Code.GDplayernameObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDScreenObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMenuObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDStatus_95959595boxObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDHPObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDHealthBarObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDHealthemptyObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDTargetObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDLevel_95959595numberObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDplayernameObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPotion_95959595boxObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPotion_95959595numberObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDTImerObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKillcountObjects1Objects, 0, 0, "");
}
{ //Subevents
gdjs.Area1_461Code.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HP"), gdjs.Area1_461Code.GDHPObjects2);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_461Code.GDKillcountObjects2);
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_461Code.GDPotion_9595boxObjects2);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_461Code.GDPotion_9595numberObjects2);
gdjs.copyArray(runtimeScene.getObjects("Screen"), gdjs.Area1_461Code.GDScreenObjects2);
gdjs.copyArray(runtimeScene.getObjects("Status_box"), gdjs.Area1_461Code.GDStatus_9595boxObjects2);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Area1_461Code.GDTargetObjects2);
{for(var i = 0, len = gdjs.Area1_461Code.GDStatus_9595boxObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDStatus_9595boxObjects2[i].setZOrder((( gdjs.Area1_461Code.GDHPObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDHPObjects2[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDPotion_9595numberObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPotion_9595numberObjects2[i].setZOrder((( gdjs.Area1_461Code.GDTargetObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDTargetObjects2[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDKillcountObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKillcountObjects2[i].setZOrder((( gdjs.Area1_461Code.GDScreenObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects2[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDPotion_9595boxObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPotion_9595boxObjects2[i].setZOrder((( gdjs.Area1_461Code.GDTargetObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDTargetObjects2[0].getZOrder()) - 2);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.Area1_461Code.GDFloorObjects2);
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_461Code.GDHealthBarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Healthempty"), gdjs.Area1_461Code.GDHealthemptyObjects2);
gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects1, gdjs.Area1_461Code.GDPlayerObjects2);

gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_461Code.GDWall_9595HorizontalObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wall_vertical"), gdjs.Area1_461Code.GDWall_9595verticalObjects2);
gdjs.copyArray(runtimeScene.getObjects("barrierhorizontal"), gdjs.Area1_461Code.GDbarrierhorizontalObjects2);
gdjs.copyArray(runtimeScene.getObjects("barriervertical"), gdjs.Area1_461Code.GDbarrierverticalObjects2);
{for(var i = 0, len = gdjs.Area1_461Code.GDHealthBarObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealthBarObjects2[i].setZOrder((( gdjs.Area1_461Code.GDHealthemptyObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDHealthemptyObjects2[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDFloorObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDFloorObjects2[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getZOrder()) - 5);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDWall_9595HorizontalObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDWall_9595HorizontalObjects2[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDWall_9595verticalObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDWall_9595verticalObjects2[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getZOrder()) - 4);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDbarrierhorizontalObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDbarrierhorizontalObjects2[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getZOrder()) - 4);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDbarrierverticalObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDbarrierverticalObjects2[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getZOrder()) - 4);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Chests"), gdjs.Area1_461Code.GDChestsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.Area1_461Code.GDDoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("MasterChest"), gdjs.Area1_461Code.GDMasterChestObjects2);
gdjs.copyArray(runtimeScene.getObjects("MasterDoor"), gdjs.Area1_461Code.GDMasterDoorObjects2);
gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects1, gdjs.Area1_461Code.GDPlayerObjects2);

{for(var i = 0, len = gdjs.Area1_461Code.GDDoorObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDDoorObjects2[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getZOrder()) - 2);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDMasterDoorObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDMasterDoorObjects2[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getZOrder()) - 2);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDMasterChestObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDMasterChestObjects2[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDChestsObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDChestsObjects2[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getZOrder()) - 1);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects1);
/* Reuse gdjs.Area1_461Code.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects1);
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects1[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects1[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects1[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects1[0].getZOrder()) + 1);
}
}}

}


};gdjs.Area1_461Code.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Shadow"), gdjs.Area1_461Code.GDShadowObjects1);
gdjs.copyArray(runtimeScene.getObjects("staircase"), gdjs.Area1_461Code.GDstaircaseObjects1);
{for(var i = 0, len = gdjs.Area1_461Code.GDShadowObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDShadowObjects1[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects1[0].getZOrder()) - 3);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDstaircaseObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDstaircaseObjects1[i].setZOrder((( gdjs.Area1_461Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects1[0].getZOrder()) - 1);
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.eventsList23 = function(runtimeScene) {

{

gdjs.Area1_461Code.GDMenuObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Area1_461Code.GDMenuObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Area1_461Code.GDMenuObjects3);
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDMenuObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDMenuObjects3[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.Area1_461Code.GDMenuObjects3[k] = gdjs.Area1_461Code.GDMenuObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDMenuObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Area1_461Code.GDMenuObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Area1_461Code.GDMenuObjects2_1final.indexOf(gdjs.Area1_461Code.GDMenuObjects3[j]) === -1 )
            gdjs.Area1_461Code.GDMenuObjects2_1final.push(gdjs.Area1_461Code.GDMenuObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.Area1_461Code.GDMenuObjects2_1final, gdjs.Area1_461Code.GDMenuObjects2);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Menu");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyReleased(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_461Code.GDHealthBarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Area1_461Code.GDHealthBarObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealthBarObjects2[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}}

}


{

gdjs.Area1_461Code.GDPotion_9595boxObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Area1_461Code.GDPotion_9595boxObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_461Code.GDPotion_9595boxObjects2);
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPotion_9595boxObjects2.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDPotion_9595boxObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.Area1_461Code.GDPotion_9595boxObjects2[k] = gdjs.Area1_461Code.GDPotion_9595boxObjects2[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPotion_9595boxObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Area1_461Code.GDPotion_9595boxObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Area1_461Code.GDPotion_9595boxObjects1_1final.indexOf(gdjs.Area1_461Code.GDPotion_9595boxObjects2[j]) === -1 )
            gdjs.Area1_461Code.GDPotion_9595boxObjects1_1final.push(gdjs.Area1_461Code.GDPotion_9595boxObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "f");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.Area1_461Code.GDPotion_9595boxObjects1_1final, gdjs.Area1_461Code.GDPotion_9595boxObjects1);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_461Code.GDHealthBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_461Code.GDPotion_9595numberObjects1);
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects1[i].getBehavior("Health").Heal((gdjs.Area1_461Code.GDPlayerObjects1[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealthBarObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealthBarObjects1[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_461Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_461Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}{runtimeScene.getGame().getVariables().getFromIndex(16).sub(1);
}{for(var i = 0, len = gdjs.Area1_461Code.GDPotion_9595numberObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPotion_9595numberObjects1[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16))) + "x");
}
}}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_461Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_461Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDbarrierhorizontalObjects4Objects = Hashtable.newFrom({"barrierhorizontal": gdjs.Area1_461Code.GDbarrierhorizontalObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDbarrierhorizontalObjects4Objects = Hashtable.newFrom({"barrierhorizontal": gdjs.Area1_461Code.GDbarrierhorizontalObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDbarrierverticalObjects3Objects = Hashtable.newFrom({"barriervertical": gdjs.Area1_461Code.GDbarrierverticalObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDbarrierverticalObjects3Objects = Hashtable.newFrom({"barriervertical": gdjs.Area1_461Code.GDbarrierverticalObjects3});
gdjs.Area1_461Code.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects4);
gdjs.copyArray(runtimeScene.getObjects("barrierhorizontal"), gdjs.Area1_461Code.GDbarrierhorizontalObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDbarrierhorizontalObjects4Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects4 */
/* Reuse gdjs.Area1_461Code.GDbarrierhorizontalObjects4 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects4[i].separateFromObjectsList(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDbarrierhorizontalObjects4Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("barriervertical"), gdjs.Area1_461Code.GDbarrierverticalObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDbarrierverticalObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
/* Reuse gdjs.Area1_461Code.GDbarrierverticalObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects3[i].separateFromObjectsList(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDbarrierverticalObjects3Objects, false);
}
}}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDBarrierObjects3Objects = Hashtable.newFrom({"Barrier": gdjs.Area1_461Code.GDBarrierObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDBoss_95959595HealthObjects3Objects = Hashtable.newFrom({"Boss_Health": gdjs.Area1_461Code.GDBoss_9595HealthObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDHealth_95959595boss_95959595emptyObjects3Objects = Hashtable.newFrom({"Health_boss_empty": gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPotionObjects3Objects = Hashtable.newFrom({"Potion": gdjs.Area1_461Code.GDPotionObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects5Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects5});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects5Objects = Hashtable.newFrom({"Slime": gdjs.Area1_461Code.GDSlimeObjects5});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects5Objects = Hashtable.newFrom({"Slime": gdjs.Area1_461Code.GDSlimeObjects5});
gdjs.Area1_461Code.asyncCallback11910756 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects6[i].getBehavior("ShakeObject_PositionAngleScale").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Area1_461Code.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_461Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback11910756(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects5, gdjs.Area1_461Code.GDPlayerObjects6);

gdjs.copyArray(gdjs.Area1_461Code.GDSlimeObjects5, gdjs.Area1_461Code.GDSlimeObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_461Code.GDPlayerObjects6.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects6[0].getPointY("Center")) - (( gdjs.Area1_461Code.GDSlimeObjects6.length === 0 ) ? 0 :gdjs.Area1_461Code.GDSlimeObjects6[0].getPointY("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects6 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects6[i].addForceTowardPosition((gdjs.Area1_461Code.GDPlayerObjects6[i].getPointX("Center")), (gdjs.Area1_461Code.GDPlayerObjects6[i].getPointY("Center")) - 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects5, gdjs.Area1_461Code.GDPlayerObjects6);

gdjs.copyArray(gdjs.Area1_461Code.GDSlimeObjects5, gdjs.Area1_461Code.GDSlimeObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_461Code.GDPlayerObjects6.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects6[0].getPointY("Center")) - (( gdjs.Area1_461Code.GDSlimeObjects6.length === 0 ) ? 0 :gdjs.Area1_461Code.GDSlimeObjects6[0].getPointY("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects6 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects6[i].addForceTowardPosition((gdjs.Area1_461Code.GDPlayerObjects6[i].getPointX("Center")), (gdjs.Area1_461Code.GDPlayerObjects6[i].getPointY("Center")) + 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects5, gdjs.Area1_461Code.GDPlayerObjects6);

gdjs.copyArray(gdjs.Area1_461Code.GDSlimeObjects5, gdjs.Area1_461Code.GDSlimeObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_461Code.GDPlayerObjects6.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects6[0].getPointX("Center")) - (( gdjs.Area1_461Code.GDSlimeObjects6.length === 0 ) ? 0 :gdjs.Area1_461Code.GDSlimeObjects6[0].getPointX("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects6 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects6[i].addForceTowardPosition((gdjs.Area1_461Code.GDPlayerObjects6[i].getPointX("Center")) + 2000, (gdjs.Area1_461Code.GDPlayerObjects6[i].getPointY("Center")), 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects5, gdjs.Area1_461Code.GDPlayerObjects6);

gdjs.copyArray(gdjs.Area1_461Code.GDSlimeObjects5, gdjs.Area1_461Code.GDSlimeObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_461Code.GDPlayerObjects6.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects6[0].getPointX("Center")) - (( gdjs.Area1_461Code.GDSlimeObjects6.length === 0 ) ? 0 :gdjs.Area1_461Code.GDSlimeObjects6[0].getPointX("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects6 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects6[i].addForceTowardPosition((gdjs.Area1_461Code.GDPlayerObjects6[i].getPointX("Center")) - 2000, (gdjs.Area1_461Code.GDPlayerObjects6[i].getPointY("Center")), 1000, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Area1_461Code.GDPlayerObjects5 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects5[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(1, 5, 5, 0, 5, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects5Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects5});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects5Objects = Hashtable.newFrom({"Slime": gdjs.Area1_461Code.GDSlimeObjects5});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects4Objects = Hashtable.newFrom({"Slime": gdjs.Area1_461Code.GDSlimeObjects4});
gdjs.Area1_461Code.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects5);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects5Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects5 */
/* Reuse gdjs.Area1_461Code.GDSlimeObjects5 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects5[i].separateFromObjectsList(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects5Objects, false);
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects5);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects5Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPlayerObjects5.length;i<l;++i) {
    if ( !(gdjs.Area1_461Code.GDPlayerObjects5[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDPlayerObjects5[k] = gdjs.Area1_461Code.GDPlayerObjects5[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPlayerObjects5.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_461Code.GDHealthBarObjects5);
/* Reuse gdjs.Area1_461Code.GDPlayerObjects5 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects5[i].getBehavior("Health").Hit(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() - runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber(), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealthBarObjects5.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealthBarObjects5[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_461Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects5[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_461Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects5[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects4);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDPlayerObjects4[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDPlayerObjects4[k] = gdjs.Area1_461Code.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPlayerObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects4[i].getBehavior("Health").Hit(0, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects4Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_461Code.GDKing_9595SlimeObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects4Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_461Code.GDKing_9595SlimeObjects4});
gdjs.Area1_461Code.asyncCallback11925844 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects5[i].getBehavior("ShakeObject_PositionAngleScale").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Area1_461Code.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_461Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback11925844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects4, gdjs.Area1_461Code.GDPlayerObjects5);

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_461Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects5[0].getPointY("Center")) - (( gdjs.Area1_461Code.GDSlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_461Code.GDSlimeObjects5[0].getPointY("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects5 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects5[i].addForceTowardPosition((gdjs.Area1_461Code.GDPlayerObjects5[i].getPointX("Center")), (gdjs.Area1_461Code.GDPlayerObjects5[i].getPointY("Center")) - 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects4, gdjs.Area1_461Code.GDPlayerObjects5);

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_461Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects5[0].getPointY("Center")) - (( gdjs.Area1_461Code.GDSlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_461Code.GDSlimeObjects5[0].getPointY("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects5 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects5[i].addForceTowardPosition((gdjs.Area1_461Code.GDPlayerObjects5[i].getPointX("Center")), (gdjs.Area1_461Code.GDPlayerObjects5[i].getPointY("Center")) + 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects4, gdjs.Area1_461Code.GDPlayerObjects5);

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_461Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects5[0].getPointX("Center")) - (( gdjs.Area1_461Code.GDSlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_461Code.GDSlimeObjects5[0].getPointX("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects5 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects5[i].addForceTowardPosition((gdjs.Area1_461Code.GDPlayerObjects5[i].getPointX("Center")) + 2000, (gdjs.Area1_461Code.GDPlayerObjects5[i].getPointY("Center")), 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects4, gdjs.Area1_461Code.GDPlayerObjects5);

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_461Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects5[0].getPointX("Center")) - (( gdjs.Area1_461Code.GDSlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_461Code.GDSlimeObjects5[0].getPointX("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects5 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects5[i].addForceTowardPosition((gdjs.Area1_461Code.GDPlayerObjects5[i].getPointX("Center")) - 2000, (gdjs.Area1_461Code.GDPlayerObjects5[i].getPointY("Center")), 1000, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Area1_461Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(1, 5, 5, 0, 5, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects4Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_461Code.GDKing_9595SlimeObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects3Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_461Code.GDKing_9595SlimeObjects3});
gdjs.Area1_461Code.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDKing_9595SlimeObjects4 */
/* Reuse gdjs.Area1_461Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects4[i].separateFromObjectsList(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects4Objects, false);
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPlayerObjects4.length;i<l;++i) {
    if ( !(gdjs.Area1_461Code.GDPlayerObjects4[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDPlayerObjects4[k] = gdjs.Area1_461Code.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPlayerObjects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_461Code.GDHealthBarObjects4);
/* Reuse gdjs.Area1_461Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects4[i].getBehavior("Health").Hit(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber() - runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber(), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealthBarObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealthBarObjects4[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_461Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects4[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_461Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects4[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDPlayerObjects3[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDPlayerObjects3[k] = gdjs.Area1_461Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPlayerObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects3[i].getBehavior("Health").Hit(0, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_461Code.eventsList31 = function(runtimeScene) {

{


gdjs.Area1_461Code.eventsList27(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList30(runtimeScene);
}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDDoorObjects4Objects = Hashtable.newFrom({"Door": gdjs.Area1_461Code.GDDoorObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDDoorObjects4Objects = Hashtable.newFrom({"Door": gdjs.Area1_461Code.GDDoorObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDDoorObjects3Objects = Hashtable.newFrom({"Door": gdjs.Area1_461Code.GDDoorObjects3});
gdjs.Area1_461Code.eventsList32 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DoorMask"), gdjs.Area1_461Code.GDDoorMaskObjects4);
{for(var i = 0, len = gdjs.Area1_461Code.GDDoorMaskObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDDoorMaskObjects4[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.Area1_461Code.GDDoorObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDDoorObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDDoorObjects4 */
/* Reuse gdjs.Area1_461Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects4[i].separateFromObjectsList(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDDoorObjects4Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.Area1_461Code.GDDoorObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDDoorObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11932612);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDDoorObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDDoorObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDDoorObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(14).sub(1);
}}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterDoorObjects4Objects = Hashtable.newFrom({"MasterDoor": gdjs.Area1_461Code.GDMasterDoorObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterDoorObjects4Objects = Hashtable.newFrom({"MasterDoor": gdjs.Area1_461Code.GDMasterDoorObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDDoorMaskObjects3Objects = Hashtable.newFrom({"DoorMask": gdjs.Area1_461Code.GDDoorMaskObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterDoorObjects3Objects = Hashtable.newFrom({"MasterDoor": gdjs.Area1_461Code.GDMasterDoorObjects3});
gdjs.Area1_461Code.eventsList33 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DoorMask"), gdjs.Area1_461Code.GDDoorMaskObjects4);
{for(var i = 0, len = gdjs.Area1_461Code.GDDoorMaskObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDDoorMaskObjects4[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MasterDoor"), gdjs.Area1_461Code.GDMasterDoorObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterDoorObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDMasterDoorObjects4 */
/* Reuse gdjs.Area1_461Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects4[i].separateFromObjectsList(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterDoorObjects4Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DoorMask"), gdjs.Area1_461Code.GDDoorMaskObjects3);
gdjs.copyArray(runtimeScene.getObjects("MasterDoor"), gdjs.Area1_461Code.GDMasterDoorObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDDoorMaskObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterDoorObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(15)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11935948);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDMasterDoorObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDMasterDoorObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDMasterDoorObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(15).sub(1);
}}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDChestsObjects4Objects = Hashtable.newFrom({"Chests": gdjs.Area1_461Code.GDChestsObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDChestsObjects4Objects = Hashtable.newFrom({"Chests": gdjs.Area1_461Code.GDChestsObjects4});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDCollisionMaskObjects3Objects = Hashtable.newFrom({"CollisionMask": gdjs.Area1_461Code.GDCollisionMaskObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDChestsObjects3Objects = Hashtable.newFrom({"Chests": gdjs.Area1_461Code.GDChestsObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDGet_95959595textObjects3Objects = Hashtable.newFrom({"Get_text": gdjs.Area1_461Code.GDGet_9595textObjects3});
gdjs.Area1_461Code.asyncCallback11941692 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Get_text"), gdjs.Area1_461Code.GDGet_9595textObjects4);

{for(var i = 0, len = gdjs.Area1_461Code.GDGet_9595textObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDGet_9595textObjects4[i].deleteFromScene(runtimeScene);
}
}}
gdjs.Area1_461Code.eventsList34 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_461Code.GDGet_9595textObjects3) asyncObjectsList.addObject("Get_text", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback11941692(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.eventsList35 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CollisionMask"), gdjs.Area1_461Code.GDCollisionMaskObjects4);
{for(var i = 0, len = gdjs.Area1_461Code.GDCollisionMaskObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDCollisionMaskObjects4[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Chests"), gdjs.Area1_461Code.GDChestsObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects4Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDChestsObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDChestsObjects4 */
/* Reuse gdjs.Area1_461Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects4[i].separateFromObjectsList(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDChestsObjects4Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Chests"), gdjs.Area1_461Code.GDChestsObjects3);
gdjs.copyArray(runtimeScene.getObjects("CollisionMask"), gdjs.Area1_461Code.GDCollisionMaskObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDCollisionMaskObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDChestsObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDChestsObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDChestsObjects3[i].getBehavior("Animation").getAnimationName() == "Chest" ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDChestsObjects3[k] = gdjs.Area1_461Code.GDChestsObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDChestsObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11939612);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDChestsObjects3 */
gdjs.Area1_461Code.GDGet_9595textObjects3.length = 0;

{for(var i = 0, len = gdjs.Area1_461Code.GDChestsObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDChestsObjects3[i].getBehavior("Animation").setAnimationName("Chest_open");
}
}{runtimeScene.getGame().getVariables().getFromIndex(14).add(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDGet_95959595textObjects3Objects, (( gdjs.Area1_461Code.GDChestsObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDChestsObjects3[0].getPointX("get_text")), (( gdjs.Area1_461Code.GDChestsObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDChestsObjects3[0].getPointY("get_text")), "");
}{for(var i = 0, len = gdjs.Area1_461Code.GDGet_9595textObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDGet_9595textObjects3[i].setBBText("1x Door Key");
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterChestObjects3Objects = Hashtable.newFrom({"MasterChest": gdjs.Area1_461Code.GDMasterChestObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterChestObjects3Objects = Hashtable.newFrom({"MasterChest": gdjs.Area1_461Code.GDMasterChestObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDCollisionMaskObjects2Objects = Hashtable.newFrom({"CollisionMask": gdjs.Area1_461Code.GDCollisionMaskObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterChestObjects2Objects = Hashtable.newFrom({"MasterChest": gdjs.Area1_461Code.GDMasterChestObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDGet_95959595textObjects2Objects = Hashtable.newFrom({"Get_text": gdjs.Area1_461Code.GDGet_9595textObjects2});
gdjs.Area1_461Code.asyncCallback11946844 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Get_text"), gdjs.Area1_461Code.GDGet_9595textObjects3);

{for(var i = 0, len = gdjs.Area1_461Code.GDGet_9595textObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDGet_9595textObjects3[i].deleteFromScene(runtimeScene);
}
}}
gdjs.Area1_461Code.eventsList36 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_461Code.GDGet_9595textObjects2) asyncObjectsList.addObject("Get_text", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback11946844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.eventsList37 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CollisionMask"), gdjs.Area1_461Code.GDCollisionMaskObjects3);
{for(var i = 0, len = gdjs.Area1_461Code.GDCollisionMaskObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDCollisionMaskObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MasterChest"), gdjs.Area1_461Code.GDMasterChestObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterChestObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDMasterChestObjects3 */
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects3[i].separateFromObjectsList(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterChestObjects3Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CollisionMask"), gdjs.Area1_461Code.GDCollisionMaskObjects2);
gdjs.copyArray(runtimeScene.getObjects("MasterChest"), gdjs.Area1_461Code.GDMasterChestObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects2Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDCollisionMaskObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects2Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDMasterChestObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDMasterChestObjects2.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDMasterChestObjects2[i].getBehavior("Animation").getAnimationName() == "Master" ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDMasterChestObjects2[k] = gdjs.Area1_461Code.GDMasterChestObjects2[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDMasterChestObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11944772);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDMasterChestObjects2 */
gdjs.Area1_461Code.GDGet_9595textObjects2.length = 0;

{for(var i = 0, len = gdjs.Area1_461Code.GDMasterChestObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDMasterChestObjects2[i].getBehavior("Animation").setAnimationName("Master_open");
}
}{runtimeScene.getGame().getVariables().getFromIndex(15).add(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDGet_95959595textObjects2Objects, (( gdjs.Area1_461Code.GDMasterChestObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDMasterChestObjects2[0].getPointX("get_text")), (( gdjs.Area1_461Code.GDMasterChestObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDMasterChestObjects2[0].getPointY("get_text")), "");
}{for(var i = 0, len = gdjs.Area1_461Code.GDGet_9595textObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDGet_9595textObjects2[i].setBBText("1x Master Key");
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.eventsList38 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Area1_461Code.GDBarrierObjects3);
gdjs.copyArray(runtimeScene.getObjects("barrierhorizontal"), gdjs.Area1_461Code.GDbarrierhorizontalObjects3);
gdjs.copyArray(runtimeScene.getObjects("barriervertical"), gdjs.Area1_461Code.GDbarrierverticalObjects3);
{for(var i = 0, len = gdjs.Area1_461Code.GDbarrierverticalObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDbarrierverticalObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDbarrierhorizontalObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDbarrierhorizontalObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDBarrierObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDBarrierObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_461Code.GDWall_9595HorizontalObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
/* Reuse gdjs.Area1_461Code.GDWall_9595HorizontalObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects3[i].separateFromObjectsList(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects3Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(12)) == 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Area1_461Code.eventsList24(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Area1_461Code.GDBarrierObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDBarrierObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDBarrierObjects3 */
gdjs.copyArray(runtimeScene.getObjects("barrierhorizontal"), gdjs.Area1_461Code.GDbarrierhorizontalObjects3);
gdjs.copyArray(runtimeScene.getObjects("barriervertical"), gdjs.Area1_461Code.GDbarrierverticalObjects3);
gdjs.Area1_461Code.GDBoss_9595HealthObjects3.length = 0;

gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3.length = 0;

{for(var i = 0, len = gdjs.Area1_461Code.GDBarrierObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDBarrierObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDBoss_95959595HealthObjects3Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDHealth_95959595boss_95959595emptyObjects3Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.Area1_461Code.GDBoss_9595HealthObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDBoss_9595HealthObjects3[i].getBehavior("Resizable").setSize(600, 25);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3[i].getBehavior("Resizable").setSize(600, 25);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDBoss_9595HealthObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDBoss_9595HealthObjects3[i].setZOrder(10);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3[i].setZOrder(9);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDbarrierverticalObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDbarrierverticalObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDbarrierhorizontalObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDbarrierhorizontalObjects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(12).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion"), gdjs.Area1_461Code.GDPotionObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPotionObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPotionObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_461Code.GDPotion_9595numberObjects3);
{for(var i = 0, len = gdjs.Area1_461Code.GDPotionObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPotionObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(16).add(1);
}{for(var i = 0, len = gdjs.Area1_461Code.GDPotion_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPotion_9595numberObjects3[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16))) + "x");
}
}}

}


{


gdjs.Area1_461Code.eventsList31(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList32(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList33(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList35(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList37(runtimeScene);
}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlashObjects3Objects = Hashtable.newFrom({"Slash": gdjs.Area1_461Code.GDSlashObjects3});
gdjs.Area1_461Code.asyncCallback11948812 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Slash"), gdjs.Area1_461Code.GDSlashObjects4);

{for(var i = 0, len = gdjs.Area1_461Code.GDSlashObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlashObjects4[i].deleteFromScene(runtimeScene);
}
}}
gdjs.Area1_461Code.eventsList39 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_461Code.GDSlashObjects3) asyncObjectsList.addObject("Slash", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback11948812(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.eventsList40 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);
gdjs.Area1_461Code.GDSlashObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlashObjects3Objects, (( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("slash")), (( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointY("slash")), "");
}{for(var i = 0, len = gdjs.Area1_461Code.GDSlashObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlashObjects3[i].getBehavior("Animation").setAnimationName("Slash");
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList39(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseInsideCanvas(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_461Code.GDSlashObjects2);
{for(var i = 0, len = gdjs.Area1_461Code.GDSlashObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlashObjects2[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


};gdjs.Area1_461Code.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Boss_Health"), gdjs.Area1_461Code.GDBoss_9595HealthObjects3);
gdjs.copyArray(runtimeScene.getObjects("HP"), gdjs.Area1_461Code.GDHPObjects3);
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_461Code.GDHealthBarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Health_boss_empty"), gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Healthempty"), gdjs.Area1_461Code.GDHealthemptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_461Code.GDKillcountObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_number"), gdjs.Area1_461Code.GDLevel_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Area1_461Code.GDMenuObjects3);
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_461Code.GDPotion_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_461Code.GDPotion_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Screen"), gdjs.Area1_461Code.GDScreenObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_461Code.GDSlashObjects3);
gdjs.copyArray(runtimeScene.getObjects("Status_box"), gdjs.Area1_461Code.GDStatus_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_461Code.GDTImerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Area1_461Code.GDTargetObjects3);
gdjs.copyArray(runtimeScene.getObjects("playername"), gdjs.Area1_461Code.GDplayernameObjects3);
{for(var i = 0, len = gdjs.Area1_461Code.GDScreenObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDScreenObjects3[i].setPosition((( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("screen")),(( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointY("screen")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDMenuObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("Menu")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("Menu")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDStatus_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDStatus_9595boxObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("box_status")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("box_status")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHPObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHPObjects3[i].setPosition((( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointX("HP_name")),(( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointY("HP_name")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealthBarObjects3[i].setPosition((( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealthemptyObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealthemptyObjects3[i].setPosition((( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDBoss_9595HealthObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDBoss_9595HealthObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("bosshp")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("bosshp")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("bosshp")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("bosshp")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDLevel_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDLevel_9595numberObjects3[i].setPosition((( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointX("LVL_name")),(( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointY("LVL_name")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDplayernameObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDplayernameObjects3[i].setPosition((( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointX("player_name")),(( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointY("player_name")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDSlashObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlashObjects3[i].setPosition((( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("slash")),(( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointY("slash")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDTImerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDTImerObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("time")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("time")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDPotion_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPotion_9595boxObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("potion")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("potion")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDKillcountObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKillcountObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("kcount")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("kcount")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDPotion_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPotion_9595numberObjects3[i].setPosition((( gdjs.Area1_461Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPotion_9595boxObjects3[0].getPointX("number")),(( gdjs.Area1_461Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPotion_9595boxObjects3[0].getPointY("number")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDTargetObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDTargetObjects3[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("screen")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointY("screen")), "", 0);
}}

}


};gdjs.Area1_461Code.eventsList42 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Boss_Health"), gdjs.Area1_461Code.GDBoss_9595HealthObjects3);
gdjs.copyArray(runtimeScene.getObjects("HP"), gdjs.Area1_461Code.GDHPObjects3);
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_461Code.GDHealthBarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Health_boss_empty"), gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Healthempty"), gdjs.Area1_461Code.GDHealthemptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_461Code.GDKillcountObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_number"), gdjs.Area1_461Code.GDLevel_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Area1_461Code.GDMenuObjects3);
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_461Code.GDPotion_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_461Code.GDPotion_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Screen"), gdjs.Area1_461Code.GDScreenObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_461Code.GDSlashObjects3);
gdjs.copyArray(runtimeScene.getObjects("Status_box"), gdjs.Area1_461Code.GDStatus_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_461Code.GDTImerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Area1_461Code.GDTargetObjects3);
gdjs.copyArray(runtimeScene.getObjects("playername"), gdjs.Area1_461Code.GDplayernameObjects3);
{for(var i = 0, len = gdjs.Area1_461Code.GDScreenObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDScreenObjects3[i].setPosition((( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("screen")),(( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointY("screen")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDMenuObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("Menu")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("Menu")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDStatus_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDStatus_9595boxObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("box_status")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("box_status")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHPObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHPObjects3[i].setPosition((( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointX("HP_name")),(( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointY("HP_name")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealthBarObjects3[i].setPosition((( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealthemptyObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealthemptyObjects3[i].setPosition((( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDBoss_9595HealthObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDBoss_9595HealthObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("bosshp")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("bosshp")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("bosshp")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("bosshp")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDLevel_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDLevel_9595numberObjects3[i].setPosition((( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointX("LVL_name")),(( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointY("LVL_name")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDplayernameObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDplayernameObjects3[i].setPosition((( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointX("player_name")),(( gdjs.Area1_461Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDStatus_9595boxObjects3[0].getPointY("player_name")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDSlashObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlashObjects3[i].setPosition((( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("slash")),(( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointY("slash")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDTImerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDTImerObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("time")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("time")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDPotion_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPotion_9595boxObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("potion")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("potion")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDKillcountObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKillcountObjects3[i].setPosition((( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointX("kcount")),(( gdjs.Area1_461Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDScreenObjects3[0].getPointY("kcount")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDPotion_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPotion_9595numberObjects3[i].setPosition((( gdjs.Area1_461Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPotion_9595boxObjects3[0].getPointX("number")),(( gdjs.Area1_461Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPotion_9595boxObjects3[0].getPointY("number")));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDTargetObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDTargetObjects3[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("screen")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointY("screen")), "", 0);
}}

}


};gdjs.Area1_461Code.eventsList43 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDPlayerObjects3[k] = gdjs.Area1_461Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Shadow"), gdjs.Area1_461Code.GDShadowObjects3);
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects3[i].getBehavior("Animation").setAnimationName("walk");
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDShadowObjects3[i].getBehavior("Animation").setAnimationName("walk");
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDShadowObjects3[i].setPosition((( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("shadow")),(( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointY("shadow")));
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList41(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Area1_461Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDPlayerObjects3[k] = gdjs.Area1_461Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Shadow"), gdjs.Area1_461Code.GDShadowObjects3);
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects3[i].getBehavior("Animation").setAnimationName("idle");
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDShadowObjects3[i].getBehavior("Animation").setAnimationName("idle");
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDShadowObjects3[i].setPosition((( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("shadow")),(( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointY("shadow")));
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList42(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDPlayerObjects3[k] = gdjs.Area1_461Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects3[i].addForce(100, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDPlayerObjects3[k] = gdjs.Area1_461Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects3[i].addForce(-(100), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Up") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDPlayerObjects3[k] = gdjs.Area1_461Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects3[i].addForce(0, -(100), 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Down") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDPlayerObjects3[k] = gdjs.Area1_461Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects3[i].addForce(0, 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) < (( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("center"));
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects3[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) > (( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getPointX("center"));
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.Area1_461Code.eventsList44 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects8);
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects8.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects8[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_461Code.asyncCallback8718773 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)));
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)));
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)));
}
{ //Subevents
gdjs.Area1_461Code.eventsList44(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList45 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8718773(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8718405 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList45(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList46 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8718405(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8710229 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList46(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList47 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8710229(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8709861 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList47(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList48 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8709861(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8709189 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList48(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList49 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8709189(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.eventsList50 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects8);
{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects8.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects8[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects8.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects8[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_461Code.asyncCallback8725765 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList50(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList51 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(16), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8725765(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8724877 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList51(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList52 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(15), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8724877(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8723901 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList52(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList53 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(17), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8723901(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8722941 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList53(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList54 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(14), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8722941(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8722005 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList54(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList55 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(13), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8722005(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.eventsList56 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects7);
{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects7.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects7[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDPlayerObjects7.length ;i < len;++i) {
    gdjs.Area1_461Code.GDPlayerObjects7[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_461Code.asyncCallback8732157 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)));
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9)));
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)));
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(8)));
}
{ //Subevents
gdjs.Area1_461Code.eventsList56(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList57 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/maxexp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(9), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8732157(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8731221 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList57(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList58 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/hp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(5), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8731221(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8730093 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList58(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList59 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/spd/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(8), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8730093(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8729029 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList59(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList60 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/def/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(7), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8729029(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.asyncCallback8727965 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_461Code.eventsList60(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_461Code.eventsList61 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/atk/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(6), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_461Code.asyncCallback8727965(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_461Code.eventsList62 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_461Code.eventsList49(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_461Code.eventsList55(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_461Code.eventsList61(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.eventsList63 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber() > 0);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Level_number"), gdjs.Area1_461Code.GDLevel_9595numberObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Area1_461Code.GDLevel_9595numberObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDLevel_9595numberObjects2[i].setBBText("LV. " + runtimeScene.getGame().getVariables().getFromIndex(3).getAsString());
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(0);
}
{ //Subevents
gdjs.Area1_461Code.eventsList62(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.eventsList64 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Area1.1", false);
}}

}


};gdjs.Area1_461Code.eventsList65 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDPlayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDPlayerObjects1[k] = gdjs.Area1_461Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(runtimeScene.getGame().getVariables().getFromIndex(20).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(runtimeScene.getGame().getVariables().getFromIndex(21).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(16).setNumber(runtimeScene.getGame().getVariables().getFromIndex(22).getAsNumber());
}
{ //Subevents
gdjs.Area1_461Code.eventsList64(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.eventsList66 = function(runtimeScene) {

{


gdjs.Area1_461Code.eventsList38(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList40(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList43(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList63(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList65(runtimeScene);
}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects3Objects = Hashtable.newFrom({"Slime": gdjs.Area1_461Code.GDSlimeObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_461Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_461Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects3Objects = Hashtable.newFrom({"Slime": gdjs.Area1_461Code.GDSlimeObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.eventsList67 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects3, gdjs.Area1_461Code.GDPlayerObjects4);

gdjs.copyArray(gdjs.Area1_461Code.GDSlimeObjects3, gdjs.Area1_461Code.GDSlimeObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDSlimeObjects4.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDSlimeObjects4[i].getX() < (( gdjs.Area1_461Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects4[0].getPointX("Center")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDSlimeObjects4[k] = gdjs.Area1_461Code.GDSlimeObjects4[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDSlimeObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDSlimeObjects4 */
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects4.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects4[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
/* Reuse gdjs.Area1_461Code.GDSlimeObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDSlimeObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDSlimeObjects3[i].getX() > (( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("Center")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDSlimeObjects3[k] = gdjs.Area1_461Code.GDSlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDSlimeObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDSlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects3[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlashObjects3Objects = Hashtable.newFrom({"Slash": gdjs.Area1_461Code.GDSlashObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects3Objects = Hashtable.newFrom({"Slime": gdjs.Area1_461Code.GDSlimeObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlashObjects3Objects = Hashtable.newFrom({"Slash": gdjs.Area1_461Code.GDSlashObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects3Objects = Hashtable.newFrom({"Slime": gdjs.Area1_461Code.GDSlimeObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects3Objects = Hashtable.newFrom({"Slime": gdjs.Area1_461Code.GDSlimeObjects3});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects3});
gdjs.Area1_461Code.eventsList68 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_461Code.GDWall_9595HorizontalObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDSlimeObjects3 */
/* Reuse gdjs.Area1_461Code.GDWall_9595HorizontalObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects3[i].separateFromObjectsList(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects3Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, 300, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDPlayerObjects3 */
/* Reuse gdjs.Area1_461Code.GDSlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects3[i].getBehavior("Animation").setAnimationName("walk");
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects3[i].addForceTowardObject((gdjs.Area1_461Code.GDPlayerObjects3.length !== 0 ? gdjs.Area1_461Code.GDPlayerObjects3[0] : null), runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), 0);
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList67(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_461Code.GDSlashObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlashObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDSlimeObjects3.length;i<l;++i) {
    if ( !(gdjs.Area1_461Code.GDSlimeObjects3[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDSlimeObjects3[k] = gdjs.Area1_461Code.GDSlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDSlimeObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDSlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects3[i].getBehavior("Animation").setAnimationName("hurt");
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects3[i].getBehavior("Health").Hit(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber(), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_461Code.GDSlashObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlashObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDSlimeObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDSlimeObjects3[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDSlimeObjects3[k] = gdjs.Area1_461Code.GDSlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDSlimeObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDSlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects3[i].getBehavior("Health").Hit(0, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDSlimeObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDSlimeObjects3[i].getBehavior("Animation").getAnimationName() == "Hurt" ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDSlimeObjects3[k] = gdjs.Area1_461Code.GDSlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDSlimeObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDSlimeObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDSlimeObjects3[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDSlimeObjects3[k] = gdjs.Area1_461Code.GDSlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDSlimeObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDSlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects3[i].getBehavior("Animation").setAnimationName("walk");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlimeObjects3Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects3Objects, 300, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDSlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects3[i].getBehavior("Animation").setAnimationName("idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_461Code.GDSlimeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDSlimeObjects2.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDSlimeObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDSlimeObjects2[k] = gdjs.Area1_461Code.GDSlimeObjects2[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDSlimeObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Exp_point"), gdjs.Area1_461Code.GDExp_9595pointObjects2);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_461Code.GDKillcountObjects2);
/* Reuse gdjs.Area1_461Code.GDSlimeObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDSlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDSlimeObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).add(runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber());
}{for(var i = 0, len = gdjs.Area1_461Code.GDExp_9595pointObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDExp_9595pointObjects2[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(8).getAsString());
}
}{runtimeScene.getGame().getVariables().getFromIndex(23).add(1);
}{for(var i = 0, len = gdjs.Area1_461Code.GDKillcountObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKillcountObjects2[i].setBBText("Kill : " + runtimeScene.getGame().getVariables().getFromIndex(23).getAsString());
}
}}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects2Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_461Code.GDKing_9595SlimeObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects2Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_461Code.GDWall_9595HorizontalObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects2Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_461Code.GDWall_9595HorizontalObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects2Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_461Code.GDKing_9595SlimeObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects2});
gdjs.Area1_461Code.eventsList69 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Area1_461Code.GDKing_9595SlimeObjects2, gdjs.Area1_461Code.GDKing_9595SlimeObjects3);

gdjs.copyArray(gdjs.Area1_461Code.GDPlayerObjects2, gdjs.Area1_461Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDKing_9595SlimeObjects3.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDKing_9595SlimeObjects3[i].getX() < (( gdjs.Area1_461Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects3[0].getPointX("Center")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDKing_9595SlimeObjects3[k] = gdjs.Area1_461Code.GDKing_9595SlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDKing_9595SlimeObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDKing_9595SlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects3[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

/* Reuse gdjs.Area1_461Code.GDKing_9595SlimeObjects2 */
/* Reuse gdjs.Area1_461Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getX() > (( gdjs.Area1_461Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDPlayerObjects2[0].getPointX("Center")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDKing_9595SlimeObjects2[k] = gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDKing_9595SlimeObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlashObjects2Objects = Hashtable.newFrom({"Slash": gdjs.Area1_461Code.GDSlashObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects2Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_461Code.GDKing_9595SlimeObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlashObjects2Objects = Hashtable.newFrom({"Slash": gdjs.Area1_461Code.GDSlashObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects2Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_461Code.GDKing_9595SlimeObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects2Objects = Hashtable.newFrom({"King_Slime": gdjs.Area1_461Code.GDKing_9595SlimeObjects2});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects2});
gdjs.Area1_461Code.eventsList70 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_461Code.GDWall_9595HorizontalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects2Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDKing_9595SlimeObjects2 */
/* Reuse gdjs.Area1_461Code.GDWall_9595HorizontalObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].separateFromObjectsList(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDWall_95959595HorizontalObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects2Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects2Objects, 1000, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDKing_9595SlimeObjects2 */
/* Reuse gdjs.Area1_461Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getBehavior("Animation").setAnimationName("Walk");
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].addForceTowardObject((gdjs.Area1_461Code.GDPlayerObjects2.length !== 0 ? gdjs.Area1_461Code.GDPlayerObjects2[0] : null), runtimeScene.getScene().getVariables().getFromIndex(16).getAsNumber(), 0);
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList69(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_461Code.GDSlashObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlashObjects2Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length;i<l;++i) {
    if ( !(gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDKing_9595SlimeObjects2[k] = gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Boss_Health"), gdjs.Area1_461Code.GDBoss_9595HealthObjects2);
/* Reuse gdjs.Area1_461Code.GDKing_9595SlimeObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getBehavior("Animation").setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getBehavior("Health").Hit(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() - runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber(), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDBoss_9595HealthObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDBoss_9595HealthObjects2[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDKing_9595SlimeObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length === 0 ) ? 0 :gdjs.Area1_461Code.GDKing_9595SlimeObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 600);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_461Code.GDSlashObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDSlashObjects2Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDKing_9595SlimeObjects2[k] = gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDKing_9595SlimeObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getBehavior("Health").Hit(0, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getBehavior("Animation").getAnimationName() == "Hurt" ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDKing_9595SlimeObjects2[k] = gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDKing_9595SlimeObjects2[k] = gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDKing_9595SlimeObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getBehavior("Animation").setAnimationName("Walk");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDKing_95959595SlimeObjects2Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects2Objects, 1000, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDKing_9595SlimeObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("King_Slime"), gdjs.Area1_461Code.GDKing_9595SlimeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_461Code.GDKing_9595SlimeObjects1.length;i<l;++i) {
    if ( gdjs.Area1_461Code.GDKing_9595SlimeObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_461Code.GDKing_9595SlimeObjects1[k] = gdjs.Area1_461Code.GDKing_9595SlimeObjects1[i];
        ++k;
    }
}
gdjs.Area1_461Code.GDKing_9595SlimeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Boss_Health"), gdjs.Area1_461Code.GDBoss_9595HealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Health_boss_empty"), gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_461Code.GDKillcountObjects1);
/* Reuse gdjs.Area1_461Code.GDKing_9595SlimeObjects1 */
gdjs.copyArray(runtimeScene.getObjects("barrierhorizontal"), gdjs.Area1_461Code.GDbarrierhorizontalObjects1);
gdjs.copyArray(runtimeScene.getObjects("barriervertical"), gdjs.Area1_461Code.GDbarrierverticalObjects1);
{for(var i = 0, len = gdjs.Area1_461Code.GDKing_9595SlimeObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKing_9595SlimeObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDBoss_9595HealthObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDBoss_9595HealthObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDbarrierverticalObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDbarrierverticalObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_461Code.GDbarrierhorizontalObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDbarrierhorizontalObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).add(runtimeScene.getScene().getVariables().getFromIndex(16).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(23).add(1);
}{for(var i = 0, len = gdjs.Area1_461Code.GDKillcountObjects1.length ;i < len;++i) {
    gdjs.Area1_461Code.GDKillcountObjects1[i].setBBText("Kill : " + runtimeScene.getGame().getVariables().getFromIndex(23).getAsString());
}
}}

}


};gdjs.Area1_461Code.eventsList71 = function(runtimeScene) {

{



}


{


gdjs.Area1_461Code.eventsList68(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList70(runtimeScene);
}


};gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Area1_461Code.GDPlayerObjects1});
gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDstaircaseObjects1Objects = Hashtable.newFrom({"staircase": gdjs.Area1_461Code.GDstaircaseObjects1});
gdjs.Area1_461Code.eventsList72 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_461Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("staircase"), gdjs.Area1_461Code.GDstaircaseObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDPlayerObjects1Objects, gdjs.Area1_461Code.mapOfGDgdjs_9546Area1_9595461Code_9546GDstaircaseObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(2);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Area1.2", false);
}}

}


};gdjs.Area1_461Code.eventsList73 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) >= 10;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDTImerObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDTImerObjects2[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}}

}


};gdjs.Area1_461Code.eventsList74 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) >= 10;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDTImerObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList73(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.eventsList75 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) >= 10;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_461Code.GDTImerObjects2 */
{for(var i = 0, len = gdjs.Area1_461Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList74(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_461Code.eventsList76 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_461Code.GDTImerObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timer");
}{for(var i = 0, len = gdjs.Area1_461Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "timer") >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_461Code.GDTImerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(17).add(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timer");
}{for(var i = 0, len = gdjs.Area1_461Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_461Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}
{ //Subevents
gdjs.Area1_461Code.eventsList75(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) == 60;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(17).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(18).add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 60;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(19).add(1);
}}

}


};gdjs.Area1_461Code.eventsList77 = function(runtimeScene) {

{


gdjs.Area1_461Code.eventsList20(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList22(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList23(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList66(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList71(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList72(runtimeScene);
}


{


gdjs.Area1_461Code.eventsList76(runtimeScene);
}


};

gdjs.Area1_461Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Area1_461Code.GDGet_9595textObjects1.length = 0;
gdjs.Area1_461Code.GDGet_9595textObjects2.length = 0;
gdjs.Area1_461Code.GDGet_9595textObjects3.length = 0;
gdjs.Area1_461Code.GDGet_9595textObjects4.length = 0;
gdjs.Area1_461Code.GDGet_9595textObjects5.length = 0;
gdjs.Area1_461Code.GDGet_9595textObjects6.length = 0;
gdjs.Area1_461Code.GDGet_9595textObjects7.length = 0;
gdjs.Area1_461Code.GDGet_9595textObjects8.length = 0;
gdjs.Area1_461Code.GDGet_9595textObjects9.length = 0;
gdjs.Area1_461Code.GDFloorObjects1.length = 0;
gdjs.Area1_461Code.GDFloorObjects2.length = 0;
gdjs.Area1_461Code.GDFloorObjects3.length = 0;
gdjs.Area1_461Code.GDFloorObjects4.length = 0;
gdjs.Area1_461Code.GDFloorObjects5.length = 0;
gdjs.Area1_461Code.GDFloorObjects6.length = 0;
gdjs.Area1_461Code.GDFloorObjects7.length = 0;
gdjs.Area1_461Code.GDFloorObjects8.length = 0;
gdjs.Area1_461Code.GDFloorObjects9.length = 0;
gdjs.Area1_461Code.GDWall_9595HorizontalObjects1.length = 0;
gdjs.Area1_461Code.GDWall_9595HorizontalObjects2.length = 0;
gdjs.Area1_461Code.GDWall_9595HorizontalObjects3.length = 0;
gdjs.Area1_461Code.GDWall_9595HorizontalObjects4.length = 0;
gdjs.Area1_461Code.GDWall_9595HorizontalObjects5.length = 0;
gdjs.Area1_461Code.GDWall_9595HorizontalObjects6.length = 0;
gdjs.Area1_461Code.GDWall_9595HorizontalObjects7.length = 0;
gdjs.Area1_461Code.GDWall_9595HorizontalObjects8.length = 0;
gdjs.Area1_461Code.GDWall_9595HorizontalObjects9.length = 0;
gdjs.Area1_461Code.GDSlimeObjects1.length = 0;
gdjs.Area1_461Code.GDSlimeObjects2.length = 0;
gdjs.Area1_461Code.GDSlimeObjects3.length = 0;
gdjs.Area1_461Code.GDSlimeObjects4.length = 0;
gdjs.Area1_461Code.GDSlimeObjects5.length = 0;
gdjs.Area1_461Code.GDSlimeObjects6.length = 0;
gdjs.Area1_461Code.GDSlimeObjects7.length = 0;
gdjs.Area1_461Code.GDSlimeObjects8.length = 0;
gdjs.Area1_461Code.GDSlimeObjects9.length = 0;
gdjs.Area1_461Code.GDKing_9595SlimeObjects1.length = 0;
gdjs.Area1_461Code.GDKing_9595SlimeObjects2.length = 0;
gdjs.Area1_461Code.GDKing_9595SlimeObjects3.length = 0;
gdjs.Area1_461Code.GDKing_9595SlimeObjects4.length = 0;
gdjs.Area1_461Code.GDKing_9595SlimeObjects5.length = 0;
gdjs.Area1_461Code.GDKing_9595SlimeObjects6.length = 0;
gdjs.Area1_461Code.GDKing_9595SlimeObjects7.length = 0;
gdjs.Area1_461Code.GDKing_9595SlimeObjects8.length = 0;
gdjs.Area1_461Code.GDKing_9595SlimeObjects9.length = 0;
gdjs.Area1_461Code.GDExp_9595pointObjects1.length = 0;
gdjs.Area1_461Code.GDExp_9595pointObjects2.length = 0;
gdjs.Area1_461Code.GDExp_9595pointObjects3.length = 0;
gdjs.Area1_461Code.GDExp_9595pointObjects4.length = 0;
gdjs.Area1_461Code.GDExp_9595pointObjects5.length = 0;
gdjs.Area1_461Code.GDExp_9595pointObjects6.length = 0;
gdjs.Area1_461Code.GDExp_9595pointObjects7.length = 0;
gdjs.Area1_461Code.GDExp_9595pointObjects8.length = 0;
gdjs.Area1_461Code.GDExp_9595pointObjects9.length = 0;
gdjs.Area1_461Code.GDWall_9595verticalObjects1.length = 0;
gdjs.Area1_461Code.GDWall_9595verticalObjects2.length = 0;
gdjs.Area1_461Code.GDWall_9595verticalObjects3.length = 0;
gdjs.Area1_461Code.GDWall_9595verticalObjects4.length = 0;
gdjs.Area1_461Code.GDWall_9595verticalObjects5.length = 0;
gdjs.Area1_461Code.GDWall_9595verticalObjects6.length = 0;
gdjs.Area1_461Code.GDWall_9595verticalObjects7.length = 0;
gdjs.Area1_461Code.GDWall_9595verticalObjects8.length = 0;
gdjs.Area1_461Code.GDWall_9595verticalObjects9.length = 0;
gdjs.Area1_461Code.GDCollisionMaskObjects1.length = 0;
gdjs.Area1_461Code.GDCollisionMaskObjects2.length = 0;
gdjs.Area1_461Code.GDCollisionMaskObjects3.length = 0;
gdjs.Area1_461Code.GDCollisionMaskObjects4.length = 0;
gdjs.Area1_461Code.GDCollisionMaskObjects5.length = 0;
gdjs.Area1_461Code.GDCollisionMaskObjects6.length = 0;
gdjs.Area1_461Code.GDCollisionMaskObjects7.length = 0;
gdjs.Area1_461Code.GDCollisionMaskObjects8.length = 0;
gdjs.Area1_461Code.GDCollisionMaskObjects9.length = 0;
gdjs.Area1_461Code.GDChestsObjects1.length = 0;
gdjs.Area1_461Code.GDChestsObjects2.length = 0;
gdjs.Area1_461Code.GDChestsObjects3.length = 0;
gdjs.Area1_461Code.GDChestsObjects4.length = 0;
gdjs.Area1_461Code.GDChestsObjects5.length = 0;
gdjs.Area1_461Code.GDChestsObjects6.length = 0;
gdjs.Area1_461Code.GDChestsObjects7.length = 0;
gdjs.Area1_461Code.GDChestsObjects8.length = 0;
gdjs.Area1_461Code.GDChestsObjects9.length = 0;
gdjs.Area1_461Code.GDDoorObjects1.length = 0;
gdjs.Area1_461Code.GDDoorObjects2.length = 0;
gdjs.Area1_461Code.GDDoorObjects3.length = 0;
gdjs.Area1_461Code.GDDoorObjects4.length = 0;
gdjs.Area1_461Code.GDDoorObjects5.length = 0;
gdjs.Area1_461Code.GDDoorObjects6.length = 0;
gdjs.Area1_461Code.GDDoorObjects7.length = 0;
gdjs.Area1_461Code.GDDoorObjects8.length = 0;
gdjs.Area1_461Code.GDDoorObjects9.length = 0;
gdjs.Area1_461Code.GDDoorMaskObjects1.length = 0;
gdjs.Area1_461Code.GDDoorMaskObjects2.length = 0;
gdjs.Area1_461Code.GDDoorMaskObjects3.length = 0;
gdjs.Area1_461Code.GDDoorMaskObjects4.length = 0;
gdjs.Area1_461Code.GDDoorMaskObjects5.length = 0;
gdjs.Area1_461Code.GDDoorMaskObjects6.length = 0;
gdjs.Area1_461Code.GDDoorMaskObjects7.length = 0;
gdjs.Area1_461Code.GDDoorMaskObjects8.length = 0;
gdjs.Area1_461Code.GDDoorMaskObjects9.length = 0;
gdjs.Area1_461Code.GDMasterChestObjects1.length = 0;
gdjs.Area1_461Code.GDMasterChestObjects2.length = 0;
gdjs.Area1_461Code.GDMasterChestObjects3.length = 0;
gdjs.Area1_461Code.GDMasterChestObjects4.length = 0;
gdjs.Area1_461Code.GDMasterChestObjects5.length = 0;
gdjs.Area1_461Code.GDMasterChestObjects6.length = 0;
gdjs.Area1_461Code.GDMasterChestObjects7.length = 0;
gdjs.Area1_461Code.GDMasterChestObjects8.length = 0;
gdjs.Area1_461Code.GDMasterChestObjects9.length = 0;
gdjs.Area1_461Code.GDMasterDoorObjects1.length = 0;
gdjs.Area1_461Code.GDMasterDoorObjects2.length = 0;
gdjs.Area1_461Code.GDMasterDoorObjects3.length = 0;
gdjs.Area1_461Code.GDMasterDoorObjects4.length = 0;
gdjs.Area1_461Code.GDMasterDoorObjects5.length = 0;
gdjs.Area1_461Code.GDMasterDoorObjects6.length = 0;
gdjs.Area1_461Code.GDMasterDoorObjects7.length = 0;
gdjs.Area1_461Code.GDMasterDoorObjects8.length = 0;
gdjs.Area1_461Code.GDMasterDoorObjects9.length = 0;
gdjs.Area1_461Code.GDBoss_9595HealthObjects1.length = 0;
gdjs.Area1_461Code.GDBoss_9595HealthObjects2.length = 0;
gdjs.Area1_461Code.GDBoss_9595HealthObjects3.length = 0;
gdjs.Area1_461Code.GDBoss_9595HealthObjects4.length = 0;
gdjs.Area1_461Code.GDBoss_9595HealthObjects5.length = 0;
gdjs.Area1_461Code.GDBoss_9595HealthObjects6.length = 0;
gdjs.Area1_461Code.GDBoss_9595HealthObjects7.length = 0;
gdjs.Area1_461Code.GDBoss_9595HealthObjects8.length = 0;
gdjs.Area1_461Code.GDBoss_9595HealthObjects9.length = 0;
gdjs.Area1_461Code.GDbarrierverticalObjects1.length = 0;
gdjs.Area1_461Code.GDbarrierverticalObjects2.length = 0;
gdjs.Area1_461Code.GDbarrierverticalObjects3.length = 0;
gdjs.Area1_461Code.GDbarrierverticalObjects4.length = 0;
gdjs.Area1_461Code.GDbarrierverticalObjects5.length = 0;
gdjs.Area1_461Code.GDbarrierverticalObjects6.length = 0;
gdjs.Area1_461Code.GDbarrierverticalObjects7.length = 0;
gdjs.Area1_461Code.GDbarrierverticalObjects8.length = 0;
gdjs.Area1_461Code.GDbarrierverticalObjects9.length = 0;
gdjs.Area1_461Code.GDBarrierObjects1.length = 0;
gdjs.Area1_461Code.GDBarrierObjects2.length = 0;
gdjs.Area1_461Code.GDBarrierObjects3.length = 0;
gdjs.Area1_461Code.GDBarrierObjects4.length = 0;
gdjs.Area1_461Code.GDBarrierObjects5.length = 0;
gdjs.Area1_461Code.GDBarrierObjects6.length = 0;
gdjs.Area1_461Code.GDBarrierObjects7.length = 0;
gdjs.Area1_461Code.GDBarrierObjects8.length = 0;
gdjs.Area1_461Code.GDBarrierObjects9.length = 0;
gdjs.Area1_461Code.GDbarrierhorizontalObjects1.length = 0;
gdjs.Area1_461Code.GDbarrierhorizontalObjects2.length = 0;
gdjs.Area1_461Code.GDbarrierhorizontalObjects3.length = 0;
gdjs.Area1_461Code.GDbarrierhorizontalObjects4.length = 0;
gdjs.Area1_461Code.GDbarrierhorizontalObjects5.length = 0;
gdjs.Area1_461Code.GDbarrierhorizontalObjects6.length = 0;
gdjs.Area1_461Code.GDbarrierhorizontalObjects7.length = 0;
gdjs.Area1_461Code.GDbarrierhorizontalObjects8.length = 0;
gdjs.Area1_461Code.GDbarrierhorizontalObjects9.length = 0;
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects1.length = 0;
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects2.length = 0;
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects3.length = 0;
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects4.length = 0;
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects5.length = 0;
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects6.length = 0;
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects7.length = 0;
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects8.length = 0;
gdjs.Area1_461Code.GDHealth_9595boss_9595emptyObjects9.length = 0;
gdjs.Area1_461Code.GDstaircaseObjects1.length = 0;
gdjs.Area1_461Code.GDstaircaseObjects2.length = 0;
gdjs.Area1_461Code.GDstaircaseObjects3.length = 0;
gdjs.Area1_461Code.GDstaircaseObjects4.length = 0;
gdjs.Area1_461Code.GDstaircaseObjects5.length = 0;
gdjs.Area1_461Code.GDstaircaseObjects6.length = 0;
gdjs.Area1_461Code.GDstaircaseObjects7.length = 0;
gdjs.Area1_461Code.GDstaircaseObjects8.length = 0;
gdjs.Area1_461Code.GDstaircaseObjects9.length = 0;
gdjs.Area1_461Code.GDPlayerObjects1.length = 0;
gdjs.Area1_461Code.GDPlayerObjects2.length = 0;
gdjs.Area1_461Code.GDPlayerObjects3.length = 0;
gdjs.Area1_461Code.GDPlayerObjects4.length = 0;
gdjs.Area1_461Code.GDPlayerObjects5.length = 0;
gdjs.Area1_461Code.GDPlayerObjects6.length = 0;
gdjs.Area1_461Code.GDPlayerObjects7.length = 0;
gdjs.Area1_461Code.GDPlayerObjects8.length = 0;
gdjs.Area1_461Code.GDPlayerObjects9.length = 0;
gdjs.Area1_461Code.GDSlashObjects1.length = 0;
gdjs.Area1_461Code.GDSlashObjects2.length = 0;
gdjs.Area1_461Code.GDSlashObjects3.length = 0;
gdjs.Area1_461Code.GDSlashObjects4.length = 0;
gdjs.Area1_461Code.GDSlashObjects5.length = 0;
gdjs.Area1_461Code.GDSlashObjects6.length = 0;
gdjs.Area1_461Code.GDSlashObjects7.length = 0;
gdjs.Area1_461Code.GDSlashObjects8.length = 0;
gdjs.Area1_461Code.GDSlashObjects9.length = 0;
gdjs.Area1_461Code.GDShadowObjects1.length = 0;
gdjs.Area1_461Code.GDShadowObjects2.length = 0;
gdjs.Area1_461Code.GDShadowObjects3.length = 0;
gdjs.Area1_461Code.GDShadowObjects4.length = 0;
gdjs.Area1_461Code.GDShadowObjects5.length = 0;
gdjs.Area1_461Code.GDShadowObjects6.length = 0;
gdjs.Area1_461Code.GDShadowObjects7.length = 0;
gdjs.Area1_461Code.GDShadowObjects8.length = 0;
gdjs.Area1_461Code.GDShadowObjects9.length = 0;
gdjs.Area1_461Code.GDStatus_9595boxObjects1.length = 0;
gdjs.Area1_461Code.GDStatus_9595boxObjects2.length = 0;
gdjs.Area1_461Code.GDStatus_9595boxObjects3.length = 0;
gdjs.Area1_461Code.GDStatus_9595boxObjects4.length = 0;
gdjs.Area1_461Code.GDStatus_9595boxObjects5.length = 0;
gdjs.Area1_461Code.GDStatus_9595boxObjects6.length = 0;
gdjs.Area1_461Code.GDStatus_9595boxObjects7.length = 0;
gdjs.Area1_461Code.GDStatus_9595boxObjects8.length = 0;
gdjs.Area1_461Code.GDStatus_9595boxObjects9.length = 0;
gdjs.Area1_461Code.GDHealthBarObjects1.length = 0;
gdjs.Area1_461Code.GDHealthBarObjects2.length = 0;
gdjs.Area1_461Code.GDHealthBarObjects3.length = 0;
gdjs.Area1_461Code.GDHealthBarObjects4.length = 0;
gdjs.Area1_461Code.GDHealthBarObjects5.length = 0;
gdjs.Area1_461Code.GDHealthBarObjects6.length = 0;
gdjs.Area1_461Code.GDHealthBarObjects7.length = 0;
gdjs.Area1_461Code.GDHealthBarObjects8.length = 0;
gdjs.Area1_461Code.GDHealthBarObjects9.length = 0;
gdjs.Area1_461Code.GDTargetObjects1.length = 0;
gdjs.Area1_461Code.GDTargetObjects2.length = 0;
gdjs.Area1_461Code.GDTargetObjects3.length = 0;
gdjs.Area1_461Code.GDTargetObjects4.length = 0;
gdjs.Area1_461Code.GDTargetObjects5.length = 0;
gdjs.Area1_461Code.GDTargetObjects6.length = 0;
gdjs.Area1_461Code.GDTargetObjects7.length = 0;
gdjs.Area1_461Code.GDTargetObjects8.length = 0;
gdjs.Area1_461Code.GDTargetObjects9.length = 0;
gdjs.Area1_461Code.GDHPObjects1.length = 0;
gdjs.Area1_461Code.GDHPObjects2.length = 0;
gdjs.Area1_461Code.GDHPObjects3.length = 0;
gdjs.Area1_461Code.GDHPObjects4.length = 0;
gdjs.Area1_461Code.GDHPObjects5.length = 0;
gdjs.Area1_461Code.GDHPObjects6.length = 0;
gdjs.Area1_461Code.GDHPObjects7.length = 0;
gdjs.Area1_461Code.GDHPObjects8.length = 0;
gdjs.Area1_461Code.GDHPObjects9.length = 0;
gdjs.Area1_461Code.GDLevel_9595numberObjects1.length = 0;
gdjs.Area1_461Code.GDLevel_9595numberObjects2.length = 0;
gdjs.Area1_461Code.GDLevel_9595numberObjects3.length = 0;
gdjs.Area1_461Code.GDLevel_9595numberObjects4.length = 0;
gdjs.Area1_461Code.GDLevel_9595numberObjects5.length = 0;
gdjs.Area1_461Code.GDLevel_9595numberObjects6.length = 0;
gdjs.Area1_461Code.GDLevel_9595numberObjects7.length = 0;
gdjs.Area1_461Code.GDLevel_9595numberObjects8.length = 0;
gdjs.Area1_461Code.GDLevel_9595numberObjects9.length = 0;
gdjs.Area1_461Code.GDplayernameObjects1.length = 0;
gdjs.Area1_461Code.GDplayernameObjects2.length = 0;
gdjs.Area1_461Code.GDplayernameObjects3.length = 0;
gdjs.Area1_461Code.GDplayernameObjects4.length = 0;
gdjs.Area1_461Code.GDplayernameObjects5.length = 0;
gdjs.Area1_461Code.GDplayernameObjects6.length = 0;
gdjs.Area1_461Code.GDplayernameObjects7.length = 0;
gdjs.Area1_461Code.GDplayernameObjects8.length = 0;
gdjs.Area1_461Code.GDplayernameObjects9.length = 0;
gdjs.Area1_461Code.GDScreenObjects1.length = 0;
gdjs.Area1_461Code.GDScreenObjects2.length = 0;
gdjs.Area1_461Code.GDScreenObjects3.length = 0;
gdjs.Area1_461Code.GDScreenObjects4.length = 0;
gdjs.Area1_461Code.GDScreenObjects5.length = 0;
gdjs.Area1_461Code.GDScreenObjects6.length = 0;
gdjs.Area1_461Code.GDScreenObjects7.length = 0;
gdjs.Area1_461Code.GDScreenObjects8.length = 0;
gdjs.Area1_461Code.GDScreenObjects9.length = 0;
gdjs.Area1_461Code.GDMenuObjects1.length = 0;
gdjs.Area1_461Code.GDMenuObjects2.length = 0;
gdjs.Area1_461Code.GDMenuObjects3.length = 0;
gdjs.Area1_461Code.GDMenuObjects4.length = 0;
gdjs.Area1_461Code.GDMenuObjects5.length = 0;
gdjs.Area1_461Code.GDMenuObjects6.length = 0;
gdjs.Area1_461Code.GDMenuObjects7.length = 0;
gdjs.Area1_461Code.GDMenuObjects8.length = 0;
gdjs.Area1_461Code.GDMenuObjects9.length = 0;
gdjs.Area1_461Code.GDHealthemptyObjects1.length = 0;
gdjs.Area1_461Code.GDHealthemptyObjects2.length = 0;
gdjs.Area1_461Code.GDHealthemptyObjects3.length = 0;
gdjs.Area1_461Code.GDHealthemptyObjects4.length = 0;
gdjs.Area1_461Code.GDHealthemptyObjects5.length = 0;
gdjs.Area1_461Code.GDHealthemptyObjects6.length = 0;
gdjs.Area1_461Code.GDHealthemptyObjects7.length = 0;
gdjs.Area1_461Code.GDHealthemptyObjects8.length = 0;
gdjs.Area1_461Code.GDHealthemptyObjects9.length = 0;
gdjs.Area1_461Code.GDPotionObjects1.length = 0;
gdjs.Area1_461Code.GDPotionObjects2.length = 0;
gdjs.Area1_461Code.GDPotionObjects3.length = 0;
gdjs.Area1_461Code.GDPotionObjects4.length = 0;
gdjs.Area1_461Code.GDPotionObjects5.length = 0;
gdjs.Area1_461Code.GDPotionObjects6.length = 0;
gdjs.Area1_461Code.GDPotionObjects7.length = 0;
gdjs.Area1_461Code.GDPotionObjects8.length = 0;
gdjs.Area1_461Code.GDPotionObjects9.length = 0;
gdjs.Area1_461Code.GDPotion_9595boxObjects1.length = 0;
gdjs.Area1_461Code.GDPotion_9595boxObjects2.length = 0;
gdjs.Area1_461Code.GDPotion_9595boxObjects3.length = 0;
gdjs.Area1_461Code.GDPotion_9595boxObjects4.length = 0;
gdjs.Area1_461Code.GDPotion_9595boxObjects5.length = 0;
gdjs.Area1_461Code.GDPotion_9595boxObjects6.length = 0;
gdjs.Area1_461Code.GDPotion_9595boxObjects7.length = 0;
gdjs.Area1_461Code.GDPotion_9595boxObjects8.length = 0;
gdjs.Area1_461Code.GDPotion_9595boxObjects9.length = 0;
gdjs.Area1_461Code.GDPotion_9595numberObjects1.length = 0;
gdjs.Area1_461Code.GDPotion_9595numberObjects2.length = 0;
gdjs.Area1_461Code.GDPotion_9595numberObjects3.length = 0;
gdjs.Area1_461Code.GDPotion_9595numberObjects4.length = 0;
gdjs.Area1_461Code.GDPotion_9595numberObjects5.length = 0;
gdjs.Area1_461Code.GDPotion_9595numberObjects6.length = 0;
gdjs.Area1_461Code.GDPotion_9595numberObjects7.length = 0;
gdjs.Area1_461Code.GDPotion_9595numberObjects8.length = 0;
gdjs.Area1_461Code.GDPotion_9595numberObjects9.length = 0;
gdjs.Area1_461Code.GDTImerObjects1.length = 0;
gdjs.Area1_461Code.GDTImerObjects2.length = 0;
gdjs.Area1_461Code.GDTImerObjects3.length = 0;
gdjs.Area1_461Code.GDTImerObjects4.length = 0;
gdjs.Area1_461Code.GDTImerObjects5.length = 0;
gdjs.Area1_461Code.GDTImerObjects6.length = 0;
gdjs.Area1_461Code.GDTImerObjects7.length = 0;
gdjs.Area1_461Code.GDTImerObjects8.length = 0;
gdjs.Area1_461Code.GDTImerObjects9.length = 0;
gdjs.Area1_461Code.GDKillcountObjects1.length = 0;
gdjs.Area1_461Code.GDKillcountObjects2.length = 0;
gdjs.Area1_461Code.GDKillcountObjects3.length = 0;
gdjs.Area1_461Code.GDKillcountObjects4.length = 0;
gdjs.Area1_461Code.GDKillcountObjects5.length = 0;
gdjs.Area1_461Code.GDKillcountObjects6.length = 0;
gdjs.Area1_461Code.GDKillcountObjects7.length = 0;
gdjs.Area1_461Code.GDKillcountObjects8.length = 0;
gdjs.Area1_461Code.GDKillcountObjects9.length = 0;

gdjs.Area1_461Code.eventsList77(runtimeScene);

return;

}

gdjs['Area1_461Code'] = gdjs.Area1_461Code;
