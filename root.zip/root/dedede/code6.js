gdjs.Area1_463Code = {};
gdjs.Area1_463Code.GDMenuObjects2_1final = [];

gdjs.Area1_463Code.GDPotion_9595boxObjects1_1final = [];

gdjs.Area1_463Code.GDPaimonObjects1= [];
gdjs.Area1_463Code.GDPaimonObjects2= [];
gdjs.Area1_463Code.GDPaimonObjects3= [];
gdjs.Area1_463Code.GDPaimonObjects4= [];
gdjs.Area1_463Code.GDPaimonObjects5= [];
gdjs.Area1_463Code.GDPaimonObjects6= [];
gdjs.Area1_463Code.GDPaimonObjects7= [];
gdjs.Area1_463Code.GDPaimonObjects8= [];
gdjs.Area1_463Code.GDPaimonObjects9= [];
gdjs.Area1_463Code.GDFloorObjects1= [];
gdjs.Area1_463Code.GDFloorObjects2= [];
gdjs.Area1_463Code.GDFloorObjects3= [];
gdjs.Area1_463Code.GDFloorObjects4= [];
gdjs.Area1_463Code.GDFloorObjects5= [];
gdjs.Area1_463Code.GDFloorObjects6= [];
gdjs.Area1_463Code.GDFloorObjects7= [];
gdjs.Area1_463Code.GDFloorObjects8= [];
gdjs.Area1_463Code.GDFloorObjects9= [];
gdjs.Area1_463Code.GDWall_9595HorizontalObjects1= [];
gdjs.Area1_463Code.GDWall_9595HorizontalObjects2= [];
gdjs.Area1_463Code.GDWall_9595HorizontalObjects3= [];
gdjs.Area1_463Code.GDWall_9595HorizontalObjects4= [];
gdjs.Area1_463Code.GDWall_9595HorizontalObjects5= [];
gdjs.Area1_463Code.GDWall_9595HorizontalObjects6= [];
gdjs.Area1_463Code.GDWall_9595HorizontalObjects7= [];
gdjs.Area1_463Code.GDWall_9595HorizontalObjects8= [];
gdjs.Area1_463Code.GDWall_9595HorizontalObjects9= [];
gdjs.Area1_463Code.GDWall_9595VerticalObjects1= [];
gdjs.Area1_463Code.GDWall_9595VerticalObjects2= [];
gdjs.Area1_463Code.GDWall_9595VerticalObjects3= [];
gdjs.Area1_463Code.GDWall_9595VerticalObjects4= [];
gdjs.Area1_463Code.GDWall_9595VerticalObjects5= [];
gdjs.Area1_463Code.GDWall_9595VerticalObjects6= [];
gdjs.Area1_463Code.GDWall_9595VerticalObjects7= [];
gdjs.Area1_463Code.GDWall_9595VerticalObjects8= [];
gdjs.Area1_463Code.GDWall_9595VerticalObjects9= [];
gdjs.Area1_463Code.GDBarrierObjects1= [];
gdjs.Area1_463Code.GDBarrierObjects2= [];
gdjs.Area1_463Code.GDBarrierObjects3= [];
gdjs.Area1_463Code.GDBarrierObjects4= [];
gdjs.Area1_463Code.GDBarrierObjects5= [];
gdjs.Area1_463Code.GDBarrierObjects6= [];
gdjs.Area1_463Code.GDBarrierObjects7= [];
gdjs.Area1_463Code.GDBarrierObjects8= [];
gdjs.Area1_463Code.GDBarrierObjects9= [];
gdjs.Area1_463Code.GDCollision_9595MaskObjects1= [];
gdjs.Area1_463Code.GDCollision_9595MaskObjects2= [];
gdjs.Area1_463Code.GDCollision_9595MaskObjects3= [];
gdjs.Area1_463Code.GDCollision_9595MaskObjects4= [];
gdjs.Area1_463Code.GDCollision_9595MaskObjects5= [];
gdjs.Area1_463Code.GDCollision_9595MaskObjects6= [];
gdjs.Area1_463Code.GDCollision_9595MaskObjects7= [];
gdjs.Area1_463Code.GDCollision_9595MaskObjects8= [];
gdjs.Area1_463Code.GDCollision_9595MaskObjects9= [];
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects1= [];
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects2= [];
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3= [];
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects4= [];
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects5= [];
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects6= [];
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects7= [];
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects8= [];
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects9= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects1= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects2= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects4= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects5= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects6= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects7= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects8= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects9= [];
gdjs.Area1_463Code.GDBoss_9595nameObjects1= [];
gdjs.Area1_463Code.GDBoss_9595nameObjects2= [];
gdjs.Area1_463Code.GDBoss_9595nameObjects3= [];
gdjs.Area1_463Code.GDBoss_9595nameObjects4= [];
gdjs.Area1_463Code.GDBoss_9595nameObjects5= [];
gdjs.Area1_463Code.GDBoss_9595nameObjects6= [];
gdjs.Area1_463Code.GDBoss_9595nameObjects7= [];
gdjs.Area1_463Code.GDBoss_9595nameObjects8= [];
gdjs.Area1_463Code.GDBoss_9595nameObjects9= [];
gdjs.Area1_463Code.GDGungnirObjects1= [];
gdjs.Area1_463Code.GDGungnirObjects2= [];
gdjs.Area1_463Code.GDGungnirObjects3= [];
gdjs.Area1_463Code.GDGungnirObjects4= [];
gdjs.Area1_463Code.GDGungnirObjects5= [];
gdjs.Area1_463Code.GDGungnirObjects6= [];
gdjs.Area1_463Code.GDGungnirObjects7= [];
gdjs.Area1_463Code.GDGungnirObjects8= [];
gdjs.Area1_463Code.GDGungnirObjects9= [];
gdjs.Area1_463Code.GDattackzoneObjects1= [];
gdjs.Area1_463Code.GDattackzoneObjects2= [];
gdjs.Area1_463Code.GDattackzoneObjects3= [];
gdjs.Area1_463Code.GDattackzoneObjects4= [];
gdjs.Area1_463Code.GDattackzoneObjects5= [];
gdjs.Area1_463Code.GDattackzoneObjects6= [];
gdjs.Area1_463Code.GDattackzoneObjects7= [];
gdjs.Area1_463Code.GDattackzoneObjects8= [];
gdjs.Area1_463Code.GDattackzoneObjects9= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects1= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects2= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects4= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects5= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects6= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects7= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects8= [];
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects9= [];
gdjs.Area1_463Code.GDSpawnObjects1= [];
gdjs.Area1_463Code.GDSpawnObjects2= [];
gdjs.Area1_463Code.GDSpawnObjects3= [];
gdjs.Area1_463Code.GDSpawnObjects4= [];
gdjs.Area1_463Code.GDSpawnObjects5= [];
gdjs.Area1_463Code.GDSpawnObjects6= [];
gdjs.Area1_463Code.GDSpawnObjects7= [];
gdjs.Area1_463Code.GDSpawnObjects8= [];
gdjs.Area1_463Code.GDSpawnObjects9= [];
gdjs.Area1_463Code.GDSlimeObjects1= [];
gdjs.Area1_463Code.GDSlimeObjects2= [];
gdjs.Area1_463Code.GDSlimeObjects3= [];
gdjs.Area1_463Code.GDSlimeObjects4= [];
gdjs.Area1_463Code.GDSlimeObjects5= [];
gdjs.Area1_463Code.GDSlimeObjects6= [];
gdjs.Area1_463Code.GDSlimeObjects7= [];
gdjs.Area1_463Code.GDSlimeObjects8= [];
gdjs.Area1_463Code.GDSlimeObjects9= [];
gdjs.Area1_463Code.GDTEXTObjects1= [];
gdjs.Area1_463Code.GDTEXTObjects2= [];
gdjs.Area1_463Code.GDTEXTObjects3= [];
gdjs.Area1_463Code.GDTEXTObjects4= [];
gdjs.Area1_463Code.GDTEXTObjects5= [];
gdjs.Area1_463Code.GDTEXTObjects6= [];
gdjs.Area1_463Code.GDTEXTObjects7= [];
gdjs.Area1_463Code.GDTEXTObjects8= [];
gdjs.Area1_463Code.GDTEXTObjects9= [];
gdjs.Area1_463Code.GDNewTiledSpriteObjects1= [];
gdjs.Area1_463Code.GDNewTiledSpriteObjects2= [];
gdjs.Area1_463Code.GDNewTiledSpriteObjects3= [];
gdjs.Area1_463Code.GDNewTiledSpriteObjects4= [];
gdjs.Area1_463Code.GDNewTiledSpriteObjects5= [];
gdjs.Area1_463Code.GDNewTiledSpriteObjects6= [];
gdjs.Area1_463Code.GDNewTiledSpriteObjects7= [];
gdjs.Area1_463Code.GDNewTiledSpriteObjects8= [];
gdjs.Area1_463Code.GDNewTiledSpriteObjects9= [];
gdjs.Area1_463Code.GDStaircaseObjects1= [];
gdjs.Area1_463Code.GDStaircaseObjects2= [];
gdjs.Area1_463Code.GDStaircaseObjects3= [];
gdjs.Area1_463Code.GDStaircaseObjects4= [];
gdjs.Area1_463Code.GDStaircaseObjects5= [];
gdjs.Area1_463Code.GDStaircaseObjects6= [];
gdjs.Area1_463Code.GDStaircaseObjects7= [];
gdjs.Area1_463Code.GDStaircaseObjects8= [];
gdjs.Area1_463Code.GDStaircaseObjects9= [];
gdjs.Area1_463Code.GDPlayerObjects1= [];
gdjs.Area1_463Code.GDPlayerObjects2= [];
gdjs.Area1_463Code.GDPlayerObjects3= [];
gdjs.Area1_463Code.GDPlayerObjects4= [];
gdjs.Area1_463Code.GDPlayerObjects5= [];
gdjs.Area1_463Code.GDPlayerObjects6= [];
gdjs.Area1_463Code.GDPlayerObjects7= [];
gdjs.Area1_463Code.GDPlayerObjects8= [];
gdjs.Area1_463Code.GDPlayerObjects9= [];
gdjs.Area1_463Code.GDSlashObjects1= [];
gdjs.Area1_463Code.GDSlashObjects2= [];
gdjs.Area1_463Code.GDSlashObjects3= [];
gdjs.Area1_463Code.GDSlashObjects4= [];
gdjs.Area1_463Code.GDSlashObjects5= [];
gdjs.Area1_463Code.GDSlashObjects6= [];
gdjs.Area1_463Code.GDSlashObjects7= [];
gdjs.Area1_463Code.GDSlashObjects8= [];
gdjs.Area1_463Code.GDSlashObjects9= [];
gdjs.Area1_463Code.GDShadowObjects1= [];
gdjs.Area1_463Code.GDShadowObjects2= [];
gdjs.Area1_463Code.GDShadowObjects3= [];
gdjs.Area1_463Code.GDShadowObjects4= [];
gdjs.Area1_463Code.GDShadowObjects5= [];
gdjs.Area1_463Code.GDShadowObjects6= [];
gdjs.Area1_463Code.GDShadowObjects7= [];
gdjs.Area1_463Code.GDShadowObjects8= [];
gdjs.Area1_463Code.GDShadowObjects9= [];
gdjs.Area1_463Code.GDStatus_9595boxObjects1= [];
gdjs.Area1_463Code.GDStatus_9595boxObjects2= [];
gdjs.Area1_463Code.GDStatus_9595boxObjects3= [];
gdjs.Area1_463Code.GDStatus_9595boxObjects4= [];
gdjs.Area1_463Code.GDStatus_9595boxObjects5= [];
gdjs.Area1_463Code.GDStatus_9595boxObjects6= [];
gdjs.Area1_463Code.GDStatus_9595boxObjects7= [];
gdjs.Area1_463Code.GDStatus_9595boxObjects8= [];
gdjs.Area1_463Code.GDStatus_9595boxObjects9= [];
gdjs.Area1_463Code.GDHealthBarObjects1= [];
gdjs.Area1_463Code.GDHealthBarObjects2= [];
gdjs.Area1_463Code.GDHealthBarObjects3= [];
gdjs.Area1_463Code.GDHealthBarObjects4= [];
gdjs.Area1_463Code.GDHealthBarObjects5= [];
gdjs.Area1_463Code.GDHealthBarObjects6= [];
gdjs.Area1_463Code.GDHealthBarObjects7= [];
gdjs.Area1_463Code.GDHealthBarObjects8= [];
gdjs.Area1_463Code.GDHealthBarObjects9= [];
gdjs.Area1_463Code.GDTargetObjects1= [];
gdjs.Area1_463Code.GDTargetObjects2= [];
gdjs.Area1_463Code.GDTargetObjects3= [];
gdjs.Area1_463Code.GDTargetObjects4= [];
gdjs.Area1_463Code.GDTargetObjects5= [];
gdjs.Area1_463Code.GDTargetObjects6= [];
gdjs.Area1_463Code.GDTargetObjects7= [];
gdjs.Area1_463Code.GDTargetObjects8= [];
gdjs.Area1_463Code.GDTargetObjects9= [];
gdjs.Area1_463Code.GDHPObjects1= [];
gdjs.Area1_463Code.GDHPObjects2= [];
gdjs.Area1_463Code.GDHPObjects3= [];
gdjs.Area1_463Code.GDHPObjects4= [];
gdjs.Area1_463Code.GDHPObjects5= [];
gdjs.Area1_463Code.GDHPObjects6= [];
gdjs.Area1_463Code.GDHPObjects7= [];
gdjs.Area1_463Code.GDHPObjects8= [];
gdjs.Area1_463Code.GDHPObjects9= [];
gdjs.Area1_463Code.GDLevel_9595numberObjects1= [];
gdjs.Area1_463Code.GDLevel_9595numberObjects2= [];
gdjs.Area1_463Code.GDLevel_9595numberObjects3= [];
gdjs.Area1_463Code.GDLevel_9595numberObjects4= [];
gdjs.Area1_463Code.GDLevel_9595numberObjects5= [];
gdjs.Area1_463Code.GDLevel_9595numberObjects6= [];
gdjs.Area1_463Code.GDLevel_9595numberObjects7= [];
gdjs.Area1_463Code.GDLevel_9595numberObjects8= [];
gdjs.Area1_463Code.GDLevel_9595numberObjects9= [];
gdjs.Area1_463Code.GDplayernameObjects1= [];
gdjs.Area1_463Code.GDplayernameObjects2= [];
gdjs.Area1_463Code.GDplayernameObjects3= [];
gdjs.Area1_463Code.GDplayernameObjects4= [];
gdjs.Area1_463Code.GDplayernameObjects5= [];
gdjs.Area1_463Code.GDplayernameObjects6= [];
gdjs.Area1_463Code.GDplayernameObjects7= [];
gdjs.Area1_463Code.GDplayernameObjects8= [];
gdjs.Area1_463Code.GDplayernameObjects9= [];
gdjs.Area1_463Code.GDScreenObjects1= [];
gdjs.Area1_463Code.GDScreenObjects2= [];
gdjs.Area1_463Code.GDScreenObjects3= [];
gdjs.Area1_463Code.GDScreenObjects4= [];
gdjs.Area1_463Code.GDScreenObjects5= [];
gdjs.Area1_463Code.GDScreenObjects6= [];
gdjs.Area1_463Code.GDScreenObjects7= [];
gdjs.Area1_463Code.GDScreenObjects8= [];
gdjs.Area1_463Code.GDScreenObjects9= [];
gdjs.Area1_463Code.GDMenuObjects1= [];
gdjs.Area1_463Code.GDMenuObjects2= [];
gdjs.Area1_463Code.GDMenuObjects3= [];
gdjs.Area1_463Code.GDMenuObjects4= [];
gdjs.Area1_463Code.GDMenuObjects5= [];
gdjs.Area1_463Code.GDMenuObjects6= [];
gdjs.Area1_463Code.GDMenuObjects7= [];
gdjs.Area1_463Code.GDMenuObjects8= [];
gdjs.Area1_463Code.GDMenuObjects9= [];
gdjs.Area1_463Code.GDHealthemptyObjects1= [];
gdjs.Area1_463Code.GDHealthemptyObjects2= [];
gdjs.Area1_463Code.GDHealthemptyObjects3= [];
gdjs.Area1_463Code.GDHealthemptyObjects4= [];
gdjs.Area1_463Code.GDHealthemptyObjects5= [];
gdjs.Area1_463Code.GDHealthemptyObjects6= [];
gdjs.Area1_463Code.GDHealthemptyObjects7= [];
gdjs.Area1_463Code.GDHealthemptyObjects8= [];
gdjs.Area1_463Code.GDHealthemptyObjects9= [];
gdjs.Area1_463Code.GDPotionObjects1= [];
gdjs.Area1_463Code.GDPotionObjects2= [];
gdjs.Area1_463Code.GDPotionObjects3= [];
gdjs.Area1_463Code.GDPotionObjects4= [];
gdjs.Area1_463Code.GDPotionObjects5= [];
gdjs.Area1_463Code.GDPotionObjects6= [];
gdjs.Area1_463Code.GDPotionObjects7= [];
gdjs.Area1_463Code.GDPotionObjects8= [];
gdjs.Area1_463Code.GDPotionObjects9= [];
gdjs.Area1_463Code.GDPotion_9595boxObjects1= [];
gdjs.Area1_463Code.GDPotion_9595boxObjects2= [];
gdjs.Area1_463Code.GDPotion_9595boxObjects3= [];
gdjs.Area1_463Code.GDPotion_9595boxObjects4= [];
gdjs.Area1_463Code.GDPotion_9595boxObjects5= [];
gdjs.Area1_463Code.GDPotion_9595boxObjects6= [];
gdjs.Area1_463Code.GDPotion_9595boxObjects7= [];
gdjs.Area1_463Code.GDPotion_9595boxObjects8= [];
gdjs.Area1_463Code.GDPotion_9595boxObjects9= [];
gdjs.Area1_463Code.GDPotion_9595numberObjects1= [];
gdjs.Area1_463Code.GDPotion_9595numberObjects2= [];
gdjs.Area1_463Code.GDPotion_9595numberObjects3= [];
gdjs.Area1_463Code.GDPotion_9595numberObjects4= [];
gdjs.Area1_463Code.GDPotion_9595numberObjects5= [];
gdjs.Area1_463Code.GDPotion_9595numberObjects6= [];
gdjs.Area1_463Code.GDPotion_9595numberObjects7= [];
gdjs.Area1_463Code.GDPotion_9595numberObjects8= [];
gdjs.Area1_463Code.GDPotion_9595numberObjects9= [];
gdjs.Area1_463Code.GDTImerObjects1= [];
gdjs.Area1_463Code.GDTImerObjects2= [];
gdjs.Area1_463Code.GDTImerObjects3= [];
gdjs.Area1_463Code.GDTImerObjects4= [];
gdjs.Area1_463Code.GDTImerObjects5= [];
gdjs.Area1_463Code.GDTImerObjects6= [];
gdjs.Area1_463Code.GDTImerObjects7= [];
gdjs.Area1_463Code.GDTImerObjects8= [];
gdjs.Area1_463Code.GDTImerObjects9= [];
gdjs.Area1_463Code.GDKillcountObjects1= [];
gdjs.Area1_463Code.GDKillcountObjects2= [];
gdjs.Area1_463Code.GDKillcountObjects3= [];
gdjs.Area1_463Code.GDKillcountObjects4= [];
gdjs.Area1_463Code.GDKillcountObjects5= [];
gdjs.Area1_463Code.GDKillcountObjects6= [];
gdjs.Area1_463Code.GDKillcountObjects7= [];
gdjs.Area1_463Code.GDKillcountObjects8= [];
gdjs.Area1_463Code.GDKillcountObjects9= [];


gdjs.Area1_463Code.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects7);

{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects7.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects7[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(8).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects7.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects7[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(8).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_463Code.asyncCallback8755772 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(8)));
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9)));
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)));
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)));
}
{ //Subevents
gdjs.Area1_463Code.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/maxexp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(9), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8755772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8754836 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/hp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(8), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8754836(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8753708 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/spd/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(7), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8753708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8752644 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/atk/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(5), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8752644(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8751580 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_463Code.GDPlayerObjects1) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/def/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(6), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8751580(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects6);
{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects6.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects6[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects6.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects6[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_463Code.asyncCallback8761940 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8761940(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8761604 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8761604(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8761228 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8761228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8760892 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8760892(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8760428 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8760428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.eventsList12 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_463Code.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_463Code.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDScreenObjects1Objects = Hashtable.newFrom({"Screen": gdjs.Area1_463Code.GDScreenObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDMenuObjects1Objects = Hashtable.newFrom({"Menu": gdjs.Area1_463Code.GDMenuObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDStatus_95959595boxObjects1Objects = Hashtable.newFrom({"Status_box": gdjs.Area1_463Code.GDStatus_9595boxObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDHPObjects1Objects = Hashtable.newFrom({"HP": gdjs.Area1_463Code.GDHPObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDHealthBarObjects1Objects = Hashtable.newFrom({"HealthBar": gdjs.Area1_463Code.GDHealthBarObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDTargetObjects1Objects = Hashtable.newFrom({"Target": gdjs.Area1_463Code.GDTargetObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDLevel_95959595numberObjects1Objects = Hashtable.newFrom({"Level_number": gdjs.Area1_463Code.GDLevel_9595numberObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDplayernameObjects1Objects = Hashtable.newFrom({"playername": gdjs.Area1_463Code.GDplayernameObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPotion_95959595boxObjects1Objects = Hashtable.newFrom({"Potion_box": gdjs.Area1_463Code.GDPotion_9595boxObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPotion_95959595numberObjects1Objects = Hashtable.newFrom({"Potion_number": gdjs.Area1_463Code.GDPotion_9595numberObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDKillcountObjects1Objects = Hashtable.newFrom({"Killcount": gdjs.Area1_463Code.GDKillcountObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDTImerObjects1Objects = Hashtable.newFrom({"TImer": gdjs.Area1_463Code.GDTImerObjects1});
gdjs.Area1_463Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Collision_Mask"), gdjs.Area1_463Code.GDCollision_9595MaskObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects2);
gdjs.copyArray(gdjs.Area1_463Code.GDScreenObjects1, gdjs.Area1_463Code.GDScreenObjects2);

gdjs.copyArray(gdjs.Area1_463Code.GDStatus_9595boxObjects1, gdjs.Area1_463Code.GDStatus_9595boxObjects2);

{for(var i = 0, len = gdjs.Area1_463Code.GDScreenObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDScreenObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDStatus_9595boxObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDStatus_9595boxObjects2[i].getBehavior("Opacity").setOpacity(200);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDStatus_9595boxObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDStatus_9595boxObjects2[i].getBehavior("Resizable").setSize(300, 150);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects2[i].getBehavior("Resizable").setSize(77, 96);
}
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.Area1_463Code.GDCollision_9595MaskObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDCollision_9595MaskObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Area1_463Code.GDKillcountObjects1 */
/* Reuse gdjs.Area1_463Code.GDLevel_9595numberObjects1 */
/* Reuse gdjs.Area1_463Code.GDplayernameObjects1 */
{for(var i = 0, len = gdjs.Area1_463Code.GDplayernameObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDplayernameObjects1[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(2).getAsString());
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDLevel_9595numberObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDLevel_9595numberObjects1[i].setBBText("LV. " + runtimeScene.getGame().getVariables().getFromIndex(3).getAsString());
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDKillcountObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDKillcountObjects1[i].setBBText("Kill : " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(23))));
}
}}

}


};gdjs.Area1_463Code.eventsList14 = function(runtimeScene) {

{

gdjs.Area1_463Code.GDMenuObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Area1_463Code.GDMenuObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Area1_463Code.GDMenuObjects3);
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDMenuObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDMenuObjects3[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.Area1_463Code.GDMenuObjects3[k] = gdjs.Area1_463Code.GDMenuObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDMenuObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Area1_463Code.GDMenuObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Area1_463Code.GDMenuObjects2_1final.indexOf(gdjs.Area1_463Code.GDMenuObjects3[j]) === -1 )
            gdjs.Area1_463Code.GDMenuObjects2_1final.push(gdjs.Area1_463Code.GDMenuObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.Area1_463Code.GDMenuObjects2_1final, gdjs.Area1_463Code.GDMenuObjects2);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Menu");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyReleased(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_463Code.GDHealthBarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Area1_463Code.GDHealthBarObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealthBarObjects2[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_463Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_463Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}}

}


{

gdjs.Area1_463Code.GDPotion_9595boxObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Area1_463Code.GDPotion_9595boxObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_463Code.GDPotion_9595boxObjects2);
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPotion_9595boxObjects2.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPotion_9595boxObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.Area1_463Code.GDPotion_9595boxObjects2[k] = gdjs.Area1_463Code.GDPotion_9595boxObjects2[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPotion_9595boxObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Area1_463Code.GDPotion_9595boxObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Area1_463Code.GDPotion_9595boxObjects1_1final.indexOf(gdjs.Area1_463Code.GDPotion_9595boxObjects2[j]) === -1 )
            gdjs.Area1_463Code.GDPotion_9595boxObjects1_1final.push(gdjs.Area1_463Code.GDPotion_9595boxObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "f");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.Area1_463Code.GDPotion_9595boxObjects1_1final, gdjs.Area1_463Code.GDPotion_9595boxObjects1);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_463Code.GDHealthBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_463Code.GDPotion_9595numberObjects1);
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects1[i].getBehavior("Health").Heal((gdjs.Area1_463Code.GDPlayerObjects1[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealthBarObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealthBarObjects1[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_463Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_463Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}{runtimeScene.getGame().getVariables().getFromIndex(16).sub(1);
}{for(var i = 0, len = gdjs.Area1_463Code.GDPotion_9595numberObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPotion_9595numberObjects1[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16))) + "x");
}
}}

}


};gdjs.Area1_463Code.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HP"), gdjs.Area1_463Code.GDHPObjects3);
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_463Code.GDHealthBarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Healthempty"), gdjs.Area1_463Code.GDHealthemptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_463Code.GDKillcountObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_number"), gdjs.Area1_463Code.GDLevel_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Area1_463Code.GDMenuObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_463Code.GDPotion_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_463Code.GDPotion_9595numberObjects3);
gdjs.copyArray(gdjs.Area1_463Code.GDScreenObjects2, gdjs.Area1_463Code.GDScreenObjects3);

gdjs.copyArray(runtimeScene.getObjects("Status_box"), gdjs.Area1_463Code.GDStatus_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_463Code.GDTImerObjects3);
gdjs.copyArray(runtimeScene.getObjects("playername"), gdjs.Area1_463Code.GDplayernameObjects3);
{for(var i = 0, len = gdjs.Area1_463Code.GDStatus_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDStatus_9595boxObjects3[i].setZOrder((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDMenuObjects3[i].setZOrder((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDTImerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTImerObjects3[i].setZOrder((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPotion_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPotion_9595boxObjects3[i].setZOrder((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDKillcountObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDKillcountObjects3[i].setZOrder((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPotion_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPotion_9595numberObjects3[i].setZOrder((( gdjs.Area1_463Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPotion_9595boxObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHPObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHPObjects3[i].setZOrder((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealthemptyObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealthemptyObjects3[i].setZOrder((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getZOrder()) + 2);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealthBarObjects3[i].setZOrder((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getZOrder()) + 3);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDLevel_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDLevel_9595numberObjects3[i].setZOrder((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDplayernameObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDplayernameObjects3[i].setZOrder((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getZOrder()) + 3);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.Area1_463Code.GDFloorObjects3);
gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects2, gdjs.Area1_463Code.GDPlayerObjects3);

gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_463Code.GDWall_9595HorizontalObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall_Vertical"), gdjs.Area1_463Code.GDWall_9595VerticalObjects3);
{for(var i = 0, len = gdjs.Area1_463Code.GDFloorObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDFloorObjects3[i].setZOrder((( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getZOrder()) - 10);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDWall_9595VerticalObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDWall_9595VerticalObjects3[i].setZOrder((( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getZOrder()) - 4);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDWall_9595HorizontalObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDWall_9595HorizontalObjects3[i].setZOrder((( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getZOrder()) - 4);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.Area1_463Code.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Screen"), gdjs.Area1_463Code.GDScreenObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shadow"), gdjs.Area1_463Code.GDShadowObjects2);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Area1_463Code.GDTargetObjects2);
{for(var i = 0, len = gdjs.Area1_463Code.GDShadowObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDShadowObjects2[i].setZOrder((( gdjs.Area1_463Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects2[0].getZOrder()) - 3);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDScreenObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDScreenObjects2[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDTargetObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTargetObjects2[i].setZOrder((( gdjs.Area1_463Code.GDScreenObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects2[0].getZOrder()) + 10);
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList15(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPlayerObjects2[i].getY() > (( gdjs.Area1_463Code.GDPaimonObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects2[0].getPointY("Zorder")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects2[k] = gdjs.Area1_463Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPaimonObjects2 */
/* Reuse gdjs.Area1_463Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_463Code.GDSlashObjects2);
{for(var i = 0, len = gdjs.Area1_463Code.GDSlashObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlashObjects2[i].setZOrder((( gdjs.Area1_463Code.GDPaimonObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects2[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects2[i].setZOrder((( gdjs.Area1_463Code.GDPaimonObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects2[0].getZOrder()) + 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects2);
gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDGungnirObjects2.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDGungnirObjects2[i].getY() > (( gdjs.Area1_463Code.GDPaimonObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects2[0].getPointY("Zorder")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDGungnirObjects2[k] = gdjs.Area1_463Code.GDGungnirObjects2[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDGungnirObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDGungnirObjects2 */
/* Reuse gdjs.Area1_463Code.GDPaimonObjects2 */
{for(var i = 0, len = gdjs.Area1_463Code.GDGungnirObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDGungnirObjects2[i].setZOrder((( gdjs.Area1_463Code.GDPaimonObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects2[0].getZOrder()) + 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPlayerObjects1[i].getY() < (( gdjs.Area1_463Code.GDPaimonObjects1.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects1[0].getPointY("Zorder")) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects1[k] = gdjs.Area1_463Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects1);
/* Reuse gdjs.Area1_463Code.GDPaimonObjects1 */
/* Reuse gdjs.Area1_463Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Area1_463Code.GDGungnirObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDGungnirObjects1[i].setZOrder((( gdjs.Area1_463Code.GDPaimonObjects1.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects1[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects1[i].setZOrder((( gdjs.Area1_463Code.GDPaimonObjects1.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects1[0].getZOrder()) - 1);
}
}}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_463Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_463Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDCollision_95959595MaskObjects3Objects = Hashtable.newFrom({"Collision_Mask": gdjs.Area1_463Code.GDCollision_9595MaskObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDBoss_95959595nameObjects3Objects = Hashtable.newFrom({"Boss_name": gdjs.Area1_463Code.GDBoss_9595nameObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDHealth_95959595boss_95959595barObjects3Objects = Hashtable.newFrom({"Health_boss_bar": gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDHealth_95959595bar_95959595boss_95959595emptyObjects3Objects = Hashtable.newFrom({"Health_bar_boss_empty": gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDHealth_95959595bar_95959595boss_95959595defenseObjects3Objects = Hashtable.newFrom({"Health_bar_boss_defense": gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3});
gdjs.Area1_463Code.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Screen"), gdjs.Area1_463Code.GDScreenObjects3);
gdjs.Area1_463Code.GDBoss_9595nameObjects3.length = 0;

gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3.length = 0;

gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3.length = 0;

gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDBoss_95959595nameObjects3Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDHealth_95959595boss_95959595barObjects3Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDHealth_95959595bar_95959595boss_95959595emptyObjects3Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDHealth_95959595bar_95959595boss_95959595defenseObjects3Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3[i].getBehavior("Resizable").setSize(600, 25);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3[i].getBehavior("Resizable").setSize(600, 25);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3[i].getBehavior("Resizable").setSize(600, 25);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3[i].setZOrder((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getZOrder()) + 2);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3[i].setZOrder((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3[i].setZOrder((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getZOrder()) + 3);
}
}}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDBarrierObjects4Objects = Hashtable.newFrom({"Barrier": gdjs.Area1_463Code.GDBarrierObjects4});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects4});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDBarrierObjects4Objects = Hashtable.newFrom({"Barrier": gdjs.Area1_463Code.GDBarrierObjects4});
gdjs.Area1_463Code.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Area1_463Code.GDBarrierObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDBarrierObjects4Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDBarrierObjects4 */
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].separateFromObjectsList(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDBarrierObjects4Objects, false);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDBarrierObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDBarrierObjects4[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPotionObjects3Objects = Hashtable.newFrom({"Potion": gdjs.Area1_463Code.GDPotionObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects4});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects4Objects = Hashtable.newFrom({"Slime": gdjs.Area1_463Code.GDSlimeObjects4});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects4Objects = Hashtable.newFrom({"Slime": gdjs.Area1_463Code.GDSlimeObjects4});
gdjs.Area1_463Code.asyncCallback11273412 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects5[i].getBehavior("ShakeObject_PositionAngleScale").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Area1_463Code.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_463Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback11273412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects4, gdjs.Area1_463Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.Area1_463Code.GDSlimeObjects4, gdjs.Area1_463Code.GDSlimeObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects5[0].getPointY("Center")) - (( gdjs.Area1_463Code.GDSlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_463Code.GDSlimeObjects5[0].getPointY("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects5 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects5[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects5[i].getPointX("Center")), (gdjs.Area1_463Code.GDPlayerObjects5[i].getPointY("Center")) - 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects4, gdjs.Area1_463Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.Area1_463Code.GDSlimeObjects4, gdjs.Area1_463Code.GDSlimeObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects5[0].getPointY("Center")) - (( gdjs.Area1_463Code.GDSlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_463Code.GDSlimeObjects5[0].getPointY("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects5 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects5[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects5[i].getPointX("Center")), (gdjs.Area1_463Code.GDPlayerObjects5[i].getPointY("Center")) + 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects4, gdjs.Area1_463Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.Area1_463Code.GDSlimeObjects4, gdjs.Area1_463Code.GDSlimeObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects5[0].getPointX("Center")) - (( gdjs.Area1_463Code.GDSlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_463Code.GDSlimeObjects5[0].getPointX("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects5 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects5[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects5[i].getPointX("Center")) + 2000, (gdjs.Area1_463Code.GDPlayerObjects5[i].getPointY("Center")), 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects4, gdjs.Area1_463Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.Area1_463Code.GDSlimeObjects4, gdjs.Area1_463Code.GDSlimeObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects5[0].getPointX("Center")) - (( gdjs.Area1_463Code.GDSlimeObjects5.length === 0 ) ? 0 :gdjs.Area1_463Code.GDSlimeObjects5[0].getPointX("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects5 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects5[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects5[i].getPointX("Center")) - 2000, (gdjs.Area1_463Code.GDPlayerObjects5[i].getPointY("Center")), 1000, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(1, 5, 5, 0, 5, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects4});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects4Objects = Hashtable.newFrom({"Slime": gdjs.Area1_463Code.GDSlimeObjects4});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects3Objects = Hashtable.newFrom({"Slime": gdjs.Area1_463Code.GDSlimeObjects3});
gdjs.Area1_463Code.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects4);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_463Code.GDSlimeObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects4Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
/* Reuse gdjs.Area1_463Code.GDSlimeObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].separateFromObjectsList(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects4Objects, false);
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects4);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_463Code.GDSlimeObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects4Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects4.length;i<l;++i) {
    if ( !(gdjs.Area1_463Code.GDPlayerObjects4[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects4[k] = gdjs.Area1_463Code.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_463Code.GDHealthBarObjects4);
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
/* Reuse gdjs.Area1_463Code.GDSlimeObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].getBehavior("Health").Hit(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber() - runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber(), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealthBarObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealthBarObjects4[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_463Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects4[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_463Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects4[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_463Code.GDSlimeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects3[k] = gdjs.Area1_463Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
/* Reuse gdjs.Area1_463Code.GDSlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("Health").Hit(0, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects3Objects = Hashtable.newFrom({"Paimon": gdjs.Area1_463Code.GDPaimonObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects3Objects = Hashtable.newFrom({"Paimon": gdjs.Area1_463Code.GDPaimonObjects3});
gdjs.Area1_463Code.asyncCallback11324172 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].getBehavior("ShakeObject_PositionAngleScale").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Area1_463Code.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_463Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback11324172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Area1_463Code.GDPaimonObjects3, gdjs.Area1_463Code.GDPaimonObjects4);

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects3, gdjs.Area1_463Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects4[0].getPointY("Center")) - (( gdjs.Area1_463Code.GDPaimonObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects4[0].getPointY("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects4[i].getPointX("Center")), (gdjs.Area1_463Code.GDPlayerObjects4[i].getPointY("Center")) - 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_463Code.GDPaimonObjects3, gdjs.Area1_463Code.GDPaimonObjects4);

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects3, gdjs.Area1_463Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects4[0].getPointY("Center")) - (( gdjs.Area1_463Code.GDPaimonObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects4[0].getPointY("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects4[i].getPointX("Center")), (gdjs.Area1_463Code.GDPlayerObjects4[i].getPointY("Center")) + 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_463Code.GDPaimonObjects3, gdjs.Area1_463Code.GDPaimonObjects4);

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects3, gdjs.Area1_463Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects4[0].getPointX("Center")) - (( gdjs.Area1_463Code.GDPaimonObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects4[0].getPointX("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects4[i].getPointX("Center")) + 2000, (gdjs.Area1_463Code.GDPlayerObjects4[i].getPointY("Center")), 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_463Code.GDPaimonObjects3, gdjs.Area1_463Code.GDPaimonObjects4);

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects3, gdjs.Area1_463Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects4[0].getPointX("Center")) - (( gdjs.Area1_463Code.GDPaimonObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects4[0].getPointX("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects4[i].getPointX("Center")) - 2000, (gdjs.Area1_463Code.GDPlayerObjects4[i].getPointY("Center")), 1000, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(1, 5, 5, 0, 5, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPaimonObjects3 */
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].separateFromObjectsList(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects3Objects, false);
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList23(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDGungnirObjects3Objects = Hashtable.newFrom({"Gungnir": gdjs.Area1_463Code.GDGungnirObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDGungnirObjects3Objects = Hashtable.newFrom({"Gungnir": gdjs.Area1_463Code.GDGungnirObjects3});
gdjs.Area1_463Code.asyncCallback11387076 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].getBehavior("ShakeObject_PositionAngleScale").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Area1_463Code.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_463Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback11387076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Area1_463Code.GDGungnirObjects3, gdjs.Area1_463Code.GDGungnirObjects4);

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects3, gdjs.Area1_463Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects4[0].getPointY("Center")) - (( gdjs.Area1_463Code.GDGungnirObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDGungnirObjects4[0].getPointY("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects4[i].getPointX("Center")), (gdjs.Area1_463Code.GDPlayerObjects4[i].getPointY("Center")) - 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_463Code.GDGungnirObjects3, gdjs.Area1_463Code.GDGungnirObjects4);

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects3, gdjs.Area1_463Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects4[0].getPointY("Center")) - (( gdjs.Area1_463Code.GDGungnirObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDGungnirObjects4[0].getPointY("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects4[i].getPointX("Center")), (gdjs.Area1_463Code.GDPlayerObjects4[i].getPointY("Center")) + 2000, 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_463Code.GDGungnirObjects3, gdjs.Area1_463Code.GDGungnirObjects4);

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects3, gdjs.Area1_463Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects4[0].getPointX("Center")) - (( gdjs.Area1_463Code.GDGungnirObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDGungnirObjects4[0].getPointX("Center")) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects4[i].getPointX("Center")) + 2000, (gdjs.Area1_463Code.GDPlayerObjects4[i].getPointY("Center")), 1000, 0);
}
}}

}


{

gdjs.copyArray(gdjs.Area1_463Code.GDGungnirObjects3, gdjs.Area1_463Code.GDGungnirObjects4);

gdjs.copyArray(gdjs.Area1_463Code.GDPlayerObjects3, gdjs.Area1_463Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Area1_463Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects4[0].getPointX("Center")) - (( gdjs.Area1_463Code.GDGungnirObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDGungnirObjects4[0].getPointX("Center")) < 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects4[i].addForceTowardPosition((gdjs.Area1_463Code.GDPlayerObjects4[i].getPointX("Center")) - 2000, (gdjs.Area1_463Code.GDPlayerObjects4[i].getPointY("Center")), 1000, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(1, 5, 5, 0, 5, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDGungnirObjects3Objects = Hashtable.newFrom({"Gungnir": gdjs.Area1_463Code.GDGungnirObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDattackzoneObjects3Objects = Hashtable.newFrom({"attackzone": gdjs.Area1_463Code.GDattackzoneObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDGungnirObjects3Objects = Hashtable.newFrom({"Gungnir": gdjs.Area1_463Code.GDGungnirObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects2});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDGungnirObjects2Objects = Hashtable.newFrom({"Gungnir": gdjs.Area1_463Code.GDGungnirObjects2});
gdjs.Area1_463Code.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDGungnirObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(12)) == 1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDGungnirObjects3 */
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].separateFromObjectsList(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDGungnirObjects3Objects, false);
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects3);
gdjs.copyArray(runtimeScene.getObjects("attackzone"), gdjs.Area1_463Code.GDattackzoneObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDGungnirObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDattackzoneObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0, 0.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDGungnirObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects3[k] = gdjs.Area1_463Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_463Code.GDHealthBarObjects3);
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("Health").Hit(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() - runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber(), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealthBarObjects3[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 200);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects2Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDGungnirObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPlayerObjects2[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects2[k] = gdjs.Area1_463Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects2[i].getBehavior("Health").Hit(0, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_463Code.eventsList28 = function(runtimeScene) {

{


gdjs.Area1_463Code.eventsList21(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList24(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList27(runtimeScene);
}


};gdjs.Area1_463Code.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Area1_463Code.GDBarrierObjects3);
{for(var i = 0, len = gdjs.Area1_463Code.GDBarrierObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDBarrierObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_463Code.GDWall_9595HorizontalObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
/* Reuse gdjs.Area1_463Code.GDWall_9595HorizontalObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].separateFromObjectsList(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Collision_Mask"), gdjs.Area1_463Code.GDCollision_9595MaskObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDCollision_95959595MaskObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Area1_463Code.GDBarrierObjects3);
/* Reuse gdjs.Area1_463Code.GDCollision_9595MaskObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects3);
gdjs.copyArray(runtimeScene.getObjects("attackzone"), gdjs.Area1_463Code.GDattackzoneObjects3);
{for(var i = 0, len = gdjs.Area1_463Code.GDCollision_9595MaskObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDCollision_9595MaskObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDBarrierObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDBarrierObjects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gungnir");
}{for(var i = 0, len = gdjs.Area1_463Code.GDGungnirObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDGungnirObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDattackzoneObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDattackzoneObjects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(12).setNumber(1);
}
{ //Subevents
gdjs.Area1_463Code.eventsList17(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(10)) == 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Area1_463Code.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion"), gdjs.Area1_463Code.GDPotionObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPotionObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPotionObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_463Code.GDPotion_9595numberObjects3);
{for(var i = 0, len = gdjs.Area1_463Code.GDPotionObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPotionObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(16).add(1);
}{for(var i = 0, len = gdjs.Area1_463Code.GDPotion_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPotion_9595numberObjects3[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16))) + "x");
}
}}

}


{


gdjs.Area1_463Code.eventsList28(runtimeScene);
}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects3Objects = Hashtable.newFrom({"Slash": gdjs.Area1_463Code.GDSlashObjects3});
gdjs.Area1_463Code.asyncCallback11223220 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Slash"), gdjs.Area1_463Code.GDSlashObjects4);

{for(var i = 0, len = gdjs.Area1_463Code.GDSlashObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlashObjects4[i].deleteFromScene(runtimeScene);
}
}}
gdjs.Area1_463Code.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_463Code.GDSlashObjects3) asyncObjectsList.addObject("Slash", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback11223220(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);
gdjs.Area1_463Code.GDSlashObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects3Objects, (( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointX("slash")), (( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointY("slash")), "");
}{for(var i = 0, len = gdjs.Area1_463Code.GDSlashObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlashObjects3[i].getBehavior("Animation").setAnimationName("Slash");
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList30(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseInsideCanvas(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_463Code.GDSlashObjects2);
{for(var i = 0, len = gdjs.Area1_463Code.GDSlashObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlashObjects2[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


};gdjs.Area1_463Code.eventsList32 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Boss_name"), gdjs.Area1_463Code.GDBoss_9595nameObjects3);
gdjs.copyArray(runtimeScene.getObjects("HP"), gdjs.Area1_463Code.GDHPObjects3);
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_463Code.GDHealthBarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Health_bar_boss_defense"), gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Health_bar_boss_empty"), gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Health_boss_bar"), gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3);
gdjs.copyArray(runtimeScene.getObjects("Healthempty"), gdjs.Area1_463Code.GDHealthemptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_463Code.GDKillcountObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_number"), gdjs.Area1_463Code.GDLevel_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Area1_463Code.GDMenuObjects3);
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_463Code.GDPotion_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_463Code.GDPotion_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Screen"), gdjs.Area1_463Code.GDScreenObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_463Code.GDSlashObjects3);
gdjs.copyArray(runtimeScene.getObjects("Status_box"), gdjs.Area1_463Code.GDStatus_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_463Code.GDTImerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Area1_463Code.GDTargetObjects3);
gdjs.copyArray(runtimeScene.getObjects("playername"), gdjs.Area1_463Code.GDplayernameObjects3);
{for(var i = 0, len = gdjs.Area1_463Code.GDScreenObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDScreenObjects3[i].setPosition((( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointX("screen")),(( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointY("screen")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDMenuObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("Menu")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("Menu")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDStatus_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDStatus_9595boxObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("box_status")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("box_status")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHPObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHPObjects3[i].setPosition((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointX("HP_name")),(( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointY("HP_name")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealthBarObjects3[i].setPosition((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealthemptyObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealthemptyObjects3[i].setPosition((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("bosshp")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("bosshp")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("bosshp")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("bosshp")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("bosshp")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("bosshp")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDBoss_9595nameObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDBoss_9595nameObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("bossname")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("bossname")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDLevel_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDLevel_9595numberObjects3[i].setPosition((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointX("LVL_name")),(( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointY("LVL_name")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDplayernameObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDplayernameObjects3[i].setPosition((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointX("player_name")),(( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointY("player_name")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPotion_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPotion_9595boxObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("potion")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("potion")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPotion_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPotion_9595numberObjects3[i].setPosition((( gdjs.Area1_463Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPotion_9595boxObjects3[0].getPointX("number")),(( gdjs.Area1_463Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPotion_9595boxObjects3[0].getPointY("number")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDSlashObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlashObjects3[i].setPosition((( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointX("slash")),(( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointY("slash")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDTargetObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTargetObjects3[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDKillcountObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDKillcountObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("kcount")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("kcount")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDTImerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTImerObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("time")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("time")));
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointX("screen")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointY("screen")), "", 0);
}}

}


};gdjs.Area1_463Code.eventsList33 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Boss_name"), gdjs.Area1_463Code.GDBoss_9595nameObjects3);
gdjs.copyArray(runtimeScene.getObjects("HP"), gdjs.Area1_463Code.GDHPObjects3);
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Area1_463Code.GDHealthBarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Health_bar_boss_defense"), gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Health_bar_boss_empty"), gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Health_boss_bar"), gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3);
gdjs.copyArray(runtimeScene.getObjects("Healthempty"), gdjs.Area1_463Code.GDHealthemptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_463Code.GDKillcountObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_number"), gdjs.Area1_463Code.GDLevel_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Area1_463Code.GDMenuObjects3);
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Potion_box"), gdjs.Area1_463Code.GDPotion_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("Potion_number"), gdjs.Area1_463Code.GDPotion_9595numberObjects3);
gdjs.copyArray(runtimeScene.getObjects("Screen"), gdjs.Area1_463Code.GDScreenObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_463Code.GDSlashObjects3);
gdjs.copyArray(runtimeScene.getObjects("Status_box"), gdjs.Area1_463Code.GDStatus_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_463Code.GDTImerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Area1_463Code.GDTargetObjects3);
gdjs.copyArray(runtimeScene.getObjects("playername"), gdjs.Area1_463Code.GDplayernameObjects3);
{for(var i = 0, len = gdjs.Area1_463Code.GDScreenObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDScreenObjects3[i].setPosition((( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointX("screen")),(( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointY("screen")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDMenuObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("Menu")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("Menu")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDStatus_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDStatus_9595boxObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("box_status")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("box_status")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHPObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHPObjects3[i].setPosition((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointX("HP_name")),(( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointY("HP_name")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealthBarObjects3[i].setPosition((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealthemptyObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealthemptyObjects3[i].setPosition((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointX("HP_bar")),(( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointY("HP_bar")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("bosshp")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("bosshp")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("bosshp")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("bosshp")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("bosshp")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("bosshp")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDBoss_9595nameObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDBoss_9595nameObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("bossname")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("bossname")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDLevel_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDLevel_9595numberObjects3[i].setPosition((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointX("LVL_name")),(( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointY("LVL_name")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDplayernameObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDplayernameObjects3[i].setPosition((( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointX("player_name")),(( gdjs.Area1_463Code.GDStatus_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDStatus_9595boxObjects3[0].getPointY("player_name")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPotion_9595boxObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPotion_9595boxObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("potion")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("potion")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPotion_9595numberObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPotion_9595numberObjects3[i].setPosition((( gdjs.Area1_463Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPotion_9595boxObjects3[0].getPointX("number")),(( gdjs.Area1_463Code.GDPotion_9595boxObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPotion_9595boxObjects3[0].getPointY("number")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDSlashObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlashObjects3[i].setPosition((( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointX("slash")),(( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointY("slash")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDTargetObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTargetObjects3[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDKillcountObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDKillcountObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("kcount")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("kcount")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDTImerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTImerObjects3[i].setPosition((( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointX("time")),(( gdjs.Area1_463Code.GDScreenObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDScreenObjects3[0].getPointY("time")));
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointX("screen")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointY("screen")), "", 0);
}}

}


};gdjs.Area1_463Code.eventsList34 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects3[k] = gdjs.Area1_463Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Shadow"), gdjs.Area1_463Code.GDShadowObjects3);
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("Animation").setAnimationName("walk");
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDShadowObjects3[i].getBehavior("Animation").setAnimationName("walk");
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDShadowObjects3[i].setPosition((( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointX("shadow")),(( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointY("shadow")));
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList32(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects3[k] = gdjs.Area1_463Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Shadow"), gdjs.Area1_463Code.GDShadowObjects3);
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("Animation").setAnimationName("idle");
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDShadowObjects3[i].getBehavior("Animation").setAnimationName("idle");
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDShadowObjects3[i].setPosition((( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointX("shadow")),(( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointY("shadow")));
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList33(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects3[k] = gdjs.Area1_463Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].addForce(100, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects3[k] = gdjs.Area1_463Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].addForce(-(100), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Up") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects3[k] = gdjs.Area1_463Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].addForce(0, -(100), 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Down") ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects3[k] = gdjs.Area1_463Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].addForce(0, 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) < (( gdjs.Area1_463Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects3[0].getPointX("center"));
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects3[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) > (( gdjs.Area1_463Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects2[0].getPointX("center"));
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.Area1_463Code.eventsList35 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Area1.3", false);
}}

}


};gdjs.Area1_463Code.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPlayerObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects2[k] = gdjs.Area1_463Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(16).setNumber(runtimeScene.getGame().getVariables().getFromIndex(22).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(runtimeScene.getGame().getVariables().getFromIndex(20).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(runtimeScene.getGame().getVariables().getFromIndex(21).getAsNumber());
}
{ //Subevents
gdjs.Area1_463Code.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.eventsList37 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects7);
{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects7.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects7[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(8).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPlayerObjects7.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPlayerObjects7[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(8).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_463Code.asyncCallback8755773 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(8)));
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9)));
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)));
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)));
}
{ //Subevents
gdjs.Area1_463Code.eventsList37(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList38 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/maxexp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(9), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8755773(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8754837 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList38(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList39 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/hp/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(8), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8754837(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8753709 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList39(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList40 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/spd/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(7), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8753709(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8752645 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList40(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList41 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/atk/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(5), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8752645(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8751581 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList41(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList42 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/player/def/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(6), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8751581(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.eventsList43 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects6);
{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects6.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects6[i].getBehavior("Health").SetMaxHealthOp(runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects6.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects6[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_463Code.asyncCallback8761941 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList43(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList44 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8761941(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8761605 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList44(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList45 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8761605(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8761229 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList45(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList46 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(2), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8761229(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8760893 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList46(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList47 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(1), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8760893(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback8760429 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList47(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList48 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8760429(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.eventsList49 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_463Code.eventsList42(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_463Code.eventsList48(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.eventsList50 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber() > 0);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Level_number"), gdjs.Area1_463Code.GDLevel_9595numberObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Area1_463Code.GDLevel_9595numberObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDLevel_9595numberObjects1[i].setBBText("LV. " + runtimeScene.getGame().getVariables().getFromIndex(3).getAsString());
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(0);
}
{ //Subevents
gdjs.Area1_463Code.eventsList49(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.eventsList51 = function(runtimeScene) {

{


gdjs.Area1_463Code.eventsList29(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList31(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList34(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList36(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList50(runtimeScene);
}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSpawnObjects3Objects = Hashtable.newFrom({"Spawn": gdjs.Area1_463Code.GDSpawnObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects3Objects = Hashtable.newFrom({"Slime": gdjs.Area1_463Code.GDSlimeObjects3});
gdjs.Area1_463Code.eventsList52 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Slime"), gdjs.Area1_463Code.GDSlimeObjects8);

{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects8.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects8[i].getBehavior("Health").SetHealth(runtimeScene.getScene().getVariables().getFromIndex(17).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Area1_463Code.asyncCallback11381252 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList52(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList53 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Slime as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/exp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(16), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback11381252(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback11380916 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList53(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList54 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Slime as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/hp/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(17), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback11380916(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback11380540 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList54(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList55 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Slime as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/spd/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(15), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback11380540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback11380180 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList55(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList56 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Slime as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/def/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(14), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback11380180(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.asyncCallback11379716 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList56(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList57 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_463Code.GDSlimeObjects3) asyncObjectsList.addObject("Slime", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("http://127.0.0.1:8000/enemy/atk/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), "/", "GET", "name", runtimeScene.getScene().getVariables().getFromIndex(13), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback11379716(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.eventsList58 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Area1_463Code.eventsList57(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects2Objects = Hashtable.newFrom({"Slime": gdjs.Area1_463Code.GDSlimeObjects2});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects2Objects = Hashtable.newFrom({"Paimon": gdjs.Area1_463Code.GDPaimonObjects2});
gdjs.Area1_463Code.eventsList59 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Spawn"), gdjs.Area1_463Code.GDSpawnObjects3);
{for(var i = 0, len = gdjs.Area1_463Code.GDSpawnObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSpawnObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Spawn"), gdjs.Area1_463Code.GDSpawnObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "slime") >= 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSpawnObjects3Objects);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDSpawnObjects3 */
gdjs.copyArray(runtimeScene.getObjects("TEXT"), gdjs.Area1_463Code.GDTEXTObjects3);
gdjs.Area1_463Code.GDSlimeObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects3Objects, (( gdjs.Area1_463Code.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDSpawnObjects3[0].getPointX("Origin")), (( gdjs.Area1_463Code.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDSpawnObjects3[0].getPointY("Origin")), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "slime");
}{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects3[i].getBehavior("Resizable").setSize(64, 83);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDTEXTObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTEXTObjects3[i].setBBText(runtimeScene.getScene().getVariables().getFromIndex(17).getAsString());
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList58(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.Area1_463Code.GDFloorObjects3);
gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_463Code.GDSlimeObjects3);
{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects3[i].addForceTowardObject((gdjs.Area1_463Code.GDPaimonObjects3.length !== 0 ? gdjs.Area1_463Code.GDPaimonObjects3[0] : null), runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber(), 0);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects3[i].getBehavior("Animation").setAnimationName("Walk");
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects3[i].setZOrder((( gdjs.Area1_463Code.GDFloorObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDFloorObjects3[0].getZOrder()) + 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_463Code.GDSlimeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects2Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Health_boss_bar"), gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects2);
/* Reuse gdjs.Area1_463Code.GDPaimonObjects2 */
/* Reuse gdjs.Area1_463Code.GDSlimeObjects2 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects2[i].getBehavior("Health").Heal(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects2[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_463Code.GDPaimonObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_463Code.GDPaimonObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 600);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects3Objects = Hashtable.newFrom({"Slime": gdjs.Area1_463Code.GDSlimeObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_463Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_463Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects3Objects = Hashtable.newFrom({"Slash": gdjs.Area1_463Code.GDSlashObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects3Objects = Hashtable.newFrom({"Slime": gdjs.Area1_463Code.GDSlimeObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects3Objects = Hashtable.newFrom({"Slash": gdjs.Area1_463Code.GDSlashObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects3Objects = Hashtable.newFrom({"Slime": gdjs.Area1_463Code.GDSlimeObjects3});
gdjs.Area1_463Code.eventsList60 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_463Code.GDSlimeObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_463Code.GDWall_9595HorizontalObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDSlimeObjects3 */
/* Reuse gdjs.Area1_463Code.GDWall_9595HorizontalObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects3[i].separateFromObjectsList(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_463Code.GDSlashObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_463Code.GDSlimeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDSlimeObjects3.length;i<l;++i) {
    if ( !(gdjs.Area1_463Code.GDSlimeObjects3[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDSlimeObjects3[k] = gdjs.Area1_463Code.GDSlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDSlimeObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDSlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects3[i].getBehavior("Animation").setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects3[i].getBehavior("Health").Hit(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() - runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber(), false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_463Code.GDSlashObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_463Code.GDSlimeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlimeObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDSlimeObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDSlimeObjects3[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDSlimeObjects3[k] = gdjs.Area1_463Code.GDSlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDSlimeObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDSlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects3[i].getBehavior("Health").Hit(0, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_463Code.GDSlimeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDSlimeObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDSlimeObjects3[i].getBehavior("Animation").getAnimationName() == "Hurt" ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDSlimeObjects3[k] = gdjs.Area1_463Code.GDSlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDSlimeObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDSlimeObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDSlimeObjects3[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDSlimeObjects3[k] = gdjs.Area1_463Code.GDSlimeObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDSlimeObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDSlimeObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects3[i].getBehavior("Animation").setAnimationName("Walk");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slime"), gdjs.Area1_463Code.GDSlimeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDSlimeObjects2.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDSlimeObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDSlimeObjects2[k] = gdjs.Area1_463Code.GDSlimeObjects2[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDSlimeObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_463Code.GDKillcountObjects2);
/* Reuse gdjs.Area1_463Code.GDSlimeObjects2 */
{for(var i = 0, len = gdjs.Area1_463Code.GDSlimeObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDSlimeObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDKillcountObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDKillcountObjects2[i].setBBText("Kill : " + runtimeScene.getGame().getVariables().getFromIndex(23).getAsString());
}
}{runtimeScene.getGame().getVariables().getFromIndex(23).add(1);
}}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects3Objects = Hashtable.newFrom({"Paimon": gdjs.Area1_463Code.GDPaimonObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_463Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects = Hashtable.newFrom({"Wall_Horizontal": gdjs.Area1_463Code.GDWall_9595HorizontalObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects3Objects = Hashtable.newFrom({"Slash": gdjs.Area1_463Code.GDSlashObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects3Objects = Hashtable.newFrom({"Paimon": gdjs.Area1_463Code.GDPaimonObjects3});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects4Objects = Hashtable.newFrom({"Slash": gdjs.Area1_463Code.GDSlashObjects4});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects4Objects = Hashtable.newFrom({"Paimon": gdjs.Area1_463Code.GDPaimonObjects4});
gdjs.Area1_463Code.eventsList61 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_463Code.GDSlashObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects4Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPaimonObjects4.length;i<l;++i) {
    if ( !(gdjs.Area1_463Code.GDPaimonObjects4[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPaimonObjects4[k] = gdjs.Area1_463Code.GDPaimonObjects4[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPaimonObjects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Health_bar_boss_defense"), gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects4);
/* Reuse gdjs.Area1_463Code.GDPaimonObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects4[i].getBehavior("Health").Hit(50, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects4[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_463Code.GDPaimonObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects4[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_463Code.GDPaimonObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects4[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 600);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPaimonObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPaimonObjects3[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPaimonObjects3[k] = gdjs.Area1_463Code.GDPaimonObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPaimonObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Health_bar_boss_defense"), gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3);
/* Reuse gdjs.Area1_463Code.GDPaimonObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects3[i].getBehavior("Health").Heal(runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(11).setNumber(1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 2, 2, 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "slime");
}}

}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects4Objects = Hashtable.newFrom({"Slash": gdjs.Area1_463Code.GDSlashObjects4});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects4Objects = Hashtable.newFrom({"Paimon": gdjs.Area1_463Code.GDPaimonObjects4});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDStaircaseObjects3Objects = Hashtable.newFrom({"Staircase": gdjs.Area1_463Code.GDStaircaseObjects3});
gdjs.Area1_463Code.eventsList62 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_463Code.GDSlashObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects4Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPaimonObjects4.length;i<l;++i) {
    if ( !(gdjs.Area1_463Code.GDPaimonObjects4[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPaimonObjects4[k] = gdjs.Area1_463Code.GDPaimonObjects4[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPaimonObjects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Health_boss_bar"), gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects4);
/* Reuse gdjs.Area1_463Code.GDPaimonObjects4 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects4[i].getBehavior("Health").Hit(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() - runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber(), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects4.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects4[i].getBehavior("Resizable").setWidth(((( gdjs.Area1_463Code.GDPaimonObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects4[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Area1_463Code.GDPaimonObjects4.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPaimonObjects4[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 600);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPaimonObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPaimonObjects3[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPaimonObjects3[k] = gdjs.Area1_463Code.GDPaimonObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPaimonObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Area1_463Code.GDBarrierObjects3);
gdjs.copyArray(runtimeScene.getObjects("Boss_name"), gdjs.Area1_463Code.GDBoss_9595nameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.Area1_463Code.GDFloorObjects3);
gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects3);
gdjs.copyArray(runtimeScene.getObjects("Health_bar_boss_empty"), gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Health_boss_bar"), gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3);
gdjs.copyArray(runtimeScene.getObjects("Killcount"), gdjs.Area1_463Code.GDKillcountObjects3);
/* Reuse gdjs.Area1_463Code.GDPaimonObjects3 */
gdjs.copyArray(runtimeScene.getObjects("attackzone"), gdjs.Area1_463Code.GDattackzoneObjects3);
gdjs.Area1_463Code.GDStaircaseObjects3.length = 0;

{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "gungnir");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "slime");
}{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDBoss_9595nameObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDBoss_9595nameObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDGungnirObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDGungnirObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDattackzoneObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDattackzoneObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDBarrierObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDBarrierObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).add(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDStaircaseObjects3Objects, 544, 416, "");
}{for(var i = 0, len = gdjs.Area1_463Code.GDStaircaseObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDStaircaseObjects3[i].setZOrder((( gdjs.Area1_463Code.GDFloorObjects3.length === 0 ) ? 0 :gdjs.Area1_463Code.GDFloorObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDKillcountObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDKillcountObjects3[i].setBBText("Kill : " + runtimeScene.getGame().getVariables().getFromIndex(23).getAsString());
}
}{runtimeScene.getGame().getVariables().getFromIndex(23).add(1);
}}

}


};gdjs.Area1_463Code.eventsList63 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall_Horizontal"), gdjs.Area1_463Code.GDWall_9595HorizontalObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPaimonObjects3 */
/* Reuse gdjs.Area1_463Code.GDWall_9595HorizontalObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects3[i].separateFromObjectsList(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDWall_95959595HorizontalObjects3Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Slash"), gdjs.Area1_463Code.GDSlashObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDSlashObjects3Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPaimonObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPaimonObjects3.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPaimonObjects3[i].getBehavior("Health").IsDamageCooldownActive((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPaimonObjects3[k] = gdjs.Area1_463Code.GDPaimonObjects3[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPaimonObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPaimonObjects3 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects3[i].getBehavior("Health").Hit(0, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(11)) == 0;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Area1_463Code.eventsList61(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(11)) == 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Area1_463Code.eventsList62(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Paimon"), gdjs.Area1_463Code.GDPaimonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPaimonObjects2.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPaimonObjects2[i].getBehavior("Animation").getAnimationName() == "idle" ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPaimonObjects2[k] = gdjs.Area1_463Code.GDPaimonObjects2[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPaimonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPaimonObjects2.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPaimonObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPaimonObjects2[k] = gdjs.Area1_463Code.GDPaimonObjects2[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPaimonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDPaimonObjects2 */
{for(var i = 0, len = gdjs.Area1_463Code.GDPaimonObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPaimonObjects2[i].getBehavior("Animation").setAnimationName("Walk");
}
}}

}


};gdjs.Area1_463Code.asyncCallback8633308 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects3);

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gungnir");
}{for(var i = 0, len = gdjs.Area1_463Code.GDGungnirObjects3.length ;i < len;++i) {
    gdjs.Area1_463Code.GDGungnirObjects3[i].getBehavior("Animation").setAnimationName("idle");
}
}}
gdjs.Area1_463Code.eventsList64 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Area1_463Code.GDGungnirObjects2) asyncObjectsList.addObject("Gungnir", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8633308(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.eventsList65 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("attackzone"), gdjs.Area1_463Code.GDattackzoneObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gungnir");
}{for(var i = 0, len = gdjs.Area1_463Code.GDGungnirObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDGungnirObjects2[i].getBehavior("Animation").setAnimationName("idle");
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDattackzoneObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDattackzoneObjects2[i].setZOrder((( gdjs.Area1_463Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects2[0].getZOrder()) - 4);
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDGungnirObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDGungnirObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDattackzoneObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDattackzoneObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "gungnir") >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects2);
{for(var i = 0, len = gdjs.Area1_463Code.GDGungnirObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDGungnirObjects2[i].getBehavior("Animation").setAnimationName("attack");
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList64(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects2[k] = gdjs.Area1_463Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDGungnirObjects2.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDGungnirObjects2[i].getBehavior("Animation").getAnimationName() == "idle" ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDGungnirObjects2[k] = gdjs.Area1_463Code.GDGungnirObjects2[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDGungnirObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDGungnirObjects2 */
/* Reuse gdjs.Area1_463Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("attackzone"), gdjs.Area1_463Code.GDattackzoneObjects2);
{for(var i = 0, len = gdjs.Area1_463Code.GDGungnirObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDGungnirObjects2[i].setPosition((( gdjs.Area1_463Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects2[0].getPointX("shadow")),(( gdjs.Area1_463Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects2[0].getPointY("shadow")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDattackzoneObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDattackzoneObjects2[i].setPosition((( gdjs.Area1_463Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects2[0].getPointX("shadow")),(( gdjs.Area1_463Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects2[0].getPointY("shadow")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gungnir"), gdjs.Area1_463Code.GDGungnirObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Area1_463Code.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDPlayerObjects1[k] = gdjs.Area1_463Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Area1_463Code.GDGungnirObjects1.length;i<l;++i) {
    if ( gdjs.Area1_463Code.GDGungnirObjects1[i].getBehavior("Animation").getAnimationName() == "idle" ) {
        isConditionTrue_0 = true;
        gdjs.Area1_463Code.GDGungnirObjects1[k] = gdjs.Area1_463Code.GDGungnirObjects1[i];
        ++k;
    }
}
gdjs.Area1_463Code.GDGungnirObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDGungnirObjects1 */
/* Reuse gdjs.Area1_463Code.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("attackzone"), gdjs.Area1_463Code.GDattackzoneObjects1);
{for(var i = 0, len = gdjs.Area1_463Code.GDGungnirObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDGungnirObjects1[i].setPosition((( gdjs.Area1_463Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects1[0].getPointX("shadow")),(( gdjs.Area1_463Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects1[0].getPointY("shadow")));
}
}{for(var i = 0, len = gdjs.Area1_463Code.GDattackzoneObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDattackzoneObjects1[i].setPosition((( gdjs.Area1_463Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects1[0].getPointX("shadow")),(( gdjs.Area1_463Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Area1_463Code.GDPlayerObjects1[0].getPointY("shadow")));
}
}}

}


};gdjs.Area1_463Code.eventsList66 = function(runtimeScene) {

{


gdjs.Area1_463Code.eventsList59(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList60(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList63(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList65(runtimeScene);
}


};gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Area1_463Code.GDPlayerObjects1});
gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDStaircaseObjects1Objects = Hashtable.newFrom({"Staircase": gdjs.Area1_463Code.GDStaircaseObjects1});
gdjs.Area1_463Code.eventsList67 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ending", false);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber());
}}

}


};gdjs.Area1_463Code.asyncCallback8640716 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Area1_463Code.eventsList67(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Area1_463Code.eventsList68 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Area1_463Code.asyncCallback8640716(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Area1_463Code.eventsList69 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if (isConditionTrue_0) {
{gdjs.evtTools.network.sendAsyncRequest("http://127.0.0.1:8000/leaderboard/wingame/name=" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) + "&level=" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))) + "&killcount=" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(23))) + "&hour=" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + "&minute=" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + "&second=" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))), "", "POST", "", gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable);
}
{ //Subevents
gdjs.Area1_463Code.eventsList68(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.eventsList70 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Staircase"), gdjs.Area1_463Code.GDStaircaseObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPlayerObjects1Objects, gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDStaircaseObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TEXT"), gdjs.Area1_463Code.GDTEXTObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(19).setString(runtimeScene.getGame().getVariables().getFromIndex(2).getAsString());
}{for(var i = 0, len = gdjs.Area1_463Code.GDTEXTObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTEXTObjects1[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(2).getAsString());
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList69(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.eventsList71 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) >= 10;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDTImerObjects2 */
{for(var i = 0, len = gdjs.Area1_463Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTImerObjects2[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}}

}


};gdjs.Area1_463Code.eventsList72 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) >= 10;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDTImerObjects2 */
{for(var i = 0, len = gdjs.Area1_463Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList71(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.eventsList73 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) >= 10;
if (isConditionTrue_0) {
/* Reuse gdjs.Area1_463Code.GDTImerObjects2 */
{for(var i = 0, len = gdjs.Area1_463Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList72(runtimeScene);} //End of subevents
}

}


};gdjs.Area1_463Code.eventsList74 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_463Code.GDTImerObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timer");
}{for(var i = 0, len = gdjs.Area1_463Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "timer") >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TImer"), gdjs.Area1_463Code.GDTImerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(17).add(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timer");
}{for(var i = 0, len = gdjs.Area1_463Code.GDTImerObjects2.length ;i < len;++i) {
    gdjs.Area1_463Code.GDTImerObjects2[i].setBBText("0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + ":0" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList73(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) == 60;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(17).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(18).add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 60;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(19).add(1);
}}

}


};gdjs.Area1_463Code.eventsList75 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Area1_463Code.GDPlayerObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(1).setString("paimon");
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("slime");
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Area1_463Code.GDPlayerObjects1.length !== 0 ? gdjs.Area1_463Code.GDPlayerObjects1[0] : null), true, "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.2, "", 0);
}
{ //Subevents
gdjs.Area1_463Code.eventsList12(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(21).setNumber(runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(22).setNumber(runtimeScene.getGame().getVariables().getFromIndex(16).getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.Area1_463Code.GDHPObjects1.length = 0;

gdjs.Area1_463Code.GDHealthBarObjects1.length = 0;

gdjs.Area1_463Code.GDKillcountObjects1.length = 0;

gdjs.Area1_463Code.GDLevel_9595numberObjects1.length = 0;

gdjs.Area1_463Code.GDMenuObjects1.length = 0;

gdjs.Area1_463Code.GDPotion_9595boxObjects1.length = 0;

gdjs.Area1_463Code.GDPotion_9595numberObjects1.length = 0;

gdjs.Area1_463Code.GDScreenObjects1.length = 0;

gdjs.Area1_463Code.GDStatus_9595boxObjects1.length = 0;

gdjs.Area1_463Code.GDTImerObjects1.length = 0;

gdjs.Area1_463Code.GDTargetObjects1.length = 0;

gdjs.Area1_463Code.GDplayernameObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDScreenObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDMenuObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDStatus_95959595boxObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDHPObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDHealthBarObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDTargetObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDLevel_95959595numberObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDplayernameObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPotion_95959595boxObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDPotion_95959595numberObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDKillcountObjects1Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Area1_463Code.mapOfGDgdjs_9546Area1_9595463Code_9546GDTImerObjects1Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.Area1_463Code.GDPotion_9595numberObjects1.length ;i < len;++i) {
    gdjs.Area1_463Code.GDPotion_9595numberObjects1[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16))) + "x");
}
}
{ //Subevents
gdjs.Area1_463Code.eventsList13(runtimeScene);} //End of subevents
}

}


{


gdjs.Area1_463Code.eventsList14(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList16(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList51(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList66(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList70(runtimeScene);
}


{


gdjs.Area1_463Code.eventsList74(runtimeScene);
}


};

gdjs.Area1_463Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Area1_463Code.GDPaimonObjects1.length = 0;
gdjs.Area1_463Code.GDPaimonObjects2.length = 0;
gdjs.Area1_463Code.GDPaimonObjects3.length = 0;
gdjs.Area1_463Code.GDPaimonObjects4.length = 0;
gdjs.Area1_463Code.GDPaimonObjects5.length = 0;
gdjs.Area1_463Code.GDPaimonObjects6.length = 0;
gdjs.Area1_463Code.GDPaimonObjects7.length = 0;
gdjs.Area1_463Code.GDPaimonObjects8.length = 0;
gdjs.Area1_463Code.GDPaimonObjects9.length = 0;
gdjs.Area1_463Code.GDFloorObjects1.length = 0;
gdjs.Area1_463Code.GDFloorObjects2.length = 0;
gdjs.Area1_463Code.GDFloorObjects3.length = 0;
gdjs.Area1_463Code.GDFloorObjects4.length = 0;
gdjs.Area1_463Code.GDFloorObjects5.length = 0;
gdjs.Area1_463Code.GDFloorObjects6.length = 0;
gdjs.Area1_463Code.GDFloorObjects7.length = 0;
gdjs.Area1_463Code.GDFloorObjects8.length = 0;
gdjs.Area1_463Code.GDFloorObjects9.length = 0;
gdjs.Area1_463Code.GDWall_9595HorizontalObjects1.length = 0;
gdjs.Area1_463Code.GDWall_9595HorizontalObjects2.length = 0;
gdjs.Area1_463Code.GDWall_9595HorizontalObjects3.length = 0;
gdjs.Area1_463Code.GDWall_9595HorizontalObjects4.length = 0;
gdjs.Area1_463Code.GDWall_9595HorizontalObjects5.length = 0;
gdjs.Area1_463Code.GDWall_9595HorizontalObjects6.length = 0;
gdjs.Area1_463Code.GDWall_9595HorizontalObjects7.length = 0;
gdjs.Area1_463Code.GDWall_9595HorizontalObjects8.length = 0;
gdjs.Area1_463Code.GDWall_9595HorizontalObjects9.length = 0;
gdjs.Area1_463Code.GDWall_9595VerticalObjects1.length = 0;
gdjs.Area1_463Code.GDWall_9595VerticalObjects2.length = 0;
gdjs.Area1_463Code.GDWall_9595VerticalObjects3.length = 0;
gdjs.Area1_463Code.GDWall_9595VerticalObjects4.length = 0;
gdjs.Area1_463Code.GDWall_9595VerticalObjects5.length = 0;
gdjs.Area1_463Code.GDWall_9595VerticalObjects6.length = 0;
gdjs.Area1_463Code.GDWall_9595VerticalObjects7.length = 0;
gdjs.Area1_463Code.GDWall_9595VerticalObjects8.length = 0;
gdjs.Area1_463Code.GDWall_9595VerticalObjects9.length = 0;
gdjs.Area1_463Code.GDBarrierObjects1.length = 0;
gdjs.Area1_463Code.GDBarrierObjects2.length = 0;
gdjs.Area1_463Code.GDBarrierObjects3.length = 0;
gdjs.Area1_463Code.GDBarrierObjects4.length = 0;
gdjs.Area1_463Code.GDBarrierObjects5.length = 0;
gdjs.Area1_463Code.GDBarrierObjects6.length = 0;
gdjs.Area1_463Code.GDBarrierObjects7.length = 0;
gdjs.Area1_463Code.GDBarrierObjects8.length = 0;
gdjs.Area1_463Code.GDBarrierObjects9.length = 0;
gdjs.Area1_463Code.GDCollision_9595MaskObjects1.length = 0;
gdjs.Area1_463Code.GDCollision_9595MaskObjects2.length = 0;
gdjs.Area1_463Code.GDCollision_9595MaskObjects3.length = 0;
gdjs.Area1_463Code.GDCollision_9595MaskObjects4.length = 0;
gdjs.Area1_463Code.GDCollision_9595MaskObjects5.length = 0;
gdjs.Area1_463Code.GDCollision_9595MaskObjects6.length = 0;
gdjs.Area1_463Code.GDCollision_9595MaskObjects7.length = 0;
gdjs.Area1_463Code.GDCollision_9595MaskObjects8.length = 0;
gdjs.Area1_463Code.GDCollision_9595MaskObjects9.length = 0;
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects1.length = 0;
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects2.length = 0;
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects3.length = 0;
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects4.length = 0;
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects5.length = 0;
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects6.length = 0;
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects7.length = 0;
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects8.length = 0;
gdjs.Area1_463Code.GDHealth_9595boss_9595barObjects9.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects1.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects2.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects3.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects4.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects5.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects6.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects7.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects8.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595emptyObjects9.length = 0;
gdjs.Area1_463Code.GDBoss_9595nameObjects1.length = 0;
gdjs.Area1_463Code.GDBoss_9595nameObjects2.length = 0;
gdjs.Area1_463Code.GDBoss_9595nameObjects3.length = 0;
gdjs.Area1_463Code.GDBoss_9595nameObjects4.length = 0;
gdjs.Area1_463Code.GDBoss_9595nameObjects5.length = 0;
gdjs.Area1_463Code.GDBoss_9595nameObjects6.length = 0;
gdjs.Area1_463Code.GDBoss_9595nameObjects7.length = 0;
gdjs.Area1_463Code.GDBoss_9595nameObjects8.length = 0;
gdjs.Area1_463Code.GDBoss_9595nameObjects9.length = 0;
gdjs.Area1_463Code.GDGungnirObjects1.length = 0;
gdjs.Area1_463Code.GDGungnirObjects2.length = 0;
gdjs.Area1_463Code.GDGungnirObjects3.length = 0;
gdjs.Area1_463Code.GDGungnirObjects4.length = 0;
gdjs.Area1_463Code.GDGungnirObjects5.length = 0;
gdjs.Area1_463Code.GDGungnirObjects6.length = 0;
gdjs.Area1_463Code.GDGungnirObjects7.length = 0;
gdjs.Area1_463Code.GDGungnirObjects8.length = 0;
gdjs.Area1_463Code.GDGungnirObjects9.length = 0;
gdjs.Area1_463Code.GDattackzoneObjects1.length = 0;
gdjs.Area1_463Code.GDattackzoneObjects2.length = 0;
gdjs.Area1_463Code.GDattackzoneObjects3.length = 0;
gdjs.Area1_463Code.GDattackzoneObjects4.length = 0;
gdjs.Area1_463Code.GDattackzoneObjects5.length = 0;
gdjs.Area1_463Code.GDattackzoneObjects6.length = 0;
gdjs.Area1_463Code.GDattackzoneObjects7.length = 0;
gdjs.Area1_463Code.GDattackzoneObjects8.length = 0;
gdjs.Area1_463Code.GDattackzoneObjects9.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects1.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects2.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects3.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects4.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects5.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects6.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects7.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects8.length = 0;
gdjs.Area1_463Code.GDHealth_9595bar_9595boss_9595defenseObjects9.length = 0;
gdjs.Area1_463Code.GDSpawnObjects1.length = 0;
gdjs.Area1_463Code.GDSpawnObjects2.length = 0;
gdjs.Area1_463Code.GDSpawnObjects3.length = 0;
gdjs.Area1_463Code.GDSpawnObjects4.length = 0;
gdjs.Area1_463Code.GDSpawnObjects5.length = 0;
gdjs.Area1_463Code.GDSpawnObjects6.length = 0;
gdjs.Area1_463Code.GDSpawnObjects7.length = 0;
gdjs.Area1_463Code.GDSpawnObjects8.length = 0;
gdjs.Area1_463Code.GDSpawnObjects9.length = 0;
gdjs.Area1_463Code.GDSlimeObjects1.length = 0;
gdjs.Area1_463Code.GDSlimeObjects2.length = 0;
gdjs.Area1_463Code.GDSlimeObjects3.length = 0;
gdjs.Area1_463Code.GDSlimeObjects4.length = 0;
gdjs.Area1_463Code.GDSlimeObjects5.length = 0;
gdjs.Area1_463Code.GDSlimeObjects6.length = 0;
gdjs.Area1_463Code.GDSlimeObjects7.length = 0;
gdjs.Area1_463Code.GDSlimeObjects8.length = 0;
gdjs.Area1_463Code.GDSlimeObjects9.length = 0;
gdjs.Area1_463Code.GDTEXTObjects1.length = 0;
gdjs.Area1_463Code.GDTEXTObjects2.length = 0;
gdjs.Area1_463Code.GDTEXTObjects3.length = 0;
gdjs.Area1_463Code.GDTEXTObjects4.length = 0;
gdjs.Area1_463Code.GDTEXTObjects5.length = 0;
gdjs.Area1_463Code.GDTEXTObjects6.length = 0;
gdjs.Area1_463Code.GDTEXTObjects7.length = 0;
gdjs.Area1_463Code.GDTEXTObjects8.length = 0;
gdjs.Area1_463Code.GDTEXTObjects9.length = 0;
gdjs.Area1_463Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Area1_463Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Area1_463Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.Area1_463Code.GDNewTiledSpriteObjects4.length = 0;
gdjs.Area1_463Code.GDNewTiledSpriteObjects5.length = 0;
gdjs.Area1_463Code.GDNewTiledSpriteObjects6.length = 0;
gdjs.Area1_463Code.GDNewTiledSpriteObjects7.length = 0;
gdjs.Area1_463Code.GDNewTiledSpriteObjects8.length = 0;
gdjs.Area1_463Code.GDNewTiledSpriteObjects9.length = 0;
gdjs.Area1_463Code.GDStaircaseObjects1.length = 0;
gdjs.Area1_463Code.GDStaircaseObjects2.length = 0;
gdjs.Area1_463Code.GDStaircaseObjects3.length = 0;
gdjs.Area1_463Code.GDStaircaseObjects4.length = 0;
gdjs.Area1_463Code.GDStaircaseObjects5.length = 0;
gdjs.Area1_463Code.GDStaircaseObjects6.length = 0;
gdjs.Area1_463Code.GDStaircaseObjects7.length = 0;
gdjs.Area1_463Code.GDStaircaseObjects8.length = 0;
gdjs.Area1_463Code.GDStaircaseObjects9.length = 0;
gdjs.Area1_463Code.GDPlayerObjects1.length = 0;
gdjs.Area1_463Code.GDPlayerObjects2.length = 0;
gdjs.Area1_463Code.GDPlayerObjects3.length = 0;
gdjs.Area1_463Code.GDPlayerObjects4.length = 0;
gdjs.Area1_463Code.GDPlayerObjects5.length = 0;
gdjs.Area1_463Code.GDPlayerObjects6.length = 0;
gdjs.Area1_463Code.GDPlayerObjects7.length = 0;
gdjs.Area1_463Code.GDPlayerObjects8.length = 0;
gdjs.Area1_463Code.GDPlayerObjects9.length = 0;
gdjs.Area1_463Code.GDSlashObjects1.length = 0;
gdjs.Area1_463Code.GDSlashObjects2.length = 0;
gdjs.Area1_463Code.GDSlashObjects3.length = 0;
gdjs.Area1_463Code.GDSlashObjects4.length = 0;
gdjs.Area1_463Code.GDSlashObjects5.length = 0;
gdjs.Area1_463Code.GDSlashObjects6.length = 0;
gdjs.Area1_463Code.GDSlashObjects7.length = 0;
gdjs.Area1_463Code.GDSlashObjects8.length = 0;
gdjs.Area1_463Code.GDSlashObjects9.length = 0;
gdjs.Area1_463Code.GDShadowObjects1.length = 0;
gdjs.Area1_463Code.GDShadowObjects2.length = 0;
gdjs.Area1_463Code.GDShadowObjects3.length = 0;
gdjs.Area1_463Code.GDShadowObjects4.length = 0;
gdjs.Area1_463Code.GDShadowObjects5.length = 0;
gdjs.Area1_463Code.GDShadowObjects6.length = 0;
gdjs.Area1_463Code.GDShadowObjects7.length = 0;
gdjs.Area1_463Code.GDShadowObjects8.length = 0;
gdjs.Area1_463Code.GDShadowObjects9.length = 0;
gdjs.Area1_463Code.GDStatus_9595boxObjects1.length = 0;
gdjs.Area1_463Code.GDStatus_9595boxObjects2.length = 0;
gdjs.Area1_463Code.GDStatus_9595boxObjects3.length = 0;
gdjs.Area1_463Code.GDStatus_9595boxObjects4.length = 0;
gdjs.Area1_463Code.GDStatus_9595boxObjects5.length = 0;
gdjs.Area1_463Code.GDStatus_9595boxObjects6.length = 0;
gdjs.Area1_463Code.GDStatus_9595boxObjects7.length = 0;
gdjs.Area1_463Code.GDStatus_9595boxObjects8.length = 0;
gdjs.Area1_463Code.GDStatus_9595boxObjects9.length = 0;
gdjs.Area1_463Code.GDHealthBarObjects1.length = 0;
gdjs.Area1_463Code.GDHealthBarObjects2.length = 0;
gdjs.Area1_463Code.GDHealthBarObjects3.length = 0;
gdjs.Area1_463Code.GDHealthBarObjects4.length = 0;
gdjs.Area1_463Code.GDHealthBarObjects5.length = 0;
gdjs.Area1_463Code.GDHealthBarObjects6.length = 0;
gdjs.Area1_463Code.GDHealthBarObjects7.length = 0;
gdjs.Area1_463Code.GDHealthBarObjects8.length = 0;
gdjs.Area1_463Code.GDHealthBarObjects9.length = 0;
gdjs.Area1_463Code.GDTargetObjects1.length = 0;
gdjs.Area1_463Code.GDTargetObjects2.length = 0;
gdjs.Area1_463Code.GDTargetObjects3.length = 0;
gdjs.Area1_463Code.GDTargetObjects4.length = 0;
gdjs.Area1_463Code.GDTargetObjects5.length = 0;
gdjs.Area1_463Code.GDTargetObjects6.length = 0;
gdjs.Area1_463Code.GDTargetObjects7.length = 0;
gdjs.Area1_463Code.GDTargetObjects8.length = 0;
gdjs.Area1_463Code.GDTargetObjects9.length = 0;
gdjs.Area1_463Code.GDHPObjects1.length = 0;
gdjs.Area1_463Code.GDHPObjects2.length = 0;
gdjs.Area1_463Code.GDHPObjects3.length = 0;
gdjs.Area1_463Code.GDHPObjects4.length = 0;
gdjs.Area1_463Code.GDHPObjects5.length = 0;
gdjs.Area1_463Code.GDHPObjects6.length = 0;
gdjs.Area1_463Code.GDHPObjects7.length = 0;
gdjs.Area1_463Code.GDHPObjects8.length = 0;
gdjs.Area1_463Code.GDHPObjects9.length = 0;
gdjs.Area1_463Code.GDLevel_9595numberObjects1.length = 0;
gdjs.Area1_463Code.GDLevel_9595numberObjects2.length = 0;
gdjs.Area1_463Code.GDLevel_9595numberObjects3.length = 0;
gdjs.Area1_463Code.GDLevel_9595numberObjects4.length = 0;
gdjs.Area1_463Code.GDLevel_9595numberObjects5.length = 0;
gdjs.Area1_463Code.GDLevel_9595numberObjects6.length = 0;
gdjs.Area1_463Code.GDLevel_9595numberObjects7.length = 0;
gdjs.Area1_463Code.GDLevel_9595numberObjects8.length = 0;
gdjs.Area1_463Code.GDLevel_9595numberObjects9.length = 0;
gdjs.Area1_463Code.GDplayernameObjects1.length = 0;
gdjs.Area1_463Code.GDplayernameObjects2.length = 0;
gdjs.Area1_463Code.GDplayernameObjects3.length = 0;
gdjs.Area1_463Code.GDplayernameObjects4.length = 0;
gdjs.Area1_463Code.GDplayernameObjects5.length = 0;
gdjs.Area1_463Code.GDplayernameObjects6.length = 0;
gdjs.Area1_463Code.GDplayernameObjects7.length = 0;
gdjs.Area1_463Code.GDplayernameObjects8.length = 0;
gdjs.Area1_463Code.GDplayernameObjects9.length = 0;
gdjs.Area1_463Code.GDScreenObjects1.length = 0;
gdjs.Area1_463Code.GDScreenObjects2.length = 0;
gdjs.Area1_463Code.GDScreenObjects3.length = 0;
gdjs.Area1_463Code.GDScreenObjects4.length = 0;
gdjs.Area1_463Code.GDScreenObjects5.length = 0;
gdjs.Area1_463Code.GDScreenObjects6.length = 0;
gdjs.Area1_463Code.GDScreenObjects7.length = 0;
gdjs.Area1_463Code.GDScreenObjects8.length = 0;
gdjs.Area1_463Code.GDScreenObjects9.length = 0;
gdjs.Area1_463Code.GDMenuObjects1.length = 0;
gdjs.Area1_463Code.GDMenuObjects2.length = 0;
gdjs.Area1_463Code.GDMenuObjects3.length = 0;
gdjs.Area1_463Code.GDMenuObjects4.length = 0;
gdjs.Area1_463Code.GDMenuObjects5.length = 0;
gdjs.Area1_463Code.GDMenuObjects6.length = 0;
gdjs.Area1_463Code.GDMenuObjects7.length = 0;
gdjs.Area1_463Code.GDMenuObjects8.length = 0;
gdjs.Area1_463Code.GDMenuObjects9.length = 0;
gdjs.Area1_463Code.GDHealthemptyObjects1.length = 0;
gdjs.Area1_463Code.GDHealthemptyObjects2.length = 0;
gdjs.Area1_463Code.GDHealthemptyObjects3.length = 0;
gdjs.Area1_463Code.GDHealthemptyObjects4.length = 0;
gdjs.Area1_463Code.GDHealthemptyObjects5.length = 0;
gdjs.Area1_463Code.GDHealthemptyObjects6.length = 0;
gdjs.Area1_463Code.GDHealthemptyObjects7.length = 0;
gdjs.Area1_463Code.GDHealthemptyObjects8.length = 0;
gdjs.Area1_463Code.GDHealthemptyObjects9.length = 0;
gdjs.Area1_463Code.GDPotionObjects1.length = 0;
gdjs.Area1_463Code.GDPotionObjects2.length = 0;
gdjs.Area1_463Code.GDPotionObjects3.length = 0;
gdjs.Area1_463Code.GDPotionObjects4.length = 0;
gdjs.Area1_463Code.GDPotionObjects5.length = 0;
gdjs.Area1_463Code.GDPotionObjects6.length = 0;
gdjs.Area1_463Code.GDPotionObjects7.length = 0;
gdjs.Area1_463Code.GDPotionObjects8.length = 0;
gdjs.Area1_463Code.GDPotionObjects9.length = 0;
gdjs.Area1_463Code.GDPotion_9595boxObjects1.length = 0;
gdjs.Area1_463Code.GDPotion_9595boxObjects2.length = 0;
gdjs.Area1_463Code.GDPotion_9595boxObjects3.length = 0;
gdjs.Area1_463Code.GDPotion_9595boxObjects4.length = 0;
gdjs.Area1_463Code.GDPotion_9595boxObjects5.length = 0;
gdjs.Area1_463Code.GDPotion_9595boxObjects6.length = 0;
gdjs.Area1_463Code.GDPotion_9595boxObjects7.length = 0;
gdjs.Area1_463Code.GDPotion_9595boxObjects8.length = 0;
gdjs.Area1_463Code.GDPotion_9595boxObjects9.length = 0;
gdjs.Area1_463Code.GDPotion_9595numberObjects1.length = 0;
gdjs.Area1_463Code.GDPotion_9595numberObjects2.length = 0;
gdjs.Area1_463Code.GDPotion_9595numberObjects3.length = 0;
gdjs.Area1_463Code.GDPotion_9595numberObjects4.length = 0;
gdjs.Area1_463Code.GDPotion_9595numberObjects5.length = 0;
gdjs.Area1_463Code.GDPotion_9595numberObjects6.length = 0;
gdjs.Area1_463Code.GDPotion_9595numberObjects7.length = 0;
gdjs.Area1_463Code.GDPotion_9595numberObjects8.length = 0;
gdjs.Area1_463Code.GDPotion_9595numberObjects9.length = 0;
gdjs.Area1_463Code.GDTImerObjects1.length = 0;
gdjs.Area1_463Code.GDTImerObjects2.length = 0;
gdjs.Area1_463Code.GDTImerObjects3.length = 0;
gdjs.Area1_463Code.GDTImerObjects4.length = 0;
gdjs.Area1_463Code.GDTImerObjects5.length = 0;
gdjs.Area1_463Code.GDTImerObjects6.length = 0;
gdjs.Area1_463Code.GDTImerObjects7.length = 0;
gdjs.Area1_463Code.GDTImerObjects8.length = 0;
gdjs.Area1_463Code.GDTImerObjects9.length = 0;
gdjs.Area1_463Code.GDKillcountObjects1.length = 0;
gdjs.Area1_463Code.GDKillcountObjects2.length = 0;
gdjs.Area1_463Code.GDKillcountObjects3.length = 0;
gdjs.Area1_463Code.GDKillcountObjects4.length = 0;
gdjs.Area1_463Code.GDKillcountObjects5.length = 0;
gdjs.Area1_463Code.GDKillcountObjects6.length = 0;
gdjs.Area1_463Code.GDKillcountObjects7.length = 0;
gdjs.Area1_463Code.GDKillcountObjects8.length = 0;
gdjs.Area1_463Code.GDKillcountObjects9.length = 0;

gdjs.Area1_463Code.eventsList75(runtimeScene);

return;

}

gdjs['Area1_463Code'] = gdjs.Area1_463Code;
